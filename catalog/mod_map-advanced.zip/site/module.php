<?php
/**
 * Модуль: Яндекс.Карты — сайт
 */

$subtitle = $moduleData['subtitle'] ?? '';
$title = $moduleData['title'] ?? '';
$description = $moduleData['description'] ?? '';
$items = $moduleData['items'] ?? [];
$centerLat = $moduleData['center_lat'] ?? '55.7558';
$centerLng = $moduleData['center_lng'] ?? '37.6176';

$zoom = intval($moduleData['zoom'] ?? 15);
if ($zoom < 1) $zoom = 1;
if ($zoom > 21) $zoom = 21;

$height = intval($moduleData['height'] ?? 400);
if ($height < 100) $height = 100;
if ($height > 2000) $height = 2000;

$apiKey = $moduleData['api_key'] ?? '';
$enableClustering = $moduleData['enable_clustering'] ?? true;

// Необязательный локальный скриншот карты: показывается до согласия
// вместо схематичной карты. Сторонние запросы при этом не нужны.
$previewImage = trim((string)($moduleData['preview_image'] ?? ''));
if ($previewImage !== '') {
    $previewImage = mediaImageSrc($previewImage);
}

if (!is_array($items) || empty($items)) {
    return;
}

// Карта — сторонний сервис: категория нужна в баннере даже без сниппетов.
if (function_exists('alpin_consent_require')) {
    alpin_consent_require('functional');
}

// Активная метка — по флагу `active` у самой метки.
// Если ни одна не отмечена — $activeIndex остаётся -1.
$activeIndex = -1;
foreach ($items as $idx => $item) {
    if (!empty($item['active']) && $item['active'] !== '0') {
        $activeIndex = $idx;
        break;
    }
}

$hasHeader = !empty($subtitle) || !empty($title) || !empty($description);
$mapId = 'map-' . md5(json_encode($items) . $centerLat . $centerLng . $zoom);
?>

<?php if ($hasHeader): ?>
<div class="text-center max-w-3xl mx-auto mb-12">
    <?php if (!empty($subtitle)): ?>
    <span class="text-[var(--primary-color)] font-bold tracking-wider uppercase text-sm block mb-2"><?php echo e($subtitle); ?></span>
    <?php endif; ?>

    <?php if (!empty($title)): ?>
    <h2 class="text-3xl md:text-4xl font-bold text-slate-800 mb-4"><?php echo e($title); ?></h2>
    <?php endif; ?>

    <?php if (!empty($description)): ?>
    <p class="text-[var(--text-muted)] max-w-2xl mx-auto text-lg"><?php echo e($description); ?></p>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Карта -->
<div id="<?php echo e($mapId); ?>" class="map-container" style="height: <?php echo e($height); ?>px; width: 100%; border-radius: 1rem; overflow: hidden; background: #f1f5f9;" 
     data-center-lat="<?php echo e($centerLat); ?>"
     data-center-lng="<?php echo e($centerLng); ?>"
     data-zoom="<?php echo e($zoom); ?>"
     data-api-key="<?php echo e($apiKey); ?>"
     data-enable-clustering="<?php echo $enableClustering ? 'true' : 'false'; ?>"
     data-active-index="<?php echo (int)$activeIndex; ?>"
     data-items='<?php echo e(json_encode($items, JSON_UNESCAPED_UNICODE)); ?>'>
    <div class="map-consent" hidden>
        <?php if ($previewImage !== ''): ?>
        <img class="map-consent__image" src="<?php echo e($previewImage); ?>" alt="" loading="lazy">
        <?php else: ?>
        <svg class="map-consent__bg" viewBox="0 0 800 400" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
            <rect width="800" height="400" fill="#eef2f7"/>
            <path d="M0 120 C 140 90 240 150 360 130 S 620 60 800 100 L 800 0 L 0 0 Z" fill="#e4edf8"/>
            <path d="M0 300 C 120 270 220 330 340 310 S 620 250 800 280 L 800 400 L 0 400 Z" fill="#e7f0e6"/>
            <g fill="#e3e9f1">
                <rect x="60" y="60" width="120" height="70" rx="10"/>
                <rect x="220" y="45" width="90" height="95" rx="10"/>
                <rect x="470" y="60" width="120" height="80" rx="10"/>
                <rect x="630" y="45" width="110" height="90" rx="10"/>
                <rect x="70" y="180" width="130" height="80" rx="10"/>
                <rect x="490" y="190" width="110" height="70" rx="10"/>
                <rect x="640" y="180" width="100" height="90" rx="10"/>
                <rect x="90" y="300" width="120" height="60" rx="10"/>
                <rect x="600" y="300" width="130" height="70" rx="10"/>
            </g>
            <path d="M0 330 C 140 300 230 360 360 335 S 650 285 800 315" fill="none" stroke="#d3e6f7" stroke-width="30"/>
            <g stroke="#ffffff" stroke-width="16" stroke-linecap="round">
                <path d="M0 160 H800"/>
                <path d="M400 0 V400"/>
                <path d="M0 280 H800"/>
            </g>
            <g stroke="#f7fafc" stroke-width="8" stroke-linecap="round">
                <path d="M180 0 V400"/>
                <path d="M590 0 V400"/>
            </g>
            <g transform="translate(520 110)">
                <path d="M0 0c-18 0-32 14-32 32 0 24 32 56 32 56s32-32 32-56C32 14 18 0 0 0z" fill="var(--primary-color, #10B981)"/>
                <circle cx="0" cy="32" r="11" fill="#ffffff"/>
            </g>
        </svg>
        <?php endif; ?>
        <div class="map-consent__card">
            <p class="map-consent__text" data-consent-text-default>Карта загружается с сервера Яндекс.Карт: сервис получит IP-адрес и данные браузера.</p>
            <p class="map-consent__text" data-consent-text-denied hidden>Вы отключили функциональные cookie, поэтому карта не загружается. Включить их можно в настройках cookie.</p>
            <div class="map-consent__actions">
                <button type="button" class="map-consent__btn" data-map-consent-load>Показать карту</button>
                <button type="button" class="map-consent__btn map-consent__btn--ghost" data-consent-open hidden>Настройки cookie</button>
            </div>
        </div>
    </div>
    <div class="map-loading flex items-center justify-center h-full text-slate-400" hidden>
        <span class="icon-loader animate-spin text-2xl mr-2"></span> Загрузка карты...
    </div>
</div>

<!-- Список меток под картой -->
<?php if (count($items) > 1): ?>
<div class="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
    <?php foreach ($items as $idx => $item): 
        $name = $item['name'] ?? '';
        $address = $item['address'] ?? '';
        $phone = $item['phone'] ?? '';
        $email = $item['email'] ?? '';
        $workHours = $item['work_hours'] ?? '';
        $icon = $item['icon'] ?? '';
    ?>
    <div class="map-placemark-item flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-100 hover:shadow-md transition-shadow" data-index="<?php echo $idx; ?>">
        <?php if (!empty($icon)): ?>
        <div class="text-2xl text-[var(--primary-color)] mt-0.5">
            <span class="<?php echo e($icon); ?>"></span>
        </div>
        <?php endif; ?>
        <div class="min-w-0 flex-1">
            <?php if (!empty($name)): ?>
            <div class="font-bold text-slate-800 text-sm"><?php echo e($name); ?></div>
            <?php endif; ?>
            <?php if (!empty($address)): ?>
            <div class="text-xs text-slate-500 mt-0.5"><span class="icon-map-pin map-contact-icon"></span><span class="map-contact-text"><?php echo e($address); ?></span></div>
            <?php endif; ?>
            <?php if (!empty($phone)): ?>
            <div class="text-xs text-slate-500 mt-0.5"><span class="icon-phone map-contact-icon"></span><span class="map-contact-text"><?php echo e($phone); ?></span></div>
            <?php endif; ?>
            <?php if (!empty($email)): ?>
            <div class="text-xs text-slate-500 mt-0.5"><span class="icon-mail map-contact-icon"></span><span class="map-contact-text"><?php echo e($email); ?></span></div>
            <?php endif; ?>
            <?php if (!empty($workHours)): ?>
            <div class="text-xs text-slate-500 mt-0.5"><span class="icon-clock map-contact-icon"></span><span class="map-contact-text"><?php echo e($workHours); ?></span></div>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>