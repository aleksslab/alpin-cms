<?php
/**
 * Плагин «Предпросмотр».
 *
 * Временный предпросмотр из конструктора и постоянные preview-ссылки для
 * согласования страниц. Ядро оставляет только режим рендера (`isPreview`)
 * и публичные функции чтения: loadPreviewById() и loadPageByPreviewToken().
 *
 * Данные остаются на месте: data/preview/ и поле preview_token в JSON страницы.
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

/**
 * Возвращает путь к папке временных preview-файлов.
 *
 * @return string Путь с завершающим разделителем
 */
function preview_dir(): string {
    return DATA_DIR . 'preview' . DIRECTORY_SEPARATOR;
}

/**
 * Гарантирует существование папки preview + .htaccess защиту.
 *
 * @return bool true, если папка доступна для записи
 */
function preview_ensure_dir(): bool {
    $dir = preview_dir();

    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0755, true)) {
            return false;
        }
    }

    $htaccess = $dir . '.htaccess';
    if (!file_exists($htaccess)) {
        $data = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n"
              . "<IfModule !mod_authz_core.c>\n    Order Deny,Allow\n    Deny from all\n</IfModule>\n";
        @file_put_contents($htaccess, $data);
    }

    return is_writable($dir);
}

/**
 * Удаляет все временные preview-файлы.
 *
 * @return int Количество удалённых файлов
 */
function preview_cleanup_all(): int {
    $dir = preview_dir();
    if (!is_dir($dir)) {
        return 0;
    }

    $files = glob($dir . '*.json');
    if (empty($files)) {
        return 0;
    }

    $deleted = 0;
    foreach ($files as $file) {
        if (@unlink($file)) {
            $deleted++;
        }
    }

    return $deleted;
}

/**
 * Удаляет preview-файлы конкретной сессии для конкретной страницы.
 *
 * @param string $sessionId ID сессии
 * @param string $pageId    ID страницы ('' — для ещё не сохранённой)
 * @return int Количество удалённых файлов
 */
function preview_cleanup_session_page(string $sessionId, string $pageId): int {
    $dir = preview_dir();
    if ($sessionId === '' || !is_dir($dir)) {
        return 0;
    }

    $files = glob($dir . '*.json');
    if (empty($files)) {
        return 0;
    }

    $deleted = 0;
    foreach ($files as $file) {
        $data = json_decode((string)file_get_contents($file), true);
        if (!is_array($data)) {
            @unlink($file);
            continue;
        }

        $meta = $data['_preview'] ?? [];
        $fileSessionId = $meta['session_id'] ?? '';
        $filePageId    = $meta['page_id'] ?? '';

        if ($fileSessionId === $sessionId && $filePageId === $pageId) {
            if (@unlink($file)) {
                $deleted++;
            }
        }
    }

    return $deleted;
}

/**
 * Создаёт или перезаписывает preview-файл для пары (session + page).
 *
 * @param array       $pageData         Данные страницы
 * @param string      $sessionId        ID сессии админа
 * @param string      $pageId           ID страницы ('' для новой)
 * @param string|null $existingPreviewId Если был preview с этим ID — перезаписываем его
 * @param string      $createdBy        Логин админа
 * @return array ['success' => bool, 'preview_id' => string, 'error' => string]
 */
function preview_create(array $pageData, string $sessionId, string $pageId,
    ?string $existingPreviewId = null, string $createdBy = 'system'): array {
    if ($sessionId === '') {
        return ['success' => false, 'preview_id' => '', 'error' => 'Невалидная сессия.'];
    }

    if (!preview_ensure_dir()) {
        return ['success' => false, 'preview_id' => '', 'error' => 'Папка preview недоступна для записи.'];
    }

    $dir = preview_dir();
    $previewId = '';
    $targetPath = '';

    // Проверяем, можно ли перезаписать существующий
    if ($existingPreviewId !== null && preg_match('/^[a-f0-9]{32}$/i', $existingPreviewId)) {
        $existingPath = $dir . $existingPreviewId . '.json';
        if (file_exists($existingPath)) {
            $existingData = json_decode((string)file_get_contents($existingPath), true);
            if (is_array($existingData)) {
                $meta = $existingData['_preview'] ?? [];
                if (($meta['session_id'] ?? '') === $sessionId
                    && ($meta['page_id'] ?? '') === $pageId
                ) {
                    $previewId = $existingPreviewId;
                    $targetPath = $existingPath;
                }
            }
        }
    }

    // Если не нашли существующий — создаём новый ID
    if ($previewId === '') {
        $previewId = bin2hex(random_bytes(16));
        $targetPath = $dir . $previewId . '.json';
    }

    // Добавляем метаданные
    $pageData['_preview'] = [
        'preview_id' => $previewId,
        'session_id' => $sessionId,
        'page_id'    => $pageId,
        'created_at' => time(),
        'created_by' => $createdBy,
    ];

    $json = json_encode($pageData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if (!safeFileWrite($targetPath, (string)$json)) {
        return ['success' => false, 'preview_id' => '', 'error' => 'Не удалось записать preview-файл.'];
    }

    return ['success' => true, 'preview_id' => $previewId, 'error' => ''];
}

/**
 * Формирует URL временного preview.
 *
 * @param string $previewId 32 hex-символа
 * @param string $slug      Slug страницы ('' для главной)
 * @return string Относительный URL
 */
function preview_url(string $previewId, string $slug = ''): string {
    $base = '/';
    if ($slug !== '') {
        $base = '/' . trim($slug, '/');
    }
    return $base . '?preview=' . $previewId;
}

/**
 * Возвращает preview_token страницы (или пустую строку, если не задан).
 *
 * @param string $pageId
 * @return string
 */
function preview_page_token(string $pageId): string {
    if (!preg_match('/^[a-z0-9\-_]+$/i', $pageId)) {
        return '';
    }

    $page = loadPageById($pageId);
    if (!$page) {
        return '';
    }

    return (string)($page['preview_token'] ?? '');
}

/**
 * Формирует полный preview-URL для сохранённой страницы.
 *
 * @param string $pageId
 * @param string $token preview_token
 * @return string URL вида https://host/{slug}?preview={token}
 */
function preview_page_url(string $pageId, string $token): string {
    $page = loadPageById($pageId);
    $slug = $page['slug'] ?? '';

    $base = '/' . trim($slug, '/');
    if ($slug === '') {
        $base = '/';
    }

    return getBaseUrl() . $base . '?preview=' . $token;
}

/**
 * Собирает и создаёт preview из POST-запроса конструктора.
 *
 * @return array Ответ для JSON
 */
function preview_create_from_post(): array {
    $pageId       = trim((string)($_POST['page_id'] ?? ''));
    $template     = trim((string)($_POST['template'] ?? 'full-width'));
    $showHeader   = !empty($_POST['show_header']);
    $showFooter   = !empty($_POST['show_footer']);
    $title        = trim((string)($_POST['title'] ?? ''));
    $slug         = trim((string)($_POST['slug'] ?? ''));
    $rowsJson     = (string)($_POST['rows_json'] ?? '');
    $metaDesc     = trim((string)($_POST['meta_description'] ?? ''));
    $metaKeywords = trim((string)($_POST['meta_keywords'] ?? ''));
    $existingId   = trim((string)($_POST['existing_preview_id'] ?? ''));

    // Валидация ID страницы (для сохранённых)
    if ($pageId !== '' && !preg_match('/^[a-z0-9\-_]+$/i', $pageId)) {
        return ['success' => false, 'error' => 'Невалидный ID страницы.'];
    }

    // Валидация slug (для новых)
    if ($slug !== '' && !preg_match('/^[a-z0-9\-_]+$/i', $slug)) {
        return ['success' => false, 'error' => 'Невалидный slug.'];
    }

    // Валидация template
    if (!preg_match('/^[a-z0-9\-_]+$/i', $template)) {
        $template = 'full-width';
    }
    $templatesData = getTemplateData();
    $validTemplates = array_column($templatesData['templates'] ?? [], 'id');
    if (!in_array($template, $validTemplates, true)) {
        $template = 'full-width';
    }

    // Парсим rows
    $rows = [];
    if ($rowsJson !== '') {
        $rows = json_decode($rowsJson, true);
        if (!is_array($rows)) {
            $rows = [];
        }
    }

    $pageData = [
        'id'           => $pageId !== '' ? $pageId : 'preview',
        'title'        => $title,
        'slug'         => $slug,
        'template'     => $template,
        'status'       => 'published',  // в preview статус роли не играет
        'publish_at'   => null,
        'unpublish_at' => null,
        'meta'         => [
            'description' => $metaDesc,
            'keywords'    => $metaKeywords,
        ],
        'show_header'  => $showHeader,
        'show_footer'  => $showFooter,
        'rows'         => $rows,
    ];

    $result = preview_create(
        $pageData,
        session_id(),
        $pageId,
        $existingId !== '' ? $existingId : null,
        (string)($_SESSION['admin_login'] ?? 'system')
    );

    if (empty($result['success'])) {
        return ['success' => false, 'error' => $result['error'] ?? 'Не удалось создать preview.'];
    }

    return [
        'success'    => true,
        'preview_id' => $result['preview_id'],
        'url'        => preview_url($result['preview_id'], $slug),
    ];
}

/**
 * AJAX-обработчик админки: токен и создание preview.
 *
 * Вызывается на admin_init — авторизация и CSRF уже проверены ядром.
 *
 * @return void
 */
function preview_handle_admin_init(): void {
    if (($_GET['tab'] ?? '') !== 'pages') {
        return;
    }

    $ajax = $_GET['ajax'] ?? '';

    // Генерация preview-токена (GET) — запись только при сохранении страницы.
    if ($ajax === 'generate_preview_token' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => true, 'token' => bin2hex(random_bytes(16))]);
        exit;
    }

    // Создание временного preview из конструктора (POST).
    if ($ajax === 'preview_create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(preview_create_from_post(), JSON_UNESCAPED_UNICODE);
        exit;
    }
}

/**
 * Сохраняет или удаляет preview_token при сохранении страницы.
 *
 * @param array      $pageData Данные страницы
 * @param string     $id       ID страницы
 * @param array|null $oldPage  Версия на диске (null при создании)
 * @return array
 */
function preview_filter_page_data(array $pageData, string $id, ?array $oldPage): array {
    if (!$oldPage || !array_key_exists('preview_token', $_POST)) {
        return $pageData;
    }

    $token = trim((string)($_POST['preview_token'] ?? ''));
    if (preg_match('/^[a-f0-9]{32}$/i', $token)) {
        $pageData['preview_token'] = $token;
    }

    return $pageData;
}

/**
 * Чистит временные preview после сохранения страницы.
 *
 * @param string     $id       ID страницы
 * @param array      $pageData Данные страницы
 * @param array|null $oldPage  Версия на диске (null при создании)
 * @return void
 */
function preview_after_page_saved(string $id, array $pageData, ?array $oldPage): void {
    $sessionId = session_id();
    if ($sessionId === '') {
        return;
    }

    preview_cleanup_session_page($sessionId, $id);

    // При создании previews делались для ещё не сохранённой страницы (page_id = '')
    if ($oldPage === null) {
        preview_cleanup_session_page($sessionId, '');
    }
}

/**
 * Выводит блок preview-ссылки в форме редактирования страницы.
 *
 * @param array  $page   Данные страницы
 * @param string $pageId ID страницы
 * @return void
 */
function preview_render_edit_block(array $page, string $pageId): void {
    // Заход в редактор делает временные previews этой страницы неактуальными
    preview_cleanup_session_page(session_id(), $pageId);

    $existingToken = preview_page_token($pageId);
    $previewUrl = $existingToken !== ''
        ? preview_page_url($pageId, $existingToken)
        : '';

    include __DIR__ . '/admin-preview-block.php';
}

/**
 * Подключает JS плагина на странице редактирования/создания страницы.
 *
 * @param string $pageId ID страницы
 * @param bool   $isEdit Режим редактирования
 * @return void
 */
function preview_render_scripts(string $pageId, bool $isEdit): void {
    $file = APP_ROOT . '/config/js/preview.js';
    $version = file_exists($file) ? (string)filemtime($file) : '1';

    echo '<script src="js/preview.js?v=' . e($version) . '" type="text/javascript"></script>' . "\n";
}

/**
 * Выводит баннер предпросмотра на фронте.
 *
 * @param bool $isPreview Находится ли страница в режиме предпросмотра
 * @return void
 */
function preview_render_banner(bool $isPreview): void {
    if (!$isPreview) {
        return;
    }
    ?>
    <div class="fixed top-0 left-0 right-0 z-[9999] bg-amber-400 text-amber-900 text-center py-2.5 px-4 text-sm font-bold shadow-md">
        <span class="inline-flex items-center gap-2">
            <span class="icon-eye text-base"></span>
            Предпросмотр — страница не опубликована
        </span>
    </div>
    <div style="height: 44px;"></div>
    <?php
}

// Возможность включена, пока плагин активен.
add_filter('preview_enabled', function () {
    return true;
});

// AJAX админки: токен и создание preview.
add_action('admin_init', 'preview_handle_admin_init');

// Успешный вход — чистим все временные preview.
add_action('admin_login_success', function ($userIp) {
    preview_cleanup_all();
});

// Сохранение страницы: preview_token и очистка временных файлов.
add_filter('page_data_before_save', 'preview_filter_page_data', 10, 3);
add_action('page_saved', 'preview_after_page_saved', 10, 3);

// UI редактора и фронта.
add_action('edit_page_preview_block', 'preview_render_edit_block', 10, 2);
add_action('edit_page_scripts', 'preview_render_scripts', 10, 2);
add_action('site_preview_banner', 'preview_render_banner', 10, 1);
