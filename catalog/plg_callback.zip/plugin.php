<?php
/**
 * Плагин: Обратный звонок
 *
 * Плавающая кнопка и мини-форма на сайте, журнал заявок в админке.
 * Заявка сначала пишется в data/callback/requests.json, письмо — необязательное
 * уведомление: если почтовый агент не настроен, заявка всё равно сохраняется.
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

// =========================================================================
// НАСТРОЙКИ
// =========================================================================

/**
 * Значения настроек по умолчанию.
 *
 * @return array
 */
function callback_defaults(): array {
    return [
        'enabled'         => true,
        'title'           => 'Заказать звонок',
        'subtitle'        => 'Оставьте номер — перезвоним в рабочее время',
        'button_label'    => 'Перезвоните мне',
        'submit_text'     => 'Отправить',
        'success_message' => 'Спасибо! Мы перезвоним в ближайшее время.',
        'phone_format'    => '+7 (___) ___-__-__',
        'position'        => 'right_bottom',
        'show_name'       => true,
        'name_required'   => false,
        'show_comment'    => false,
        'show_privacy'    => true,
        'privacy_text'    => 'Отправляя форму, вы соглашаетесь с {policy}.',
        'privacy_label'   => 'политикой конфиденциальности',
        'privacy_url'     => '',
        'notify_email'    => '',
        'retention_days'  => 30,
        'max_records'     => 1000,
    ];
}

/**
 * Позиции плавающей кнопки.
 *
 * @return array [ключ => подпись]
 */
function callback_positions(): array {
    return [
        'right_bottom' => 'Справа снизу',
        'right_middle' => 'Справа по центру',
        'right_top'    => 'Справа сверху',
        'left_bottom'  => 'Слева снизу',
        'left_middle'  => 'Слева по центру',
        'left_top'     => 'Слева сверху',
    ];
}

/**
 * Адрес политики конфиденциальности.
 *
 * Своё значение из настроек плагина важнее; если пусто — берём ссылку,
 * которую уже задали для cookie-баннера или cookie-согласия.
 *
 * @param array $settings
 * @return string
 */
function callback_privacy_url(array $settings): string {
    $url = trim((string)($settings['privacy_url'] ?? ''));

    if ($url !== '') {
        return $url;
    }

    $site = getSettingsData();

    foreach (['cookie_consent_policy_url', 'cookie_banner_policy_url'] as $key) {
        $candidate = trim((string)($site[$key] ?? ''));

        if ($candidate !== '') {
            return $candidate;
        }
    }

    return '';
}

/**
 * Текущие настройки плагина.
 *
 * @return array
 */
function callback_get_settings(): array {
    $settings = getSettingsData();
    $saved = $settings['callback'] ?? [];

    if (!is_array($saved)) {
        $saved = [];
    }

    return array_merge(callback_defaults(), $saved);
}

// =========================================================================
// ХРАНИЛИЩЕ ЗАЯВОК
// =========================================================================

/**
 * Каталог данных плагина.
 *
 * @return string
 */
function callback_data_dir(): string {
    return APP_ROOT . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'callback';
}

/**
 * Путь к файлу заявок.
 *
 * @return string
 */
function callback_requests_path(): string {
    return callback_data_dir() . DIRECTORY_SEPARATOR . 'requests.json';
}

/**
 * Путь к служебному состоянию (последняя ошибка отправки письма).
 *
 * @return string
 */
function callback_state_path(): string {
    return callback_data_dir() . DIRECTORY_SEPARATOR . 'state.json';
}

/**
 * Читает заявки.
 *
 * @return array
 */
function callback_read_requests(): array {
    $path = callback_requests_path();

    if (!is_file($path)) {
        return [];
    }

    $raw = json_decode((string)@file_get_contents($path), true);

    if (!is_array($raw)) {
        return [];
    }

    // Поддерживаем и {items: [...]}, и просто массив.
    $items = isset($raw['items']) && is_array($raw['items']) ? $raw['items'] : $raw;

    if (!is_array($items)) {
        return [];
    }

    $result = [];

    foreach ($items as $item) {
        if (is_array($item) && !empty($item['id'])) {
            $result[] = $item;
        }
    }

    return $result;
}

/**
 * Записывает заявки через safeFileWrite().
 *
 * @param array $items
 * @return bool
 */
function callback_write_requests(array $items): bool {
    $dir = callback_data_dir();

    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }

    return safeFileWrite(
        callback_requests_path(),
        json_encode(array_values($items), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
    );
}

/**
 * Читает служебное состояние.
 *
 * @return array
 */
function callback_get_state(): array {
    $path = callback_state_path();

    if (!is_file($path)) {
        return [];
    }

    $raw = json_decode((string)@file_get_contents($path), true);

    return is_array($raw) ? $raw : [];
}

/**
 * Обновляет служебное состояние.
 *
 * @param array $patch
 * @return void
 */
function callback_set_state(array $patch): void {
    $dir = callback_data_dir();

    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return;
    }

    $state = array_merge(callback_get_state(), $patch);

    safeFileWrite(
        callback_state_path(),
        json_encode($state, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
    );
}

/**
 * Чистит старые заявки по сроку хранения и лимиту записей.
 *
 * @param array $items
 * @return array
 */
function callback_prune_requests(array $items): array {
    $settings = callback_get_settings();
    $days = max(1, (int)$settings['retention_days']);
    $minTs = time() - $days * 86400;

    $items = array_values(array_filter($items, function ($item) use ($minTs) {
        return (int)($item['created_at'] ?? 0) >= $minTs;
    }));

    $max = max(10, (int)$settings['max_records']);

    if (count($items) > $max) {
        $items = array_slice($items, -$max);
    }

    return $items;
}

// =========================================================================
// ПРИЁМ ЗАЯВКИ
// =========================================================================

/**
 * Отвечает JSON и завершает запрос.
 *
 * @param int   $code
 * @param array $payload
 * @return void
 */
function callback_json_response(int $code, array $payload): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Очищает пользовательский текст: без тегов, управляющих символов и лишней длины.
 *
 * @param mixed $value
 * @param int   $limit
 * @return string
 */
function callback_clean_text($value, int $limit): string {
    $text = trim((string)$value);
    $text = strip_tags($text);
    $text = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $text) ?? '';

    return mb_substr($text, 0, $limit);
}

/**
 * Оставляет в номере только цифры.
 *
 * @param mixed $phone
 * @return string
 */
function callback_phone_digits($phone): string {
    $digits = preg_replace('/\D+/', '', (string)$phone);

    return is_string($digits) ? $digits : '';
}

/**
 * Приводит номер к читаемому виду для админки.
 *
 * @param string $digits
 * @return string
 */
function callback_format_phone(string $digits): string {
    if ($digits === '') {
        return '';
    }

    // 11 цифр с 7 или 8 — российский номер, приводим к +7 (XXX) XXX-XX-XX.
    if (strlen($digits) === 11 && ($digits[0] === '7' || $digits[0] === '8')) {
        $base = '7' . substr($digits, 1);

        return '+' . $base[0] . ' (' . substr($base, 1, 3) . ') '
            . substr($base, 4, 3) . '-' . substr($base, 7, 2) . '-' . substr($base, 9, 2);
    }

    return '+' . $digits;
}

/**
 * Сколько цифр ждёт формат номера.
 *
 * Формат вида `+7 (___) ___-__-__`: подчёркивания — места для цифр,
 * остальные цифры в строке — литералы (например, код страны).
 *
 * @param string $format
 * @return int 0 — формат пустой, проверять нечего
 */
function callback_phone_expected_digits(string $format): int {
    if (trim($format) === '') {
        return 0;
    }

    $placeholders = substr_count($format, '_');
    $literals = preg_match_all('/\d/', $format);

    return $placeholders + (int)$literals;
}

/**
 * Регулярка для цифр номера по формату.
 *
 * Литералы из формата должны совпасть, подчёркивания принимают любую цифру.
 * Ведущая 7 в формате допускает 8 — так принимаются оба привычных варианта.
 *
 * @param string $format
 * @return string Пустая строка — формат не задан
 */
function callback_phone_digit_pattern(string $format): string {
    $mask = preg_replace('/[^0-9_]/', '', $format);

    if (!is_string($mask) || $mask === '' || strpos($mask, '_') === false) {
        return '';
    }

    $pattern = '';
    $length = strlen($mask);

    for ($i = 0; $i < $length; $i++) {
        $char = $mask[$i];

        if ($char === '_') {
            $pattern .= '\\d';
        } elseif ($i === 0 && $char === '7') {
            $pattern .= '[78]';
        } else {
            $pattern .= $char;
        }
    }

    return $pattern;
}

/**
 * Ограничивает частоту: не больше 3 заявок в час с одного IP.
 *
 * @param array  $items
 * @param string $ip
 * @return bool true — лимит исчерпан
 */
function callback_rate_limited(array $items, string $ip): bool {
    $minTs = time() - 3600;
    $count = 0;

    foreach ($items as $item) {
        if (($item['ip'] ?? '') === $ip && (int)($item['created_at'] ?? 0) >= $minTs) {
            $count++;
        }
    }

    return $count >= 3;
}

/**
 * Адрес эндпоинта с учётом подпапки установки.
 *
 * @return string
 */
function callback_endpoint_url(): string {
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '/index.php'));

    // На Windows dirname('/page') возвращает '\', поэтому нормализуем и её.
    $dir = str_replace('\\', '/', dirname($script));
    $dir = ($dir === '.' || $dir === '/') ? '' : rtrim($dir, '/');

    return $dir . '/callback';
}

/**
 * Страница, с которой пришла заявка.
 *
 * @return string
 */
function callback_request_page(): string {
    $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
    $path = $referer !== '' ? (string)parse_url($referer, PHP_URL_PATH) : '';

    if ($path === '') {
        return '';
    }

    return mb_substr(preg_replace('/[^\w\-\/.]/', '', $path) ?? '', 0, 255);
}

/**
 * Отправляет уведомление о заявке, если почтовый агент настроен.
 *
 * @param array $item
 * @return void
 */
function callback_send_notification(array $item): void {
    if (!function_exists('send_site_mail')
        || !function_exists('mail_agent_is_configured')
        || !function_exists('get_mail_config')
    ) {
        return;
    }

    if (!mail_agent_is_configured()) {
        return;
    }

    $settings = callback_get_settings();
    $config = get_mail_config(true);
    $to = trim((string)$settings['notify_email']);

    if ($to !== '' && filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $config['to_email'] = $to;
    }

    $rows = ['Телефон' => $item['phone']];

    if ($item['name'] !== '') {
        $rows['Имя'] = $item['name'];
    }

    if ($item['comment'] !== '') {
        $rows['Комментарий'] = $item['comment'];
    }

    if ($item['page'] !== '') {
        $rows['Страница'] = $item['page'];
    }

    $rows['Время'] = date('d.m.Y H:i', (int)$item['created_at']);

    $html = '<h2>Заявка на обратный звонок</h2>'
        . '<table cellpadding="6" style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px">';

    foreach ($rows as $label => $value) {
        $html .= '<tr>'
            . '<td style="border:1px solid #e2e8f0;font-weight:600;vertical-align:top">' . e($label) . '</td>'
            . '<td style="border:1px solid #e2e8f0">' . nl2br(e((string)$value), false) . '</td>'
            . '</tr>';
    }

    $html .= '</table>';

    $result = send_site_mail('Заявка на обратный звонок', $html, '', '', $config);
    $success = !empty($result['success']);

    callback_set_state([
        'last_mail_at'    => time(),
        'last_mail_error' => $success ? '' : (string)($result['error'] ?? ''),
    ]);

    if (!$success) {
        if (function_exists('logAction')) {
            logAction('callback_mail_error', 'Письмо о заявке не отправлено: ' . ($result['error'] ?? ''), 'WARNING');
        }
    }
}

/**
 * Обработчик маршрута /callback.
 *
 * @return void
 */
function callback_handle_request(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        callback_json_response(405, ['success' => false, 'error' => 'Метод не поддерживается.']);
    }

    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        callback_json_response(403, ['success' => false, 'error' => 'Сессия истекла. Обновите страницу и попробуйте снова.']);
    }

    $settings = callback_get_settings();

    if (empty($settings['enabled'])) {
        callback_json_response(403, ['success' => false, 'error' => 'Форма отключена.']);
    }

    // Ловушка для ботов: поле скрыто стилями, человек его не заполнит.
    if (trim((string)($_POST['website'] ?? '')) !== '') {
        callback_json_response(200, [
            'success' => true,
            'message' => (string)$settings['success_message'],
        ]);
    }

    // Окно заполнения: метку ставит скрипт при открытии формы.
    $openedAt = (int)($_POST['opened_at'] ?? 0);
    $elapsed = time() - $openedAt;

    if ($openedAt <= 0 || $elapsed < 2 || $elapsed > 3600) {
        callback_json_response(400, ['success' => false, 'error' => 'Форма устарела. Обновите страницу и попробуйте снова.']);
    }

    $phone = callback_phone_digits($_POST['phone'] ?? '');
    $phoneFormat = (string)$settings['phone_format'];
    $digitPattern = callback_phone_digit_pattern($phoneFormat);

    if ($digitPattern !== '') {
        $phoneValid = (bool)preg_match('/^' . $digitPattern . '$/', $phone);
    } else {
        $expectedDigits = callback_phone_expected_digits($phoneFormat);
        $minDigits = $expectedDigits > 0 ? $expectedDigits : 10;
        $maxDigits = $expectedDigits > 0 ? $expectedDigits : 15;
        $phoneValid = strlen($phone) >= $minDigits && strlen($phone) <= $maxDigits;
    }

    if (!$phoneValid) {
        callback_json_response(400, [
            'success' => false,
            'error'   => $phoneFormat !== ''
                ? 'Укажите номер в формате ' . $phoneFormat
                : 'Укажите корректный номер телефона.',
        ]);
    }

    // Ведущую 8 приводим к 7, если формат задан с семёркой.
    if (strlen($phone) === 11 && $phone[0] === '8' && preg_match('/^\+?7/', $phoneFormat)) {
        $phone = '7' . substr($phone, 1);
    }

    $name = callback_clean_text($_POST['name'] ?? '', 100);

    if (!empty($settings['name_required']) && $name === '') {
        callback_json_response(400, ['success' => false, 'error' => 'Укажите имя.']);
    }

    $comment = callback_clean_text($_POST['comment'] ?? '', 1000);
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');

    $items = callback_prune_requests(callback_read_requests());

    if (callback_rate_limited($items, $ip)) {
        callback_json_response(429, ['success' => false, 'error' => 'Слишком много заявок. Попробуйте через час.']);
    }

    $item = [
        'id'         => bin2hex(random_bytes(8)),
        'created_at' => time(),
        'name'       => $name,
        'phone'      => $phone,
        'comment'    => $comment,
        'page'       => callback_request_page(),
        'ip'         => $ip,
        'user_agent' => mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        'status'     => 'new',
    ];

    $items[] = $item;

    if (!callback_write_requests($items)) {
        callback_json_response(500, ['success' => false, 'error' => 'Не удалось сохранить заявку. Попробуйте позже.']);
    }

    // Персональные данные в лог не пишем — только факт заявки.
    // На фронте admin_controller.php не подключён, поэтому logAction может быть недоступна.
    if (function_exists('logAction')) {
        logAction('callback_request', 'Новая заявка на звонок (' . ($item['page'] !== '' ? $item['page'] : 'без страницы') . ')', 'INFO');
    }

    callback_send_notification($item);

    callback_json_response(200, [
        'success' => true,
        'message' => (string)$settings['success_message'],
    ]);
}

// =========================================================================
// ВЫВОД НА САЙТЕ
// =========================================================================

/**
 * Нужно ли выводить кнопку на текущей странице.
 *
 * @return bool
 */
function callback_should_render(): bool {
    $settings = callback_get_settings();

    return !empty($settings['enabled']);
}

/**
 * Подключает стили.
 *
 * @return void
 */
function callback_render_head(): void {
    if (!callback_should_render()) {
        return;
    }

    $stylePath = APP_ROOT . '/css/callback.css';

    if (is_file($stylePath)) {
        echo '<link rel="stylesheet" href="css/callback.css?v=' . (int)@filemtime($stylePath) . '">' . "\n";

        return;
    }

    // Плагин скопирован без установки — берём исходник из папки плагина.
    $inline = @file_get_contents(__DIR__ . '/site/style.css');

    if ($inline !== false) {
        echo '<style>' . $inline . '</style>' . "\n";
    }
}

/**
 * Выводит кнопку, модалку и скрипт.
 *
 * @return void
 */
function callback_render_body(): void {
    if (!callback_should_render()) {
        return;
    }

    $settings = callback_get_settings();
    $positions = callback_positions();
    $position = isset($positions[$settings['position']]) ? $settings['position'] : 'right_bottom';
    $token = (string)($_SESSION['csrf_token'] ?? '');
    $endpoint = callback_endpoint_url();

    $showName = !empty($settings['show_name']);
    $showComment = !empty($settings['show_comment']);
    $phoneFormat = (string)$settings['phone_format'];
    $expectedDigits = callback_phone_expected_digits($phoneFormat);
    $phonePattern = callback_phone_digit_pattern($phoneFormat);
    $privacyUrl = !empty($settings['show_privacy']) ? callback_privacy_url($settings) : '';
    $privacyText = trim((string)$settings['privacy_text']);
    $privacyLabel = trim((string)$settings['privacy_label']);
    $privacyNote = '';

    if ($privacyText !== '') {
        if ($privacyLabel === '') {
            $privacyLabel = 'политикой конфиденциальности';
        }

        if ($privacyUrl !== '') {
            $policy = '<a href="' . e($privacyUrl) . '" target="_blank" rel="noopener">' . e($privacyLabel) . '</a>';
        } else {
            // Пусто — встроенная политика ядра (includes/privacy.php), как в cookie-баннере.
            // Ссылка, а не кнопка: кнопка атомарна и на узком экране переносится
            // целиком, оставляя пустую строку; ссылка ломается как обычный текст.
            $policy = '<a href="#" role="button" class="callback__privacy-link"'
                . ' onclick="openPolicy(\'privacy\'); return false;">'
                . e($privacyLabel) . '</a>';
        }

        $privacyNote = str_replace('{policy}', $policy, nl2br(e($privacyText), false));
    }
    ?>
<div class="callback" data-callback
     data-endpoint="<?php echo e($endpoint); ?>"
     data-csrf="<?php echo e($token); ?>">
    <button type="button" class="callback__fab callback__fab--<?php echo e(str_replace('_', '-', $position)); ?>" data-callback-open aria-expanded="false">
        <span class="icon-phone-call callback__fab-icon" aria-hidden="true"></span>
        <span class="callback__fab-text"><?php echo e($settings['button_label']); ?></span>
    </button>

    <div class="callback__modal" data-callback-modal hidden>
        <div class="callback__overlay" data-callback-close></div>
        <div class="callback__dialog" role="dialog" aria-modal="true" aria-labelledby="callback-title">
            <button type="button" class="callback__close" data-callback-close aria-label="Закрыть">
                <span class="icon-x" aria-hidden="true"></span>
            </button>

            <h2 class="callback__title" id="callback-title"><?php echo e($settings['title']); ?></h2>

            <?php if (trim((string)$settings['subtitle']) !== ''): ?>
                <p class="callback__subtitle"><?php echo e($settings['subtitle']); ?></p>
            <?php endif; ?>

            <form class="callback__form" data-callback-form data-phone-digits="<?php echo (int)$expectedDigits; ?>" data-phone-pattern="<?php echo e($phonePattern); ?>" novalidate>
                <input type="hidden" name="csrf_token" value="<?php echo e($token); ?>">
                <input type="hidden" name="opened_at" value="0">

                <div class="callback__hp" aria-hidden="true">
                    <label>Не заполняйте это поле
                        <input type="text" name="website" value="" tabindex="-1" autocomplete="off">
                    </label>
                </div>

                <label class="callback__field">
                    <span class="callback__label">Телефон <span class="callback__req">*</span></span>
                    <input type="tel" name="phone" inputmode="tel" autocomplete="tel" maxlength="25"
                           placeholder="<?php echo e($phoneFormat); ?>" required>
                </label>

                <?php if ($showName): ?>
                <label class="callback__field">
                    <span class="callback__label">Имя<?php echo !empty($settings['name_required']) ? ' <span class="callback__req">*</span>' : ''; ?></span>
                    <input type="text" name="name" autocomplete="name" maxlength="100"<?php echo !empty($settings['name_required']) ? ' required' : ''; ?>>
                </label>
                <?php endif; ?>

                <?php if ($showComment): ?>
                <label class="callback__field">
                    <span class="callback__label">Комментарий</span>
                    <textarea name="comment" rows="3" maxlength="1000"></textarea>
                </label>
                <?php endif; ?>

                <button type="submit" class="callback__submit" data-callback-submit><?php echo e($settings['submit_text']); ?></button>

                <?php if ($privacyNote !== ''): ?>
                    <p class="callback__privacy"><?php echo $privacyNote; ?></p>
                <?php endif; ?>
            </form>

            <div class="callback__success" data-callback-success hidden>
                <span class="callback__success-icon" aria-hidden="true"><span class="icon-shield-check"></span></span>
                <p class="callback__success-title">Заявка отправлена</p>
                <p class="callback__success-text" data-callback-success-text></p>
            </div>

            <p class="callback__status" data-callback-status role="status" aria-live="polite"></p>
        </div>
    </div>
</div>
    <?php
    $scriptPath = APP_ROOT . '/js/callback.js';

    if (is_file($scriptPath)) {
        echo '<script src="js/callback.js?v=' . (int)@filemtime($scriptPath) . '"></script>' . "\n";

        return;
    }

    $inlineScript = @file_get_contents(__DIR__ . '/site/script.js');

    if ($inlineScript !== false) {
        echo '<script>' . $inlineScript . '</script>' . "\n";
    }
}

// =========================================================================
// АДМИНКА
// =========================================================================

/**
 * Сохранение настроек плагина.
 *
 * @param array $newSettings
 * @return array
 */
function callback_save_settings(array $newSettings): array {
    $defaults = callback_defaults();

    $submitted = save_plugin_settings($newSettings, 'callback_title', [
        'callback.enabled'         => $defaults['enabled'],
        'callback.title'           => $defaults['title'],
        'callback.subtitle'        => $defaults['subtitle'],
        'callback.button_label'    => $defaults['button_label'],
        'callback.submit_text'     => $defaults['submit_text'],
        'callback.success_message' => $defaults['success_message'],
        'callback.phone_format'    => $defaults['phone_format'],
        'callback.position'        => $defaults['position'],
        'callback.show_name'       => $defaults['show_name'],
        'callback.name_required'   => $defaults['name_required'],
        'callback.show_comment'    => $defaults['show_comment'],
        'callback.show_privacy'    => $defaults['show_privacy'],
        'callback.privacy_text'    => $defaults['privacy_text'],
        'callback.privacy_label'   => $defaults['privacy_label'],
        'callback.privacy_url'     => $defaults['privacy_url'],
        'callback.notify_email'    => $defaults['notify_email'],
        'callback.retention_days'  => $defaults['retention_days'],
        'callback.max_records'     => $defaults['max_records'],
    ], [
        'callback_enabled'         => 'callback.enabled',
        'callback_title'           => 'callback.title',
        'callback_subtitle'        => 'callback.subtitle',
        'callback_button_label'    => 'callback.button_label',
        'callback_submit_text'     => 'callback.submit_text',
        'callback_success_message' => 'callback.success_message',
        'callback_phone_format'    => 'callback.phone_format',
        'callback_position'        => 'callback.position',
        'callback_show_name'       => 'callback.show_name',
        'callback_name_required'   => 'callback.name_required',
        'callback_show_comment'    => 'callback.show_comment',
        'callback_show_privacy'    => 'callback.show_privacy',
        'callback_privacy_text'    => 'callback.privacy_text',
        'callback_privacy_label'   => 'callback.privacy_label',
        'callback_privacy_url'     => 'callback.privacy_url',
        'callback_notify_email'    => 'callback.notify_email',
        'callback_retention_days'  => 'callback.retention_days',
        'callback_max_records'     => 'callback.max_records',
    ]);

    // Форма не отправлялась — чужие настройки не трогаем.
    if (!$submitted) {
        return $newSettings;
    }

    $positions = callback_positions();

    $newSettings['callback']['title'] = mb_substr(trim((string)$newSettings['callback']['title']), 0, 120);
    $newSettings['callback']['subtitle'] = mb_substr(trim((string)$newSettings['callback']['subtitle']), 0, 200);
    $newSettings['callback']['button_label'] = mb_substr(trim((string)$newSettings['callback']['button_label']), 0, 60);
    $newSettings['callback']['submit_text'] = mb_substr(trim((string)$newSettings['callback']['submit_text']), 0, 60);
    $newSettings['callback']['success_message'] = mb_substr(trim((string)$newSettings['callback']['success_message']), 0, 300);
    $newSettings['callback']['privacy_text'] = mb_substr(trim((string)$newSettings['callback']['privacy_text']), 0, 300);
    $newSettings['callback']['privacy_label'] = mb_substr(trim((string)$newSettings['callback']['privacy_label']), 0, 120);

    $phoneFormat = trim((string)$newSettings['callback']['phone_format']);
    $phoneFormat = preg_replace('/[^0-9+()\-\s_]/u', '', $phoneFormat) ?? '';

    // Без хотя бы одного места для цифры формат бесполезен.
    if (substr_count($phoneFormat, '_') === 0) {
        $phoneFormat = callback_defaults()['phone_format'];
    }

    $newSettings['callback']['phone_format'] = mb_substr($phoneFormat, 0, 30);

    if (!isset($positions[$newSettings['callback']['position']])) {
        $newSettings['callback']['position'] = 'right_bottom';
    }

    $newSettings['callback']['retention_days'] = max(1, min(365, (int)$newSettings['callback']['retention_days']));
    $newSettings['callback']['max_records'] = max(10, min(5000, (int)$newSettings['callback']['max_records']));

    // Пустой текст отключает кнопку? Нет: заголовок нужен, иначе модалка без имени.
    if ($newSettings['callback']['title'] === '') {
        $newSettings['callback']['title'] = callback_defaults()['title'];
    }

    $privacyUrl = trim((string)$newSettings['callback']['privacy_url']);

    if ($privacyUrl !== '' && !preg_match('#^(https?://|/)#i', $privacyUrl)) {
        $privacyUrl = '/' . ltrim($privacyUrl, '/');
    }

    $newSettings['callback']['privacy_url'] = mb_substr($privacyUrl, 0, 255);

    $notifyEmail = trim((string)$newSettings['callback']['notify_email']);
    $newSettings['callback']['notify_email'] = filter_var($notifyEmail, FILTER_VALIDATE_EMAIL)
        ? $notifyEmail
        : '';

    return $newSettings;
}

/**
 * Обработчик действий в админке: смена статуса, удаление, очистка.
 *
 * @return void
 */
function callback_admin_handle_action(): void {
    if (!isset($_POST['callback_action'])) {
        return;
    }

    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        setFlash('Ошибка безопасности: CSRF-токен невалиден.', 'error');
        header('Location: index.php?tab=callback');
        exit;
    }

    $action = (string)$_POST['callback_action'];
    $id = (string)($_POST['id'] ?? '');
    $items = callback_read_requests();
    $message = '';

    if ($action === 'clear') {
        $items = [];
        $message = 'Журнал заявок очищен.';
    } elseif ($action === 'done_all') {
        foreach ($items as $index => $item) {
            $items[$index]['status'] = 'done';
        }

        $message = 'Все заявки отмечены обработанными.';
    } elseif ($action === 'delete' && $id !== '') {
        $items = array_values(array_filter($items, function ($item) use ($id) {
            return (string)($item['id'] ?? '') !== $id;
        }));
        $message = 'Заявка удалена.';
    } elseif (($action === 'done' || $action === 'new') && $id !== '') {
        foreach ($items as $index => $item) {
            if ((string)($item['id'] ?? '') === $id) {
                $items[$index]['status'] = $action === 'done' ? 'done' : 'new';
            }
        }

        $message = $action === 'done' ? 'Заявка обработана.' : 'Заявка возвращена в новые.';
    }

    if ($message !== '') {
        callback_write_requests(callback_prune_requests($items));
        logAction('callback_admin', $message, 'INFO');
        setFlash($message, 'success');
    }

    header('Location: index.php?tab=callback');
    exit;
}

/**
 * Выгружает заявки в CSV.
 *
 * @return void
 */
function callback_admin_export_csv(): void {
    if (!verifyCsrfToken($_GET['token'] ?? null)) {
        http_response_code(403);
        exit('Ошибка безопасности: CSRF-токен невалиден.');
    }

    $items = callback_prune_requests(callback_read_requests());

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="callback-' . date('Y-m-d') . '.csv"');
    header('Cache-Control: no-store, max-age=0');

    $out = fopen('php://output', 'w');

    if ($out === false) {
        exit;
    }

    // BOM, чтобы Excel не ломал кириллицу.
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Дата', 'Телефон', 'Имя', 'Комментарий', 'Страница', 'Статус', 'IP']);

    foreach ($items as $item) {
        fputcsv($out, [
            date('d.m.Y H:i', (int)($item['created_at'] ?? 0)),
            (string)($item['phone'] ?? ''),
            (string)($item['name'] ?? ''),
            (string)($item['comment'] ?? ''),
            (string)($item['page'] ?? ''),
            ($item['status'] ?? 'new') === 'done' ? 'обработана' : 'новая',
            (string)($item['ip'] ?? ''),
        ]);
    }

    fclose($out);
    exit;
}

// =========================================================================
// ХУКИ
// =========================================================================

// Маршрут приёма заявок.
add_route('/callback', 'callback_handle_request');

// Вывод на сайте.
add_action('render_head_end', 'callback_render_head');
add_action('render_body_end', 'callback_render_body');

// Настройки.
add_filter('save_settings_data', 'callback_save_settings');

// Действия и выгрузка в админке.
add_action('admin_init', function () {
    if (($_GET['tab'] ?? '') !== 'callback') {
        return;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['callback_action'])) {
        callback_admin_handle_action();
    }

    if (($_GET['export'] ?? '') === 'csv') {
        callback_admin_export_csv();
    }

    // Попутно чистим старое, чтобы файл не рос между заявками.
    $items = callback_prune_requests(callback_read_requests());

    if (count($items) !== count(callback_read_requests())) {
        callback_write_requests($items);
    }
});

// Реестр логирования: без регистрации logAction() действие игнорирует.
register_log_action('callback_request', 'Заявка на обратный звонок', 'Обратный звонок', 'phone-call');
register_log_action('callback_admin', 'Действия с заявками', 'Обратный звонок', 'clipboard-list');
register_log_action('callback_mail_error', 'Ошибка письма о заявке', 'Обратный звонок', 'triangle-alert');
