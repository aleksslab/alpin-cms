/**
 * Плагин «Обратный звонок»: открытие модалки и отправка заявки.
 * Модуль может встретиться на странице несколько раз — обрабатываем все.
 */
(function () {
    'use strict';

    var MIN_FILL_SECONDS = 2;

    /**
     * Инициализирует один экземпляр кнопки.
     *
     * @param {HTMLElement} root
     * @returns {void}
     */
    function initInstance(root) {
        if (!root || root.dataset.callbackReady === '1') {
            return;
        }

        var openBtn = root.querySelector('[data-callback-open]');
        var modal = root.querySelector('[data-callback-modal]');
        var form = root.querySelector('[data-callback-form]');
        var status = root.querySelector('[data-callback-status]');
        var success = root.querySelector('[data-callback-success]');
        var successText = root.querySelector('[data-callback-success-text]');
        var openedAt = root.querySelector('input[name="opened_at"]');
        var submitBtn = root.querySelector('[data-callback-submit]');

        if (!openBtn || !modal || !form) {
            return;
        }

        root.dataset.callbackReady = '1';

        var isOpen = false;
        var isSending = false;
        var endpoint = root.dataset.endpoint || '/callback';

        /**
         * Показывает сообщение под формой.
         *
         * @param {string} text
         * @param {string} state
         * @returns {void}
         */
        function setStatus(text, state) {
            if (!status) {
                return;
            }

            status.textContent = text;
            if (state) {
                status.dataset.state = state;
            } else {
                delete status.dataset.state;
            }
        }

        /**
         * Открывает модалку и ставит метку времени для проверки окна заполнения.
         *
         * @returns {void}
         */
        function openModal() {
            if (isOpen) {
                return;
            }

            if (openedAt) {
                openedAt.value = String(Math.floor(Date.now() / 1000));
            }

            modal.classList.remove('is-sent');
            modal.hidden = false;
            isOpen = true;
            document.documentElement.classList.add('callback-lock');
            openBtn.setAttribute('aria-expanded', 'true');

            // Принудительный reflow: без него браузер может склеить смену
            // display и класса и transition не проиграется. requestAnimationFrame
            // здесь не годится — в фоновой вкладке он не срабатывает.
            void modal.offsetWidth;
            modal.classList.add('is-open');

            var firstField = modal.querySelector('input[name="phone"]');

            if (firstField) {
                window.setTimeout(function () {
                    firstField.focus();
                }, 80);
            }
        }

        /**
         * Закрывает модалку и возвращает форму в исходное состояние.
         *
         * @returns {void}
         */
        function closeModal() {
            if (!isOpen) {
                return;
            }

            modal.classList.remove('is-open');
            modal.classList.remove('is-sent');
            isOpen = false;
            document.documentElement.classList.remove('callback-lock');
            openBtn.setAttribute('aria-expanded', 'false');

            window.setTimeout(function () {
                modal.hidden = true;

                // После успешной отправки форма была скрыта — возвращаем её.
                if (form.hidden) {
                    form.hidden = false;
                    form.reset();
                }

                if (success) {
                    success.hidden = true;
                }

                setStatus('', '');
            }, 200);
        }

        openBtn.addEventListener('click', openModal);

        modal.querySelectorAll('[data-callback-close]').forEach(function (el) {
            el.addEventListener('click', closeModal);
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && isOpen) {
                closeModal();
            }
        });

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            if (isSending) {
                return;
            }

            var phoneField = form.querySelector('input[name="phone"]');
            var phoneDigits = phoneField ? phoneField.value.replace(/\D+/g, '') : '';
            var expectedDigits = Number(form.dataset.phoneDigits || 0);
            var digitPattern = form.dataset.phonePattern || '';
            var isPhoneValid;

            if (digitPattern !== '') {
                try {
                    isPhoneValid = new RegExp('^' + digitPattern + '$').test(phoneDigits);
                } catch (e) {
                    isPhoneValid = false;
                }
            } else {
                var minDigits = expectedDigits > 0 ? expectedDigits : 10;
                var maxDigits = expectedDigits > 0 ? expectedDigits : 15;
                isPhoneValid = phoneDigits.length >= minDigits && phoneDigits.length <= maxDigits;
            }

            if (!isPhoneValid) {
                if (phoneField) {
                    phoneField.setAttribute('aria-invalid', 'true');
                    phoneField.focus();
                }

                setStatus(
                    phoneField && phoneField.placeholder
                        ? 'Укажите номер в формате ' + phoneField.placeholder
                        : 'Проверьте номер телефона.',
                    'error'
                );
                return;
            }

            if (phoneField) {
                phoneField.removeAttribute('aria-invalid');
            }

            // Метку могли не поставить (модалку открыли до загрузки скрипта).
            if (openedAt && Number(openedAt.value) <= 0) {
                openedAt.value = String(Math.floor(Date.now() / 1000) - MIN_FILL_SECONDS);
            }

            isSending = true;

            if (submitBtn) {
                submitBtn.disabled = true;
            }

            setStatus('Отправляем…', '');

            window.fetch(endpoint, {
                method: 'POST',
                body: new FormData(form),
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(function (response) {
                    return response.json().catch(function () {
                        return { success: false, error: 'Неожиданный ответ сервера.' };
                    });
                })
                .then(function (data) {
                    if (data && data.success) {
                        var message = data.message || 'Спасибо! Заявка принята.';
                        form.hidden = true;
                        setStatus('', '');
                        modal.classList.add('is-sent');

                        if (success) {
                            if (successText) {
                                successText.textContent = message;
                            }

                            success.hidden = false;
                        } else {
                            setStatus(message, 'ok');
                        }

                        return;
                    }

                    setStatus((data && data.error) || 'Не удалось отправить заявку.', 'error');
                })
                .catch(function () {
                    setStatus('Ошибка сети. Попробуйте ещё раз.', 'error');
                })
                .then(function () {
                    isSending = false;

                    if (submitBtn) {
                        submitBtn.disabled = false;
                    }
                });
        });
    }

    /**
     * Запускает инициализацию после готовности DOM.
     *
     * @returns {void}
     */
    function boot() {
        document.querySelectorAll('[data-callback]').forEach(initInstance);

        // Кнопку в нижних позициях поднимает реестр ядра: она встаёт над
        // «наверх» и кнопками cookie, а без них остаётся на базовом отступе.
        if (window.FloatStack) {
            document.querySelectorAll('.callback__fab--left-bottom, .callback__fab--right-bottom').forEach(function (fab) {
                window.FloatStack.register(fab, {
                    side: fab.classList.contains('callback__fab--left-bottom') ? 'left' : 'right',
                    above: true
                });
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
