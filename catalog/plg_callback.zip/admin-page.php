<?php
/**
 * Админка плагина «Обратный звонок»: настройки и журнал заявок.
 */

if (!defined('APP_ROOT') || empty($_SESSION['admin_auth'])) {
    die('Доступ запрещен');
}

$settings = callback_get_settings();
$token = (string)($_SESSION['csrf_token'] ?? '');
$state = callback_get_state();
$positions = callback_positions();

$allRequests = callback_prune_requests(callback_read_requests());
$total = count($allRequests);
$newCount = 0;

foreach ($allRequests as $request) {
    if (($request['status'] ?? 'new') !== 'done') {
        $newCount++;
    }
}

$perPage = 25;
$pages = max(1, (int)ceil($total / $perPage));
$page = max(1, min($pages, (int)($_GET['page'] ?? 1)));
$pageRequests = array_slice(array_reverse($allRequests), ($page - 1) * $perPage, $perPage);

$mailReady = function_exists('mail_agent_is_configured') && mail_agent_is_configured();
$mailRecipient = trim((string)$settings['notify_email']);

if ($mailRecipient === '') {
    $mailConfig = function_exists('get_mail_config') ? get_mail_config() : [];
    $mailRecipient = (string)($mailConfig['to_email'] ?? '');
}

$linkToMail = 'index.php?tab=config_vars';
?>

<div class="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-6">
    <div>
        <h1 class="text-3xl font-bold text-slate-800 mb-2">Обратный звонок</h1>
        <p class="text-slate-500 text-sm">Плавающая кнопка на сайте и журнал заявок</p>
    </div>
    <div class="flex items-center gap-2">
        <a href="index.php?tab=callback&amp;export=csv&amp;token=<?php echo e($token); ?>"
           class="px-4 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-all text-sm inline-flex items-center gap-2">
            <span class="icon-download"></span>
            CSV
        </a>
    </div>
</div>

<?php echo renderFlash(); ?>

<?php if (!$mailReady): ?>
<div class="mb-6 flex flex-col sm:flex-row sm:items-center gap-3 bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3">
    <span class="icon-mail-x text-amber-500 text-lg leading-none"></span>
    <div class="text-sm text-amber-800 flex-1">
        <p class="font-bold">Уведомления по почте не отправляются</p>
        <p class="text-xs mt-1">
            Почтовый агент не настроен. Заявки сохраняются в журнале — письма не приходят.
        </p>
    </div>
    <a href="<?php echo e($linkToMail); ?>"
       class="px-4 py-2.5 bg-white border border-amber-200 text-amber-800 font-bold rounded-xl hover:bg-amber-100 transition-all text-sm text-center whitespace-nowrap">
        Настроить почту
    </a>
</div>
<?php elseif (!empty($state['last_mail_error'])): ?>
<div class="mb-6 bg-rose-50 border border-rose-200 rounded-2xl px-4 py-3 text-sm text-rose-800">
    <p class="font-bold">Последнее письмо не отправлено</p>
    <p class="text-xs mt-1"><?php echo e((string)$state['last_mail_error']); ?></p>
    <?php if (!empty($state['last_mail_at'])): ?>
        <p class="text-[10px] mt-1 text-rose-600"><?php echo e(date('d.m.Y H:i', (int)$state['last_mail_at'])); ?></p>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- НАСТРОЙКИ -->
<div class="bg-white rounded-2xl border border-slate-200 p-6 mb-8">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/60 pb-3 mb-4">
        <h3 class="text-lg font-bold text-slate-800">Настройки кнопки и формы</h3>
        <p class="text-xs text-slate-400">
            Уведомления: <?php echo e($mailRecipient !== '' ? $mailRecipient : 'не задан e-mail получателя'); ?>
        </p>
    </div>

    <form method="POST" action="index.php?tab=config_vars" class="space-y-4">
        <input type="hidden" name="csrf_token" value="<?php echo e($token); ?>">
        <input type="hidden" name="save_settings" value="1">
        <input type="hidden" name="return_url" value="index.php?tab=callback">
        <input type="hidden" name="settings_source" value="плагина">

        <div class="space-y-4">
            <div>
                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">Кнопка на сайте</div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
                    <div class="editor-field flex items-center pt-5">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="hidden" name="callback_enabled" value="0">
                            <input type="checkbox" name="callback_enabled" value="1" <?php echo !empty($settings['enabled']) ? 'checked' : ''; ?>>
                            <span class="text-sm font-medium text-slate-700">Показывать кнопку на сайте</span>
                        </label>
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Позиция кнопки</label>
                        <select name="callback_position" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                            <?php foreach ($positions as $value => $label): ?>
                                <option value="<?php echo e($value); ?>" <?php echo $settings['position'] === $value ? 'selected' : ''; ?>><?php echo e($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Надпись на кнопке</label>
                        <input type="text" name="callback_button_label" maxlength="60" value="<?php echo e($settings['button_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                </div>
            </div>

            <div class="border-t border-slate-200/60 pt-4">
                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">Форма</div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Заголовок формы</label>
                        <input type="text" name="callback_title" maxlength="120" value="<?php echo e($settings['title']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Подзаголовок</label>
                        <input type="text" name="callback_subtitle" maxlength="200" value="<?php echo e($settings['subtitle']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Текст кнопки отправки</label>
                        <input type="text" name="callback_submit_text" maxlength="60" value="<?php echo e($settings['submit_text']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Формат номера</label>
                        <input type="text" name="callback_phone_format" maxlength="30" value="<?php echo e($settings['phone_format']); ?>" placeholder="+7 (___) ___-__-__" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:border-[var(--primary-color)]">
                        <p class="text-[10px] text-slate-400 mt-1">
                            Подчёркивания — места для цифр. Формат выводится плейсхолдером и проверяется при отправке.
                        </p>
                    </div>
                </div>
                <div class="editor-field mt-3">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Сообщение после отправки</label>
                    <input type="text" name="callback_success_message" maxlength="300" value="<?php echo e($settings['success_message']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                </div>
            </div>

            <div class="border-t border-slate-200/60 pt-4">
                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">Поля формы</div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px">
                    <div class="editor-field">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="hidden" name="callback_show_name" value="0">
                            <input type="checkbox" name="callback_show_name" value="1" <?php echo !empty($settings['show_name']) ? 'checked' : ''; ?>>
                            <span class="text-sm font-medium text-slate-700">Поле «Имя»</span>
                        </label>
                    </div>
                    <div class="editor-field">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="hidden" name="callback_name_required" value="0">
                            <input type="checkbox" name="callback_name_required" value="1" <?php echo !empty($settings['name_required']) ? 'checked' : ''; ?>>
                            <span class="text-sm font-medium text-slate-700">Имя обязательно</span>
                        </label>
                    </div>
                    <div class="editor-field">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="hidden" name="callback_show_comment" value="0">
                            <input type="checkbox" name="callback_show_comment" value="1" <?php echo !empty($settings['show_comment']) ? 'checked' : ''; ?>>
                            <span class="text-sm font-medium text-slate-700">Поле «Комментарий»</span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="border-t border-slate-200/60 pt-4">
                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">Согласие с политикой</div>
                <div class="editor-field">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="hidden" name="callback_show_privacy" value="0">
                        <input type="checkbox" name="callback_show_privacy" value="1" <?php echo !empty($settings['show_privacy']) ? 'checked' : ''; ?>>
                        <span class="text-sm font-medium text-slate-700">Показывать примечание под кнопкой</span>
                    </label>
                </div>
                <div class="editor-field mt-3">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Текст согласия</label>
                    <textarea name="callback_privacy_text" rows="2" maxlength="300" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]"><?php echo e($settings['privacy_text']); ?></textarea>
                    <p class="text-[10px] text-slate-400 mt-1">
                        <code class="font-mono bg-white px-1 rounded border border-slate-200">{policy}</code> заменяется на ссылку. HTML запрещён.
                    </p>
                </div>
                <div class="mt-3" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Подпись ссылки</label>
                        <input type="text" name="callback_privacy_label" maxlength="120" value="<?php echo e($settings['privacy_label']); ?>" placeholder="политикой конфиденциальности" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Адрес политики</label>
                        <input type="text" name="callback_privacy_url" maxlength="255" value="<?php echo e($settings['privacy_url']); ?>" placeholder="<?php echo e(callback_privacy_url($settings) !== '' ? callback_privacy_url($settings) : '/privacy'); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                        <p class="text-[10px] text-slate-400 mt-1">
                            <?php if (callback_privacy_url($settings) !== ''): ?>
                                Сейчас: <?php echo e(callback_privacy_url($settings)); ?> — пусто, значит берётся из cookie-баннера или cookie-согласия
                            <?php else: ?>
                                Пусто — откроется встроенная политика сайта (`includes/privacy.php`)
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="border-t border-slate-200/60 pt-4">
                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">Уведомления и хранение</div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px">
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">E-mail для уведомлений</label>
                        <input type="email" name="callback_notify_email" maxlength="120" value="<?php echo e($settings['notify_email']); ?>" placeholder="По умолчанию — получатель агента" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Срок хранения, дней</label>
                        <input type="number" name="callback_retention_days" min="1" max="365" value="<?php echo e($settings['retention_days']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Максимум записей</label>
                        <input type="number" name="callback_max_records" min="10" max="5000" value="<?php echo e($settings['max_records']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                </div>
                <p class="text-[10px] text-slate-400 mt-2">
                    Заполненный адрес перекрывает получателя из почтового агента. Пусто — письмо уйдёт на адрес агента.
                </p>
            </div>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="px-6 py-2.5 bg-[var(--primary-color)] text-white font-bold rounded-xl hover:bg-[var(--primary-dark)] transition-all text-sm">
                Сохранить настройки
            </button>
        </div>
    </form>
</div>

<!-- ЖУРНАЛ ЗАЯВОК -->
<div class="bg-white rounded-2xl border border-slate-200 p-6">
    <div class="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 border-b border-slate-200/60 pb-3 mb-4">
        <h3 class="text-lg font-bold text-slate-800">
            Журнал заявок
            <span class="text-xs font-normal text-slate-400 ml-2">
                <?php echo (int)$total; ?> всего, <?php echo (int)$newCount; ?> новых
            </span>
        </h3>

        <?php if ($total > 0): ?>
        <div class="flex flex-wrap items-center gap-2">
            <?php if ($newCount > 0): ?>
            <form method="POST" action="index.php?tab=callback">
                <input type="hidden" name="csrf_token" value="<?php echo e($token); ?>">
                <input type="hidden" name="callback_action" value="done_all">
                <button type="submit" class="px-4 py-2 text-sm font-bold text-emerald-700 border border-emerald-200 rounded-xl hover:bg-emerald-50 transition-all">
                    Отметить все обработанными
                </button>
            </form>
            <?php endif; ?>
            <form method="POST" action="index.php?tab=callback" onsubmit="return confirm('Удалить все заявки? Действие необратимо.');">
                <input type="hidden" name="csrf_token" value="<?php echo e($token); ?>">
                <input type="hidden" name="callback_action" value="clear">
                <button type="submit" class="px-4 py-2 text-sm font-bold text-rose-600 border border-rose-200 rounded-xl hover:bg-rose-50 transition-all">
                    Очистить журнал
                </button>
            </form>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($total === 0): ?>
        <div class="text-center py-12 text-slate-400">
            <span class="icon-inbox text-4xl block mb-3 text-slate-300"></span>
            <p class="text-sm">Заявок пока нет.</p>
            <p class="text-xs mt-1">Они появятся здесь, как только посетитель отправит форму.</p>
        </div>
    <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-wider bg-slate-50">
                        <th class="py-3 px-4">Дата</th>
                        <th class="py-3 px-4">Телефон</th>
                        <th class="py-3 px-4">Имя / комментарий</th>
                        <th class="py-3 px-4">Страница</th>
                        <th class="py-3 px-4">Статус</th>
                        <th class="py-3 px-4 text-right">Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pageRequests as $request): ?>
                        <?php
                        $requestId = (string)($request['id'] ?? '');
                        $isDone = ($request['status'] ?? 'new') === 'done';
                        ?>
                        <tr class="border-b border-slate-100 hover:bg-slate-50 transition-colors align-top">
                            <td class="py-3 px-4 text-xs text-slate-500 whitespace-nowrap">
                                <?php echo e(date('d.m.Y H:i', (int)($request['created_at'] ?? 0))); ?>
                            </td>
                            <td class="py-3 px-4 font-semibold text-slate-800 whitespace-nowrap">
                                <a href="tel:<?php echo e((string)($request['phone'] ?? '')); ?>" class="hover:text-[var(--primary-color)]">
                                    <?php echo e(callback_format_phone((string)($request['phone'] ?? ''))); ?>
                                </a>
                            </td>
                            <td class="py-3 px-4 text-sm text-slate-600 max-w-xs">
                                <?php if (!empty($request['name'])): ?>
                                    <div class="font-semibold text-slate-700"><?php echo e((string)$request['name']); ?></div>
                                <?php endif; ?>
                                <?php if (!empty($request['comment'])): ?>
                                    <div class="text-xs text-slate-500 mt-0.5"><?php echo nl2br(e((string)$request['comment'])); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 px-4 text-xs text-slate-500 max-w-[180px] truncate" title="<?php echo e((string)($request['page'] ?? '')); ?>">
                                <?php echo e((string)($request['page'] ?? '—')); ?>
                            </td>
                            <td class="py-3 px-4">
                                <?php if ($isDone): ?>
                                    <span class="text-[10px] bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-full">обработана</span>
                                <?php else: ?>
                                    <span class="text-[10px] bg-amber-50 text-amber-600 px-2 py-0.5 rounded-full">новая</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 px-4">
                                <div class="flex items-center justify-end gap-1">
                                    <form method="POST" action="index.php?tab=callback">
                                        <input type="hidden" name="csrf_token" value="<?php echo e($token); ?>">
                                        <input type="hidden" name="id" value="<?php echo e($requestId); ?>">
                                        <input type="hidden" name="callback_action" value="<?php echo $isDone ? 'new' : 'done'; ?>">
                                        <button type="submit" class="w-8 h-8 rounded-lg flex items-center justify-center border border-slate-200 text-slate-500 hover:text-emerald-600 hover:border-emerald-200 transition-all" title="<?php echo $isDone ? 'Вернуть в новые' : 'Отметить обработанной'; ?>">
                                            <span class="icon-<?php echo $isDone ? 'rotate-ccw' : 'check'; ?> text-sm"></span>
                                        </button>
                                    </form>
                                    <form method="POST" action="index.php?tab=callback" onsubmit="return confirm('Удалить заявку?');">
                                        <input type="hidden" name="csrf_token" value="<?php echo e($token); ?>">
                                        <input type="hidden" name="id" value="<?php echo e($requestId); ?>">
                                        <input type="hidden" name="callback_action" value="delete">
                                        <button type="submit" class="w-8 h-8 rounded-lg flex items-center justify-center border border-slate-200 text-slate-500 hover:text-rose-600 hover:border-rose-200 transition-all" title="Удалить">
                                            <span class="icon-trash-2 text-sm"></span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($pages > 1): ?>
            <div class="flex items-center justify-between pt-4 border-t border-slate-100 mt-2">
                <p class="text-xs text-slate-400">Страница <?php echo (int)$page; ?> из <?php echo (int)$pages; ?></p>
                <div class="flex items-center gap-2">
                    <?php if ($page > 1): ?>
                        <a href="index.php?tab=callback&amp;page=<?php echo (int)($page - 1); ?>" class="px-3 py-1.5 text-sm border border-slate-200 rounded-lg hover:bg-slate-50 transition-all">Назад</a>
                    <?php endif; ?>
                    <?php if ($page < $pages): ?>
                        <a href="index.php?tab=callback&amp;page=<?php echo (int)($page + 1); ?>" class="px-3 py-1.5 text-sm border border-slate-200 rounded-lg hover:bg-slate-50 transition-all">Вперёд</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <p class="text-[10px] text-slate-400 mt-4">
            Старые заявки удаляются автоматически: хранятся <?php echo (int)$settings['retention_days']; ?> дней,
            но не больше <?php echo (int)$settings['max_records']; ?> записей.
        </p>
    <?php endif; ?>
</div>
