<?php
/**
 * Плагин: Логи системы
 *
 * UI просмотра логов, AJAX get_logs, сохранение настроек через фильтр.
 * Ядро (logAction, rotateLog, getLogSettings, ensureLogsDir) — в admin_controller.php.
 * Список действий — в реестре ядра (register_log_action / get_log_actions).
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

/**
 * Парсит строку лога в массив.
 *
 * @param string $line
 * @return array|null
 */
function parseLogLine(string $line): ?array {
    $pattern = '/\[([^\]]+)\]\s+\[([^\]]+)\]\s+\[([^\]]+)\]\s+\[([^\]]+)\]\s+([^:]+):\s+(.+)/';

    if (preg_match($pattern, trim($line), $matches)) {
        return [
            'timestamp' => $matches[1],
            'level'     => $matches[2],
            'user'      => $matches[3],
            'ip'        => $matches[4],
            'action'    => $matches[5],
            'message'   => $matches[6],
        ];
    }

    return null;
}

/**
 * AJAX-обработчик: возвращает отфильтрованный список логов.
 *
 * @return void
 */
function handleGetLogs(): void {
    header('Content-Type: application/json; charset=utf-8');

    $settings = getLogSettings();
    $logDir = trim($settings['storage_path'] ?? '') ?: CMS_LOGS_DIR;
    $logDir = rtrim($logDir, '/\\') . DIRECTORY_SEPARATOR;
    $logFile = $logDir . 'admin.log';

    $filterLevel  = $_GET['level'] ?? '';
    $filterAction = $_GET['action'] ?? '';
    $search       = $_GET['search'] ?? '';
    $page         = max(1, intval($_GET['page'] ?? 1));
    $perPage      = max(1, min(200, intval($_GET['per_page'] ?? 50)));

    $logs = [];
    if (file_exists($logFile)) {
        $lines = file($logFile);
        if (is_array($lines)) {
            $lines = array_reverse($lines);

            foreach ($lines as $line) {
                $parsed = parseLogLine($line);
                if (!$parsed) continue;

                if ($filterLevel && $parsed['level'] !== $filterLevel) continue;
                if ($filterAction && strpos($parsed['action'], $filterAction) === false) continue;
                if ($search && stripos($line, $search) === false) continue;

                $logs[] = $parsed;
            }
        }
    }

    $total      = count($logs);
    $totalPages = (int)ceil($total / $perPage);
    $offset     = ($page - 1) * $perPage;
    $logs       = array_slice($logs, $offset, $perPage);

    echo json_encode([
        'logs'       => $logs,
        'total'      => $total,
        'page'       => $page,
        'totalPages' => $totalPages,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// =========================================================================
// ХУКИ
// =========================================================================

// 1. Инициализация: перехватить AJAX get_logs
add_action('admin_init', function() {
    if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_logs'
        && isset($_GET['tab']) && $_GET['tab'] === 'logs'
    ) {
        handleGetLogs();
    }
});

// 2. Сохранение настроек через фильтр save_settings_data
//    (защита от затирания при следующем handleSaveSettings)
add_filter('save_settings_data', function($newSettings) {
    // Дефолты берём из ядра, чтобы не дублировать значения
    $logDefaults = getLogSettings();

    // Триггер: форма логирования отправлена (поле storage_path есть в форме).
    // Скалярные поля сохраняет хелпер, размер и список действий — ниже.
    $submitted = save_plugin_settings($newSettings, 'storage_path', [
        'log_settings.log_enabled'  => $logDefaults['log_enabled'],
        'log_settings.storage_path' => $logDefaults['storage_path'],
        'log_settings.keep_count'   => $logDefaults['keep_count'],
    ], [
        'log_enabled'  => 'log_settings.log_enabled',
        'storage_path' => 'log_settings.storage_path',
        'keep_count'   => 'log_settings.keep_count',
    ]);

    // Форма не отправлялась — блок настроек логирования не трогаем
    if (!$submitted) {
        $newSettings['log_settings'] = getSettingsData()['log_settings'] ?? [];
        return $newSettings;
    }

    // Все ключи из реестра, true/false по факту чекбокса
    $actions = [];
    foreach (get_log_actions() as $key => $label) {
        $actions[$key] = !empty($_POST['log_actions'][$key]);
    }

    // Размер хранится в байтах, форма шлёт мегабайты
    $newSettings['log_settings']['storage_path'] = trim($_POST['storage_path'] ?? '') ?: CMS_LOGS_DIR;
    $newSettings['log_settings']['max_size']     = max(1, intval($_POST['max_size'] ?? 5)) * 1024 * 1024;
    $newSettings['log_settings']['keep_count']   = max(1, min(50, intval($_POST['keep_count'] ?? 10)));
    $newSettings['log_settings']['log_actions']  = $actions;

    return $newSettings;
});

// 3. При удалении плагина сбрасываем только список действий —
//    путь, лимиты и размер остаются. Новые действия снова включаются по умолчанию.
add_action('plugin_before_delete', function($id) {
    if ($id === 'logs') {
        $settings = getSettingsData();
        if (isset($settings['log_settings']['log_actions'])) {
            unset($settings['log_settings']['log_actions']);
            saveData('settings', $settings);
        }
    }
});
