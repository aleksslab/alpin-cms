<?php
/**
 * Плагин: Логи системы
 *
 * AJAX-просмотр логов, настройки логирования.
 * Ядро (logAction, rotateLog, getLogSettings) — остаётся в admin_controller.php.
 * Плагин даёт UI + перехватывает AJAX get_logs + сохраняет настройки через фильтр.
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

/**
 * Гарантирует существование папки логов (по пути из настроек или CMS_LOGS_DIR) + .htaccess.
 * Вызывается на admin_init.
 *
 * @return void
 */
function ensureLogsDir(): void {
    $settings = getLogSettings();
    $logDir = trim($settings['storage_path'] ?? '') ?: CMS_LOGS_DIR;

    // Нормализуем trailing separator
    $logDir = rtrim($logDir, '/\\') . DIRECTORY_SEPARATOR;

    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }

    // .htaccess — только если папка внутри сайта (вне сайта не нужно)
    $realRoot = realpath(APP_ROOT);
    $realLogs = realpath($logDir);
    if ($realRoot !== false && $realLogs !== false && strpos($realLogs, $realRoot) === 0) {
        $htaccess = $logDir . '.htaccess';
        if (!file_exists($htaccess)) {
            $data = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n"
                  . "<IfModule !mod_authz_core.c>\n    Order Deny,Allow\n    Deny from all\n</IfModule>\n";
            @file_put_contents($htaccess, $data);
        }
    }
}

/**
 * Возвращает список всех возможных действий для логирования.
 *
 * ВАЖНО: этот реестр — источник правды для фильтра в UI и для настроек
 * «какие действия логировать». Если разработчик добавляет новый вызов
 * logAction('new_action', ...) — он ОБЯЗАН добавить 'new_action' сюда.
 * Иначе действие не будет логироваться (logAction проверяет log_actions).
 *
 * @return array [action_key => label]
 */
function getLogActions(): array {
    return [
        // Страницы
        'page_save'            => 'Сохранение страницы',
        'page_trash'           => 'Перемещение страницы в корзину',
        'page_clone'           => 'Клонирование страницы',
        'page_set_home'        => 'Назначение главной страницы',
        'page_publish'         => 'Автопубликация страницы',
        'page_archive'         => 'Автоснятие страницы с публикации',
        'page_restore'         => 'Откат страницы к версии',

        // Меню
        'menu_save'            => 'Сохранение меню',
        'menu_trash'           => 'Перемещение меню в корзину',
        'menu_set_main'        => 'Назначение главного меню',

        // История
        'page_history_delete'  => 'Удаление версии истории',
        'page_history_clear'   => 'Очистка истории страницы',
        'history_clear'        => 'Очистка всей истории',

        // Корзина
        'trash_restore'        => 'Восстановление из корзины',
        'trash_delete'         => 'Окончательное удаление из корзины',
        'trash_clear'          => 'Очистка корзины',

        // Настройки
        'settings_save'        => 'Сохранение настроек сайта',
        'security_save'        => 'Сохранение настроек безопасности',

        // SEO
        'seo_regenerate'       => 'Пересборка SEO-файлов',

        // Бэкапы
        'backup_create'        => 'Создание бэкапа',
        'backup_restore'       => 'Восстановление из бэкапа',
        'backup_delete'        => 'Удаление бэкапа',

        // Файлы
        'file_upload'          => 'Загрузка файлов',
        'file_delete'          => 'Удаление файлов',
        'file_edit'            => 'Редактирование файлов',
        'file_rename'          => 'Переименование файлов',
        'file_chmod'           => 'Изменение прав доступа',
        'file_create_dir'      => 'Создание папки',
        'file_create_file'     => 'Создание файла',
        'file_list'            => 'Просмотр списка файлов',
        'file_access'          => 'Доступ к файлу',

        // Модули
        'module_install'       => 'Установка модуля',
        'module_delete'        => 'Удаление модуля',
        'module_update'        => 'Обновление модуля',
        'module_unpack'        => 'Распаковка модуля',
        'module_settings'      => 'Просмотр настроек модуля',
        
        // Плагины
        'plugin_install' => 'Установка плагина',
        'plugin_update'  => 'Обновление плагина',
        'plugin_delete'  => 'Удаление плагина',
        'plugin_toggle'  => 'Включение/выключение плагина',

        // Медиа
        'media_webp_delete'    => 'Удаление .webp-файлов',

        // Авторизация
        'auth_login'           => 'Вход в админку',
        'auth_logout'          => 'Выход из админки',
        'auth_failed'          => 'Неудачная попытка входа',
    ];
}

/**
 * Парсит строку лога в массив.
 *
 * @param string $line
 * @return array|null
 */
function parseLogLine(string $line): ?array {
    $pattern = '/\[([^\]]+)\]\s+\[([^\]]+)\]\s+\[([^\]]+)\]\s+\[([^\]]+)\]\s+([^:]+):\s+(.+)/';

    if (preg_match($pattern, trim($line), $matches)) {
        return [
            'timestamp' => $matches[1],
            'level'     => $matches[2],
            'user'      => $matches[3],
            'ip'        => $matches[4],
            'action'    => $matches[5],
            'message'   => $matches[6],
        ];
    }

    return null;
}

/**
 * AJAX-обработчик: возвращает отфильтрованный список логов.
 *
 * @return void
 */
function handleGetLogs(): void {
    header('Content-Type: application/json; charset=utf-8');

    $settings = getLogSettings();
    $logDir = trim($settings['storage_path'] ?? '') ?: CMS_LOGS_DIR;
    $logDir = rtrim($logDir, '/\\') . DIRECTORY_SEPARATOR;
    $logFile = $logDir . 'admin.log';

    $filterLevel  = $_GET['level'] ?? '';
    $filterAction = $_GET['action'] ?? '';
    $search       = $_GET['search'] ?? '';
    $page         = max(1, intval($_GET['page'] ?? 1));
    $perPage      = max(1, min(200, intval($_GET['per_page'] ?? 50)));

    $logs = [];
    if (file_exists($logFile)) {
        $lines = file($logFile);
        if (is_array($lines)) {
            $lines = array_reverse($lines);

            foreach ($lines as $line) {
                $parsed = parseLogLine($line);
                if (!$parsed) continue;

                if ($filterLevel && $parsed['level'] !== $filterLevel) continue;
                if ($filterAction && strpos($parsed['action'], $filterAction) === false) continue;
                if ($search && stripos($line, $search) === false) continue;

                $logs[] = $parsed;
            }
        }
    }

    $total      = count($logs);
    $totalPages = (int)ceil($total / $perPage);
    $offset     = ($page - 1) * $perPage;
    $logs       = array_slice($logs, $offset, $perPage);

    echo json_encode([
        'logs'       => $logs,
        'total'      => $total,
        'page'       => $page,
        'totalPages' => $totalPages,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// =========================================================================
// ХУКИ
// =========================================================================

// 1. Инициализация: создать папку логов, перехватить AJAX get_logs
add_action('admin_init', function() {
    // Папка логов + .htaccess
    ensureLogsDir();

    // AJAX: get_logs
    if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_logs'
        && isset($_GET['tab']) && $_GET['tab'] === 'logs'
    ) {
        handleGetLogs();
    }
});

// 2. Сохранение настроек через фильтр save_settings_data
//    (защита от затирания при следующем handleSaveSettings)
add_filter('save_settings_data', function($newSettings) {
    $current = getSettingsData();

    // Триггер: форма логирования отправлена (поле storage_path есть в форме)
    if (isset($_POST['storage_path'])) {
        // Все ключи из реестра, true/false по факту чекбокса
        $actions = [];
        foreach (getLogActions() as $key => $label) {
            $actions[$key] = !empty($_POST['log_actions'][$key]);
        }

        $newSettings['log_settings'] = [
            'log_enabled'  => isset($_POST['log_enabled']) && $_POST['log_enabled'] == '1',
            'storage_path' => trim($_POST['storage_path'] ?? '') ?: CMS_LOGS_DIR,
            'max_size'     => max(1, intval($_POST['max_size'] ?? 5)) * 1024 * 1024,
            'keep_count'   => max(1, min(50, intval($_POST['keep_count'] ?? 10))),
            'log_actions'  => $actions,
        ];
    } else {
        // Форма не отправлялась — сохраняем старые настройки
        $newSettings['log_settings'] = $current['log_settings'] ?? [];
    }

    return $newSettings;
});