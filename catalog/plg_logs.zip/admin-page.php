<?php
if (!defined('APP_ROOT') || empty($_SESSION['admin_auth'])) {
    die('Доступ запрещен');
}

$settings = getLogSettings();
$token = $_SESSION['csrf_token'] ?? '';
$allActions = get_log_actions();
$filterLevel = $_GET['level'] ?? '';
$filterAction = $_GET['action'] ?? '';
$search = $_GET['search'] ?? '';
?>

<!-- ЗАГОЛОВОК -->
<div class="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-6">
    <div>
        <h1 class="text-3xl font-bold text-slate-800 mb-2">Логи системы</h1>
        <p class="text-slate-500 text-sm">Просмотр и настройка журнала действий администратора</p>
    </div>
</div>

<!-- ФОРМА НАСТРОЕК -->
<div class="bg-white rounded-2xl border border-slate-200 p-6 mb-8">
    <h3 class="text-lg font-bold text-slate-800 border-b border-slate-200/60 pb-3 mb-4">Настройки логирования</h3>

    <form method="POST" action="index.php?tab=config_vars" class="space-y-4">
        <input type="hidden" name="csrf_token" value="<?php echo $token; ?>">
        <input type="hidden" name="save_settings" value="1">
        <input type="hidden" name="return_url" value="index.php?tab=logs">
        <input type="hidden" name="settings_source" value="плагина">

        <div class="editor-row">
            <div class="editor-field">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="hidden" name="log_enabled" value="0">
                    <input type="checkbox" name="log_enabled" value="1" <?php echo !empty($settings['log_enabled']) ? 'checked' : ''; ?>>
                    <span class="text-sm font-medium text-slate-700">Включить логирование</span>
                </label>
            </div>
        </div>

        <div class="editor-row">
            <div class="editor-field">
                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Путь хранения логов</label>
                <input type="text" name="storage_path" value="<?php echo e($settings['storage_path'] ?? CMS_LOGS_DIR); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                <p class="text-[10px] text-slate-400 mt-1">По умолчанию: config/logs/. Можно указать абсолютный путь (например, /var/www/logs).</p>
            </div>
        </div>

        <div class="editor-row">
            <div class="editor-field">
                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Максимальный размер файла (МБ)</label>
                <input type="number" name="max_size" value="<?php echo e(($settings['max_size'] ?? 5 * 1024 * 1024) / 1024 / 1024); ?>" min="1" max="100" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                <p class="text-[10px] text-slate-400 mt-1">При превышении размера создаётся новый файл</p>
            </div>

            <div class="editor-field">
                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Количество хранимых архивов</label>
                <input type="number" name="keep_count" value="<?php echo e($settings['keep_count'] ?? 10); ?>" min="1" max="50" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                <p class="text-[10px] text-slate-400 mt-1">Старые архивы удаляются</p>
            </div>
        </div>

        <!-- Чекбоксы действий -->
        <div class="border-t border-slate-100 pt-4">
            <h4 class="text-sm font-bold text-slate-700 mb-3">Какие действия логировать:</h4>
            <div class="bg-slate-50 p-4 rounded-xl border border-slate-100 max-h-[300px] overflow-y-scroll">
                <?php foreach (get_log_action_groups() as $groupName => $groupData): ?>
                    <div class="mb-3 last:mb-0">
                        <div class="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                            <span class="icon-<?php echo e($groupData['icon']); ?> text-sm"></span>
                            <?php echo e($groupName); ?>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2! lg:grid-cols-3! gap-1">
                            <?php foreach ($groupData['actions'] as $action => $label): ?>
                                <label class="flex items-center gap-2 text-sm py-0.5 px-2 rounded hover:bg-slate-100 transition-colors cursor-pointer">
                                    <input type="checkbox" name="log_actions[<?php echo e($action); ?>]" value="1" <?php echo !empty($settings['log_actions'][$action]) ? 'checked' : ''; ?> class="w-4 h-4 text-[var(--primary-color)] rounded border-slate-300 focus:ring-[var(--primary-color)] flex-shrink-0">
                                    <span class="text-slate-700 truncate"><?php echo e($label); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="flex justify-end">
            <button type="submit" class="px-6 py-2.5 bg-[var(--primary-color)] text-white font-bold rounded-xl hover:bg-[var(--primary-dark)] transition-all text-sm">
                Сохранить настройки
            </button>
        </div>
    </form>
</div>

<!-- ФИЛЬТРЫ И ПРОСМОТР ЛОГОВ -->
<div class="bg-white rounded-2xl border border-slate-200 p-6">
    <div class="flex flex-col lg:flex-row items-center justify-between border-b border-slate-200/60 pb-3 mb-4">
        <h3 class="text-lg font-bold text-slate-800">Журнал событий</h3>
        <div class="flex items-center gap-2">
            <span class="text-sm text-slate-500">Показывать</span>
            <select id="per-page-select" class="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[var(--primary-color)]">
                <option value="10" selected>10</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
            </select>
            <span class="text-sm text-slate-500">записей</span>
        </div>
    </div>

    <!-- ФИЛЬТРЫ -->
    <div id="logs-filters" class="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3 mb-4">

        <!-- Уровень -->
        <div class="flex-1 min-w-[120px]">
            <select name="filter_level" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                <option value="">Все уровни</option>
                <option value="INFO" <?php echo $filterLevel === 'INFO' ? 'selected' : ''; ?>>INFO</option>
                <option value="WARNING" <?php echo $filterLevel === 'WARNING' ? 'selected' : ''; ?>>WARNING</option>
                <option value="ERROR" <?php echo $filterLevel === 'ERROR' ? 'selected' : ''; ?>>ERROR</option>
                <option value="CRITICAL" <?php echo $filterLevel === 'CRITICAL' ? 'selected' : ''; ?>>CRITICAL</option>
            </select>
        </div>

        <!-- Действие -->
        <div class="flex-1 min-w-[140px]">
            <select name="filter_action" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                <option value="">Все действия</option>
                <?php foreach ($allActions as $action => $label): ?>
                    <option value="<?php echo e($action); ?>" <?php echo $filterAction === $action ? 'selected' : ''; ?>><?php echo e($label); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Поиск -->
        <div class="flex-1 min-w-[140px]">
            <input type="text" name="search" placeholder="Поиск..." value="<?php echo e($search); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
        </div>

        <!-- Кнопки -->
        <div class="flex items-center gap-2 flex-shrink-0">
            <button type="button" class="js-logs-apply px-5 py-2.5 bg-[var(--primary-color)] text-white font-bold rounded-xl hover:bg-[var(--primary-dark)] transition text-sm shadow-lg shadow-[var(--primary-color)]/20">
                Применить
            </button>
            <button type="button" class="js-logs-reset px-5 py-2.5 border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition text-sm">
                Сбросить
            </button>
        </div>

    </div>

    <!-- КОНТЕЙНЕР ДЛЯ ТАБЛИЦЫ ЛОГОВ -->
    <div id="logs-container">
        <div class="text-center py-8 text-slate-400">
            <span class="icon-refresh-cw animate-spin inline-block mr-2"></span>
            Загрузка логов...
        </div>
    </div>
</div>

<?php $logsJsFile = APP_ROOT . '/config/js/logs.js'; ?>
<?php if (file_exists($logsJsFile)): ?>
<script src="js/logs.js?v=<?php echo filemtime($logsJsFile); ?>" type="text/javascript"></script>
<?php endif; ?>