/**
 * Плагин «Логи системы»: загрузка и отрисовка журнала событий.
 */

(function () {
    'use strict';

    var searchTimeout = null;
    var initialized = false;

    /**
     * Загружает логи через AJAX и отрисовывает таблицу.
     *
     * @param {number} page Номер страницы
     * @return {void}
     */
    function loadLogs(page) {
        page = page || 1;

        var levelEl = document.querySelector('#logs-filters select[name="filter_level"]');
        var actionEl = document.querySelector('#logs-filters select[name="filter_action"]');
        var searchEl = document.querySelector('#logs-filters input[name="search"]');
        var perPageEl = document.querySelector('#per-page-select');

        var level = levelEl ? levelEl.value : '';
        var action = actionEl ? actionEl.value : '';
        var search = searchEl ? searchEl.value : '';
        var perPage = perPageEl ? perPageEl.value : 10;

        var container = document.getElementById('logs-container');
        if (!container) return;

        container.style.transition = 'opacity 0.2s ease';
        container.style.opacity = '0.4';

        var params = new URLSearchParams({
            ajax: 'get_logs',
            tab: 'logs',
            level: level,
            action: action,
            search: search,
            page: page,
            per_page: perPage
        });

        fetch('index.php?' + params.toString())
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                data.perPage = parseInt(perPageEl ? perPageEl.value : 50, 10);

                if (data.logs && data.logs.length > 0) {
                    container.innerHTML = renderLogsTable(data);
                } else {
                    container.innerHTML = `
                        <div class="text-center py-8 text-slate-400">
                            <span class="icon-file-text text-3xl block mb-2 text-slate-300"></span>
                            Логов нет
                            ${(level || action || search) ? '<br><span class="text-xs">Попробуйте изменить фильтры</span>' : ''}
                        </div>
                    `;
                }

                container.style.opacity = '1';
            })
            .catch(function (error) {
                console.error('Fetch error:', error);
                container.innerHTML = `
                    <div class="text-center py-8 text-rose-500">
                        <span class="icon-alert-triangle text-2xl block mb-2"></span>
                        Ошибка загрузки логов
                    </div>
                `;
                container.style.opacity = '1';
            });
    }

    /**
     * Собирает HTML таблицы логов.
     *
     * @param {Object} data Ответ AJAX
     * @return {string}
     */
    function renderLogsTable(data) {
        var levelColors = {
            'INFO': 'text-emerald-700 bg-emerald-50',
            'WARNING': 'text-amber-700 bg-amber-50',
            'ERROR': 'text-rose-700 bg-rose-50',
            'CRITICAL': 'text-rose-900 bg-rose-100'
        };

        var html = `
            <div class="text-xs text-slate-400 mb-3">Найдено записей: ${data.total}</div>
            <div class="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden animate-fade-in">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-sm">
                        <thead>
                            <tr class="bg-slate-100 border-b border-slate-200">
                                <th class="py-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Время</th>
                                <th class="py-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Уровень</th>
                                <th class="py-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Пользователь</th>
                                <th class="py-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">IP</th>
                                <th class="py-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Действие</th>
                                <th class="py-2 px-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Сообщение</th>
                            </tr>
                        </thead>
                        <tbody>
        `;

        data.logs.forEach(function (log) {
            var colorClass = levelColors[log.level] || 'text-slate-700 bg-slate-100';
            html += `
                <tr class="border-b border-slate-100 hover:bg-slate-50/50 transition-colors">
                    <td class="py-2 px-3 font-mono text-xs text-slate-500 whitespace-nowrap">${escapeHtml(log.timestamp)}</td>
                    <td class="py-2 px-3">
                        <span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold ${colorClass}">
                            ${escapeHtml(log.level)}
                        </span>
                    </td>
                    <td class="py-2 px-3 font-medium text-slate-700">${escapeHtml(log.user)}</td>
                    <td class="py-2 px-3 font-mono text-xs text-slate-500">${escapeHtml(log.ip)}</td>
                    <td class="py-2 px-3 text-slate-600">${escapeHtml(log.action)}</td>
                    <td class="py-2 px-3 text-slate-600">${escapeHtml(log.message)}</td>
                </tr>
            `;
        });

        html += `
                        </tbody>
                    </table>
                </div>
        `;

        if (data.totalPages > 1) {
            html += '<div class="flex flex-wrap items-center justify-center gap-1 py-4 px-3 border-t border-slate-200">';
            html += renderPagination(data.page, data.totalPages);
            html += '</div>';
        }

        html += `
            </div>
        `;

        return html;
    }

    /**
     * Собирает компактную пагинацию: начало, назад, окно страниц, вперёд, конец.
     *
     * @param {number} current Текущая страница
     * @param {number} total Всего страниц
     * @return {string}
     */
    function renderPagination(current, total) {
        var html = '';
        var windowSize = 2;
        var pages = [];
        var i;

        for (i = 1; i <= total; i++) {
            if (i === 1 || i === total || (i >= current - windowSize && i <= current + windowSize)) {
                pages.push(i);
            }
        }

        html += pageButton(1, current, 'icon-chevrons-left', 'В начало', current === 1);
        html += pageButton(current - 1, current, 'icon-chevron-left', 'Предыдущая', current === 1);

        var previous = 0;
        pages.forEach(function (page) {
            if (previous && page - previous > 1) {
                html += '<span class="inline-flex items-center justify-center min-w-[2rem] h-8 px-2 text-slate-400">…</span>';
            }
            html += pageButton(page, current, '', '', false);
            previous = page;
        });

        html += pageButton(current + 1, current, 'icon-chevron-right', 'Следующая', current === total);
        html += pageButton(total, current, 'icon-chevrons-right', 'В конец', current === total);

        return html;
    }

    /**
     * Возвращает кнопку пагинации.
     *
     * @param {number} page Номер страницы
     * @param {number} current Текущая страница
     * @param {string} icon Класс иконки Lucide (пусто — номер страницы)
     * @param {string} title Подпись для title и aria-label
     * @param {boolean} disabled Заблокирована
     * @return {string}
     */
    function pageButton(page, current, icon, title, disabled) {
        var content = icon ? '<span class="' + icon + '"></span>' : String(page);
        var base = 'inline-flex items-center justify-center min-w-[2rem] h-8 px-2 rounded-lg text-sm transition-all';
        var aria = title ? ' title="' + title + '" aria-label="' + title + '"' : '';

        if (disabled) {
            return '<button type="button" class="' + base + ' text-slate-300 bg-slate-50 cursor-not-allowed"' + aria + ' disabled>' + content + '</button>';
        }

        if (page === current) {
            return '<span class="' + base + ' bg-[var(--primary-color)] text-white font-bold"' + aria + '>' + content + '</span>';
        }

        return '<button type="button" data-logs-page="' + page + '" class="' + base + ' bg-slate-100 text-slate-600 hover:bg-slate-200"' + aria + '>' + content + '</button>';
    }

    /**
     * Экранирует HTML-спецсимволы.
     *
     * @param {string} text
     * @return {string}
     */
    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Сбрасывает фильтры и перезагружает журнал.
     *
     * @return {void}
     */
    function clearFilters() {
        var level = document.querySelector('#logs-filters select[name="filter_level"]');
        var action = document.querySelector('#logs-filters select[name="filter_action"]');
        var search = document.querySelector('#logs-filters input[name="search"]');

        if (level) level.value = '';
        if (action) action.value = '';
        if (search) search.value = '';

        loadLogs(1);
    }

    /**
     * Подписывает обработчики на контейнер страницы.
     *
     * @return {void}
     */
    function init() {
        if (initialized) return;
        if (!document.getElementById('logs-container')) return;

        initialized = true;
        loadLogs(1);

        document.addEventListener('change', function (event) {
            var target = event.target;

            if (target.id === 'per-page-select') {
                loadLogs(1);
                return;
            }

            if (target.matches('#logs-filters select')) {
                loadLogs(1);
            }
        });

        document.addEventListener('input', function (event) {
            if (!event.target.matches('#logs-filters input[name="search"]')) return;

            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(function () {
                loadLogs(1);
            }, 400);
        });

        document.addEventListener('click', function (event) {
            if (event.target.closest('.js-logs-apply')) {
                loadLogs(1);
                return;
            }

            if (event.target.closest('.js-logs-reset')) {
                clearFilters();
                return;
            }

            var pageBtn = event.target.closest('[data-logs-page]');
            if (pageBtn) {
                loadLogs(parseInt(pageBtn.getAttribute('data-logs-page'), 10));
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
