<?php
/**
 * Плагин «Cookie-баннер».
 *
 * Выводит уведомление о cookies в конце body и подключает свой скрипт.
 * Пока плагин активен, баннер работает как раньше: скрывается на 30 дней
 * после нажатия на крестик (cookie `cookie-accept`).
 *
 * Модалка политик (`openPolicy`) остаётся в ядре — её используют ссылки
 * в футере.
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

/**
 * Выводит разметку баннера и подключает клиентский скрипт.
 *
 * @return void
 */
function cookie_banner_render(): void {
    $scriptPath = APP_ROOT . '/js/cookie-banner.js';
    $version = file_exists($scriptPath) ? (string)filemtime($scriptPath) : '1';
    ?>
    <div id="cookie-banner" class="fixed bottom-6 left-6 z-50 max-w-xs sm:max-w-sm bg-slate-100 p-5 rounded-xl shadow-lg border border-slate-200">
        <button id="close-cookie-banner" class="absolute top-3 right-3 text-slate-400 hover:text-slate-600 cursor-pointer">
            <span class="icon-x text-lg"></span></button>
        <p class="text-sm text-slate-600 pr-4 font-medium">Мы используем cookies. Продолжая использовать сайт, вы соглашаетесь с нашей <button onclick="openPolicy('cookie')" class="underline cursor-pointer">Политикой cookie</button>.</p>
    </div>
    <?php
    if (file_exists($scriptPath)) {
        echo '<script src="js/cookie-banner.js?v=' . e($version) . '" type="text/javascript"></script>';
    } else {
        // Плагин скопирован вручную без установки — берём исходник из папки плагина.
        $inline = @file_get_contents(__DIR__ . '/site/script.js');
        if ($inline !== false) {
            echo '<script type="text/javascript">' . $inline . '</script>';
        }
    }
}

/**
 * Сбрасывает HTML-кеш страниц.
 *
 * Баннер попадает в кешированный HTML, поэтому при включении, выключении
 * и удалении плагина кеш нужно очистить.
 *
 * @return void
 */
function cookie_banner_clear_cache(): void {
    if (function_exists('clearPageCache')) {
        clearPageCache();
    }
}

// Разметка и скрипт в конце body.
add_action('render_body_end', 'cookie_banner_render');

// Включение/выключение плагина: старый кеш может содержать баннер.
add_action('plugin_after_toggle', function ($id, $active) {
    if ($id === 'cookie-banner') {
        cookie_banner_clear_cache();
    }
}, 10, 2);

// Обновление плагина: в кеше может остаться старая разметка.
add_action('plugin_after_update', function ($id) {
    if ($id === 'cookie-banner') {
        cookie_banner_clear_cache();
    }
}, 10, 1);

// Удаление плагина: убираем баннер из кеша до удаления файлов.
add_action('plugin_before_delete', function ($id) {
    if ($id === 'cookie-banner') {
        cookie_banner_clear_cache();
    }
}, 10, 1);
