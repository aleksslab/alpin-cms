<?php
/**
 * Плагин «Cookie-баннер».
 *
 * Выводит настраиваемое уведомление о cookies в конце body и подключает
 * клиентский скрипт. Текст, подписи и ссылки на политику/условия, а также
 * срок хранения согласия задаются в «Настройках сайта».
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

/**
 * Значения настроек по умолчанию.
 *
 * @return array
 */
function cookie_banner_defaults(): array {
    return [
        'cookie_banner_text'         => 'Мы используем cookies. Продолжая использовать сайт, вы соглашаетесь с {policy} и {cookie}.',
        'cookie_banner_policy_label' => 'Политикой конфиденциальности',
        'cookie_banner_policy_url'   => '',
        'cookie_banner_cookie_label' => 'Условиями cookie',
        'cookie_banner_cookie_url'   => '',
        'cookie_banner_days'         => 30,
    ];
}

/**
 * Возвращает настройки плагина с подстановкой значений по умолчанию.
 *
 * @return array
 */
function cookie_banner_get_settings(): array {
    $defaults = cookie_banner_defaults();
    $settings = getSettingsData();
    $result = [];

    foreach ($defaults as $key => $default) {
        $value = $settings[$key] ?? $default;

        if (is_int($default)) {
            $value = (int)$value;
            if ($value < 1 || $value > 3650) {
                $value = (int)$default;
            }
        } else {
            $value = trim((string)$value);

            // Пустой URL — это не «нет ссылки», а встроенная модалка.
            if ($value === '' && $key !== 'cookie_banner_policy_url' && $key !== 'cookie_banner_cookie_url') {
                $value = $default;
            }
        }

        $result[$key] = $value;
    }

    return $result;
}

/**
 * Формирует ссылку на политику или кнопку встроенной модалки.
 *
 * @param string $url        URL страницы; пусто — встроенная модалка ядра
 * @param string $label      Подпись ссылки
 * @param string $policyType Тип политики для openPolicy(): privacy или cookie
 * @return string HTML
 */
function cookie_banner_link(string $url, string $label, string $policyType): string {
    if ($url !== '') {
        return '<a href="' . e(safeUrl($url)) . '" class="underline cursor-pointer">' . e($label) . '</a>';
    }

    return '<button type="button" onclick="openPolicy(\'' . e($policyType) . '\')" class="underline cursor-pointer">' . e($label) . '</button>';
}

/**
 * Выводит разметку баннера и подключает клиентский скрипт.
 *
 * @return void
 */
function cookie_banner_render(): void {
    $settings = cookie_banner_get_settings();
    $scriptPath = APP_ROOT . '/js/cookie-banner.js';
    $version = file_exists($scriptPath) ? (string)filemtime($scriptPath) : '1';

    $text = str_replace(["\r\n", "\r"], "\n", $settings['cookie_banner_text']);
    $text = nl2br(e($text), false);
    $text = str_replace(
        ['{policy}', '{cookie}'],
        [
            cookie_banner_link($settings['cookie_banner_policy_url'], $settings['cookie_banner_policy_label'], 'privacy'),
            cookie_banner_link($settings['cookie_banner_cookie_url'], $settings['cookie_banner_cookie_label'], 'cookie'),
        ],
        $text
    );
    ?>
    <div id="cookie-banner" data-cookie-days="<?php echo (int)$settings['cookie_banner_days']; ?>" class="fixed bottom-6 left-6 z-50 max-w-xs sm:max-w-sm bg-slate-100 p-5 rounded-xl shadow-lg border border-slate-200">
        <button type="button" id="close-cookie-banner" aria-label="Закрыть уведомление" class="absolute top-3 right-3 text-slate-400 hover:text-slate-600 cursor-pointer">
            <span class="icon-x text-lg"></span></button>
        <p class="text-sm text-slate-600 pr-4 font-medium"><?php echo $text; ?></p>
    </div>
    <?php
    if (file_exists($scriptPath)) {
        echo '<script src="js/cookie-banner.js?v=' . e($version) . '" type="text/javascript"></script>';
    } else {
        // Плагин скопирован вручную без установки — берём исходник из папки плагина.
        $inline = @file_get_contents(__DIR__ . '/site/script.js');
        if ($inline !== false) {
            echo '<script type="text/javascript">' . $inline . '</script>';
        }
    }
}

/**
 * Сбрасывает HTML-кеш страниц.
 *
 * Баннер попадает в кешированный HTML, поэтому при включении, выключении,
 * обновлении плагина и изменении настроек кеш нужно очистить.
 *
 * @return void
 */
function cookie_banner_clear_cache(): void {
    if (function_exists('clearPageCache')) {
        clearPageCache();
    }
}

// Разметка и скрипт в конце body.
add_action('render_body_end', 'cookie_banner_render');

// Включение/выключение плагина: старый кеш может содержать баннер.
add_action('plugin_after_toggle', function ($id, $active) {
    if ($id === 'cookie-banner') {
        cookie_banner_clear_cache();
    }
}, 10, 2);

// Обновление плагина: в кеше может остаться старая разметка.
add_action('plugin_after_update', function ($id) {
    if ($id === 'cookie-banner') {
        cookie_banner_clear_cache();
    }
}, 10, 1);

// Удаление плагина: убираем баннер из кеша до удаления файлов.
add_action('plugin_before_delete', function ($id) {
    if ($id === 'cookie-banner') {
        cookie_banner_clear_cache();
    }
}, 10, 1);

// Сохранение настроек из секции «Cookie-баннер».
add_filter('save_settings_data', function ($newSettings) {
    if (!is_array($newSettings)) {
        return $newSettings;
    }

    $defaults = cookie_banner_defaults();
    $submitted = save_plugin_settings($newSettings, 'cookie_banner_section', $defaults, array_keys($defaults));

    if (!$submitted) {
        return $newSettings;
    }

    $newSettings['cookie_banner_text'] = strip_tags(trim((string)($_POST['cookie_banner_text'] ?? '')));
    $newSettings['cookie_banner_policy_label'] = strip_tags(trim((string)($_POST['cookie_banner_policy_label'] ?? '')));
    $newSettings['cookie_banner_cookie_label'] = strip_tags(trim((string)($_POST['cookie_banner_cookie_label'] ?? '')));

    foreach (['cookie_banner_policy_url', 'cookie_banner_cookie_url'] as $key) {
        $url = trim((string)($_POST[$key] ?? ''));
        if ($url !== '') {
            $safe = safeUrl($url);
            $url = ($safe === '#') ? '' : $safe;
        }
        $newSettings[$key] = $url;
    }

    $days = (int)($_POST['cookie_banner_days'] ?? 0);
    if ($days < 1) {
        $days = (int)$defaults['cookie_banner_days'];
    }
    $newSettings['cookie_banner_days'] = min(3650, $days);

    return $newSettings;
});

// Изменение настроек: баннер в кеше должен обновиться.
add_action('settings_saved', function ($oldSettings, $newSettings) {
    if (!is_array($oldSettings) || !is_array($newSettings)) {
        return;
    }

    foreach (array_keys(cookie_banner_defaults()) as $key) {
        if (($oldSettings[$key] ?? null) !== ($newSettings[$key] ?? null)) {
            cookie_banner_clear_cache();
            return;
        }
    }
}, 10, 2);

// Секция в «Настройках сайта».
register_plugin_section('cookie-banner', 'Cookie-баннер', function () {
    include __DIR__ . '/admin-section.php';
});
