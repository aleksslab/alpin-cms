/**
 * Плагин «Cookie-баннер»: клиентская часть.
 *
 * Показывает уведомление, если согласие ещё не дано, и прячет его на 30 дней
 * после закрытия. Модалку политик открывает ядро (`window.openPolicy`).
 */
(function () {
    'use strict';

    /**
     * Устанавливает cookie.
     *
     * @param {string} name
     * @param {string} value
     * @param {number} days
     * @returns {void}
     */
    function setCookie(name, value, days) {
        var d = new Date();
        d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
        document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/';
    }

    /**
     * Читает cookie по имени.
     *
     * @param {string} name
     * @returns {string}
     */
    function getCookie(name) {
        var cname = name + '=';
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i].trim();
            if (c.indexOf(cname) === 0) return c.substring(cname.length, c.length);
        }
        return '';
    }

    /**
     * Инициализирует баннер.
     *
     * @returns {void}
     */
    function initCookieBanner() {
        var banner = document.getElementById('cookie-banner');
        var closeBtn = document.getElementById('close-cookie-banner');
        if (!banner) return;

        banner.style.display = (getCookie('cookie-accept') === 'accepted') ? 'none' : 'block';

        if (closeBtn) {
            closeBtn.addEventListener('click', function () {
                setCookie('cookie-accept', 'accepted', 30);
                banner.style.display = 'none';
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initCookieBanner);
    } else {
        initCookieBanner();
    }
})();
