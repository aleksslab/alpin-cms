<?php
/**
 * Секция настроек: Cookie-баннер.
 */

if (!defined('APP_ROOT') || empty($_SESSION['admin_auth'])) {
    die('Доступ запрещен');
}

$cookieSettings = cookie_banner_get_settings();
$cookieDefaults = cookie_banner_defaults();
?>

<div class="border border-slate-200 rounded-2xl overflow-hidden mb-5">
    <div class="section-header bg-slate-50 px-4 py-3 border-b border-slate-100 flex items-center justify-between cursor-pointer hover:bg-slate-100/50 transition-colors" onclick="window.toggleSection(this)">
        <div class="flex items-center gap-3">
            <span class="section-arrow icon-chevron-right text-xs text-slate-400"></span>
            <span class="text-sm font-bold text-slate-700">Cookie-баннер</span>
            <span class="text-[10px] text-slate-400">(текст, ссылки, срок)</span>
        </div>
    </div>
    <div class="section-content p-6 bg-slate-50 hidden">
        <input type="hidden" name="cookie_banner_section" value="1">

        <div class="space-y-5">
            <div class="editor-field">
                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Текст баннера</label>
                <textarea name="cookie_banner_text" rows="4" class="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]" placeholder="<?php echo e($cookieDefaults['cookie_banner_text']); ?>"><?php echo e($cookieSettings['cookie_banner_text']); ?></textarea>
                <p class="text-[10px] text-slate-400 mt-1">
                    Плейсхолдеры <code class="font-mono bg-white px-1 rounded border border-slate-200">{policy}</code> и
                    <code class="font-mono bg-white px-1 rounded border border-slate-200">{cookie}</code> заменяются на ссылки.
                    Если плейсхолдера нет — ссылка не выводится.
                </p>
            </div>

            <div class="border-t border-slate-200/60 pt-4 mt-2">
                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Политика конфиденциальности</div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Подпись ссылки</label>
                        <input type="text" name="cookie_banner_policy_label" value="<?php echo e($cookieSettings['cookie_banner_policy_label']); ?>" placeholder="<?php echo e($cookieDefaults['cookie_banner_policy_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">URL страницы</label>
                        <input type="text" name="cookie_banner_policy_url" value="<?php echo e($cookieSettings['cookie_banner_policy_url']); ?>" placeholder="Пусто — встроенная модалка" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                </div>
                <p class="text-[10px] text-slate-400 mt-1">Если URL пуст, открывается встроенная модалка с текстом из <code class="font-mono bg-white px-1 rounded border border-slate-200">includes/privacy.php</code>.</p>
            </div>

            <div class="border-t border-slate-200/60 pt-4 mt-2">
                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Условия использования cookie</div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Подпись ссылки</label>
                        <input type="text" name="cookie_banner_cookie_label" value="<?php echo e($cookieSettings['cookie_banner_cookie_label']); ?>" placeholder="<?php echo e($cookieDefaults['cookie_banner_cookie_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">URL страницы</label>
                        <input type="text" name="cookie_banner_cookie_url" value="<?php echo e($cookieSettings['cookie_banner_cookie_url']); ?>" placeholder="Пусто — встроенная модалка" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                </div>
                <p class="text-[10px] text-slate-400 mt-1">Если URL пуст, открывается встроенная модалка с текстом из <code class="font-mono bg-white px-1 rounded border border-slate-200">includes/cookies.php</code>.</p>
            </div>

            <div class="border-t border-slate-200/60 pt-4 mt-2">
                <div class="editor-field">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Срок хранения согласия, дней</label>
                    <input type="number" name="cookie_banner_days" value="<?php echo (int)$cookieSettings['cookie_banner_days']; ?>" min="1" max="3650" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    <p class="text-[10px] text-slate-400 mt-1">
                        По умолчанию 30. После закрытия баннера согласие хранится в cookie
                        <code class="font-mono bg-white px-1 rounded border border-slate-200">cookie-accept</code>.
                    </p>
                </div>
            </div>

            <p class="text-[10px] text-slate-400">
                Пустые текст и подписи заменяются значениями по умолчанию. Пустой URL открывает встроенную модалку политики.
            </p>
        </div>
    </div>
</div>
