<?php
/**
 * Плагин: автопубликация страниц.
 *
 * Cron-задача публикует страницы со статусом `scheduled`, у которых наступило
 * время `publish_at`, и архивирует опубликованные страницы с истёкшим
 * `unpublish_at`. Токен и расписание проверяет ядро (`config/cron/run.php`).
 */

if (!defined('APP_ROOT')) {
    die('Прямой доступ запрещён');
}

// Планирование публикации доступно только при активном плагине: он один
// умеет переводить `scheduled` в `published`. Ядро по умолчанию считает
// возможность выключенной и не показывает статус «По расписанию» с датами.
add_filter('page_scheduling_enabled', function () {
    return true;
});

/**
 * Cron-задача: публикация и архивация страниц по расписанию.
 *
 * @return bool true при успешном выполнении.
 */
function publish_run_cron(): bool {
    $pagesDir = DATA_DIR . 'pages/';
    if (!is_dir($pagesDir)) {
        return true;
    }

    $files = glob($pagesDir . '*.json');
    if (empty($files)) {
        return true;
    }

    $now = time();

    foreach ($files as $file) {
        $page = _jsonToArray($file);
        if (empty($page['id'])) {
            continue;
        }

        // Копия до изменений — для хуков page_before_save / page_saved
        $oldPage = $page;

        $changed = false;

        // Сценарий А: scheduled → published
        if (($page['status'] ?? '') === 'scheduled'
            && !empty($page['publish_at'])
            && (int)$page['publish_at'] <= $now
        ) {
            $page['status']     = 'published';
            $page['publish_at'] = null;

            // Если unpublish_at уже в прошлом — сразу archived
            if (!empty($page['unpublish_at']) && (int)$page['unpublish_at'] <= $now) {
                $page['status']       = 'archived';
                $page['unpublish_at'] = null;
                logAction('page_archive', 'Автоснятие: "' . ($page['title'] ?? $page['id']) . '" (ID: ' . $page['id'] . ')', 'INFO');
            } else {
                logAction('page_publish', 'Автопубликация: "' . ($page['title'] ?? $page['id']) . '" (ID: ' . $page['id'] . ')', 'INFO');
            }

            $changed = true;
        }
        // Сценарий Б: published → archived
        elseif (($page['status'] ?? '') === 'published'
            && !empty($page['unpublish_at'])
            && (int)$page['unpublish_at'] <= $now
        ) {
            $page['status']       = 'archived';
            $page['unpublish_at'] = null;

            $changed = true;

            logAction('page_archive', 'Автоснятие: "' . ($page['title'] ?? $page['id']) . '" (ID: ' . $page['id'] . ')', 'INFO');
        }

        if ($changed) {
            // Единый контракт ядра: плагины получают те же хуки, что и при ручном сохранении
            $page = apply_filters('page_data_before_save', $page, $page['id'], $oldPage);
            do_action('page_before_save', $page['id'], $page, $oldPage);

            if (savePageData($page['id'], $page)) {
                clearPageCacheById($page['id']);

                // SEO-плагин и другие подписчики обновляются после автопубликации
                do_action('page_saved', $page['id'], $page, $oldPage);
            } else {
                logAction('page_publish', 'Ошибка записи при автопубликации: ' . $page['id'], 'ERROR');
            }
        }
    }

    return true;
}

// Задача в общем реестре кронов ядра (виртуальный крон — при заходе админа)
register_cron_task('publish', 'publish_run_cron', [
    'interval' => 60,
    'virtual'  => true,
    'enabled'  => true,
    // В лог попадают только page_publish/page_archive, а не каждый минутный запуск
    'log'      => false,
    'label'    => 'Автопубликация страниц',
]);

// Действия логирования
register_log_action('page_publish', 'Автопубликация страницы', 'Страницы', 'file-text');
register_log_action('page_archive', 'Автоснятие страницы с публикации', 'Страницы', 'file-text');
