<?php
/**
 * Модалка корзины для страниц и меню.
 *
 * Ожидаемые переменные:
 * - $trashContext   'page' | 'menu'
 * - $trashReturnUrl URL для редиректа после POST
 */

if (!defined('APP_ROOT') || empty($_SESSION['admin_auth'])) {
    die('Доступ запрещён');
}

$trashContext   = $trashContext   ?? 'page';
$trashReturnUrl = $trashReturnUrl ?? '?tab=pages';

$trashList  = trash_get_list($trashContext);
$trashCount = count($trashList);
$token      = $_SESSION['csrf_token'] ?? '';
$contextLabel = ($trashContext === 'page') ? 'страницы' : 'меню';
?>

<!-- Модалка корзины -->
<div id="trash-modal" class="modal-backdrop-fixed !z-9996">
    <div class="modal-content-card" style="max-width: 800px; max-height: 90vh;">
        <div class="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50 flex-shrink-0">
            <div>
                <h3 class="text-base font-bold text-slate-800">Корзина</h3>
                <p class="text-xs text-slate-400 mt-0.5">
                    Удалённые <?php echo e($contextLabel); ?>. Хранятся до ручной очистки.
                </p>
            </div>
            <button type="button" onclick="window.closeTrashModal()" 
                    class="w-10 h-10 flex items-center justify-center bg-white border border-slate-200 text-slate-400 rounded-lg hover:text-slate-600 transition-all">
                <span class="icon-x text-xl"></span>
            </button>
        </div>

        <div class="p-4 overflow-y-auto flex-1" style="max-height: calc(90vh - 180px);">
            <?php if (empty($trashList)): ?>
                <div class="text-center py-16 text-slate-400">
                    <span class="icon-trash-2 text-3xl block mb-3 text-slate-300"></span>
                    <p class="text-sm font-semibold text-slate-600">Корзина пуста</p>
                    <p class="text-xs mt-1">Удалённые <?php echo e($contextLabel); ?> появятся здесь.</p>
                </div>
            <?php else: ?>
                <!-- Шапка: выбрать все -->
                <div class="flex items-center gap-3 px-3 py-2 mb-2 border-b border-slate-100">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" id="trash-select-all" class="w-4 h-4 text-[var(--primary-color)] rounded border-slate-300">
                        <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Выбрать все</span>
                    </label>
                    <span class="text-xs text-slate-400 ml-auto">
                        <span id="trash-selected-count">0</span> выбрано из <?php echo $trashCount; ?>
                    </span>
                </div>

                <!-- Список -->
                <div class="space-y-2" id="trash-list">
                    <?php foreach ($trashList as $item): ?>
                        <label class="trash-item flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl hover:border-slate-300 transition-all cursor-pointer"
                               data-file="<?php echo e($item['file']); ?>">
                            <input type="checkbox" class="trash-item-checkbox w-4 h-4 text-[var(--primary-color)] rounded border-slate-300 flex-shrink-0">
                            
                            <div class="flex-1 min-w-0">
                                <div class="font-semibold text-slate-800 truncate" title="<?php echo e($item['title']); ?>">
                                    <?php echo e($item['title']); ?>
                                </div>
                                <div class="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-400 mt-1">
                                    <span class="font-mono">ID: <?php echo e($item['original_id']); ?></span>
                                    <span>Удалено: <?php echo date('d.m.Y H:i', $item['deleted_at']); ?></span>
                                    <?php if (!empty($item['deleted_by'])): ?>
                                        <span>Кем: <?php echo e($item['deleted_by']); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </label>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="p-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50 flex-shrink-0">
            <button type="button" 
                    onclick="window.trashClearAll()" 
                    class="px-4 py-2 border border-rose-200 text-rose-600 text-sm font-bold rounded-xl hover:bg-rose-50 transition-all <?php echo empty($trashList) ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'; ?>"
                    <?php echo empty($trashList) ? 'disabled' : ''; ?>>
                <span class="icon-trash-2 text-sm mr-1"></span> Очистить корзину
            </button>

            <div class="flex items-center gap-2">
                <button type="button" 
                        onclick="window.trashRestoreSelected()" 
                        class="px-4 py-2 bg-[var(--primary-color)] text-white text-sm font-bold rounded-xl hover:bg-[var(--primary-dark)] transition-all cursor-pointer disabled:opacity-40"
                        id="trash-restore-btn" disabled>
                    <span class="icon-rotate-ccw text-sm mr-1"></span> Восстановить
                </button>
                <button type="button" 
                        onclick="window.trashDeleteSelected()" 
                        class="px-4 py-2 bg-rose-500 text-white text-sm font-bold rounded-xl hover:bg-rose-600 transition-all cursor-pointer disabled:opacity-40"
                        id="trash-delete-btn" disabled>
                    <span class="icon-x text-sm mr-1"></span> Удалить выбранные
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Скрытая форма для POST-действий -->
<form id="trash-action-form" method="POST" action="<?php echo e($trashReturnUrl); ?>" class="hidden">
    <input type="hidden" name="csrf_token" value="<?php echo e($token); ?>">
    <input type="hidden" name="trash_return_url" value="<?php echo e($trashReturnUrl); ?>">
    <input type="hidden" name="trash_context" value="<?php echo e($trashContext); ?>">
    <div id="trash-form-files"></div>
    <input type="hidden" name="trash_action" id="trash-form-action" value="">
</form>

<script>
(function() {
    'use strict';

    function getSelectedFiles() {
        var files = [];
        document.querySelectorAll('.trash-item-checkbox:checked').forEach(function(cb) {
            var item = cb.closest('.trash-item');
            if (item) files.push(item.dataset.file);
        });
        return files;
    }

    function updateState() {
        var files = getSelectedFiles();
        var count = files.length;
        var counter = document.getElementById('trash-selected-count');
        if (counter) counter.textContent = count;

        var restoreBtn = document.getElementById('trash-restore-btn');
        var deleteBtn = document.getElementById('trash-delete-btn');
        if (restoreBtn) restoreBtn.disabled = count === 0;
        if (deleteBtn) deleteBtn.disabled = count === 0;

        var selectAll = document.getElementById('trash-select-all');
        if (selectAll) {
            var all = document.querySelectorAll('.trash-item-checkbox');
            var checked = document.querySelectorAll('.trash-item-checkbox:checked');
            selectAll.checked = (all.length > 0 && all.length === checked.length);
            selectAll.indeterminate = (checked.length > 0 && checked.length < all.length);
        }
    }

    function submitAction(action, files) {
        var form = document.getElementById('trash-action-form');
        if (!form) return;

        var actionInput = document.getElementById('trash-form-action');
        if (actionInput) actionInput.value = action;

        var filesContainer = document.getElementById('trash-form-files');
        if (filesContainer) {
            filesContainer.innerHTML = '';
            files.forEach(function(f) {
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'trash_files[]';
                input.value = f;
                filesContainer.appendChild(input);
            });
        }

        form.submit();
    }

    window.openTrashModal = function() {
        var modal = document.getElementById('trash-modal');
        if (modal) modal.classList.add('active');
    };

    window.closeTrashModal = function() {
        var modal = document.getElementById('trash-modal');
        if (modal) modal.classList.remove('active');
    };

    window.trashRestoreSelected = function() {
        var files = getSelectedFiles();
        if (files.length === 0) return;
        if (!confirm('Восстановить выбранные элементы?')) return;
        submitAction('restore', files);
    };

    window.trashDeleteSelected = function() {
        var files = getSelectedFiles();
        if (files.length === 0) return;
        if (!confirm('Удалить выбранные элементы НАВСЕГДА? Восстановить будет невозможно.')) return;
        submitAction('delete_selected', files);
    };

    window.trashClearAll = function() {
        if (!confirm('Очистить корзину полностью? Все элементы будут удалены НАВСЕГДА.')) return;
        submitAction('clear_all', []);
    };

    function init() {
        var selectAll = document.getElementById('trash-select-all');
        if (selectAll) {
            selectAll.addEventListener('change', function() {
                var checked = this.checked;
                document.querySelectorAll('.trash-item-checkbox').forEach(function(cb) {
                    cb.checked = checked;
                });
                updateState();
            });
        }

        document.addEventListener('change', function(e) {
            if (e.target.classList && e.target.classList.contains('trash-item-checkbox')) {
                updateState();
            }
        });

        updateState();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
</script>
