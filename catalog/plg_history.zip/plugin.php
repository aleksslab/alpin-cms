<?php
/**
 * Плагин: История изменений страниц.
 *
 * Создаёт снапшоты версий в data/history/, откатывает только контент,
 * хранит лимит версий и чистит историю при окончательном удалении страницы.
 *
 * Настройки — history_enabled и history_limit в data/settings.json.
 * Поле history_key остаётся в JSON страницы и генерируется плагином.
 */

if (!defined('APP_ROOT')) {
    die('Прямой доступ запрещён');
}

// Базовая папка истории
if (!defined('HISTORY_DIR')) {
    define('HISTORY_DIR', DATA_DIR . 'history' . DIRECTORY_SEPARATOR);
}

/**
 * Проверяет, включено ли сохранение истории изменений.
 *
 * @return bool
 */
function history_is_enabled(): bool {
    $settings = getSettingsData();
    return !empty($settings['history_enabled']);
}

/**
 * Возвращает максимальное количество хранимых версий одной страницы.
 * Ограничено диапазоном 1..100.
 *
 * @return int
 */
function history_get_limit(): int {
    $settings = getSettingsData();
    $limit = intval($settings['history_limit'] ?? 20);
    return max(1, min(100, $limit));
}

/**
 * Возвращает путь к папке истории одной страницы (с trailing separator).
 * Не создаёт папку — только формирует путь.
 *
 * @param string $historyKey Ключ истории (16 hex-символов)
 * @return string Путь или пустая строка при невалидном ключе
 */
function history_get_dir(string $historyKey): string {
    if (!preg_match('/^[a-f0-9]{16}$/i', $historyKey)) {
        return '';
    }
    return HISTORY_DIR . $historyKey . DIRECTORY_SEPARATOR;
}

/**
 * Гарантирует существование базовой папки истории + .htaccess защиту.
 * Также создаёт вложенную папку для конкретной страницы.
 *
 * @param string $historyKey Ключ истории страницы (16 hex-символов)
 * @return bool true если папка доступна для записи
 */
function history_ensure_dir(string $historyKey): bool {
    if (!preg_match('/^[a-f0-9]{16}$/i', $historyKey)) {
        return false;
    }

    if (!is_dir(HISTORY_DIR)) {
        if (!@mkdir(HISTORY_DIR, 0755, true)) {
            return false;
        }
    }

    $htaccess = HISTORY_DIR . '.htaccess';
    if (!file_exists($htaccess)) {
        $data = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n"
              . "<IfModule !mod_authz_core.c>\n    Order Deny,Allow\n    Deny from all\n</IfModule>\n";
        @file_put_contents($htaccess, $data);
    }

    $pageDir = HISTORY_DIR . $historyKey . DIRECTORY_SEPARATOR;
    if (!is_dir($pageDir)) {
        if (!@mkdir($pageDir, 0755, true)) {
            return false;
        }
    }

    return is_writable($pageDir);
}

/**
 * Возвращает history_key страницы.
 * Если ключа нет — генерирует, сохраняет в JSON страницы и возвращает.
 *
 * ВНИМАНИЕ: при генерации модифицирует файл на диске.
 * Используется как fallback для страниц, созданных до фичи.
 *
 * @param array $page Данные страницы (по ссылке, чтобы можно было обновить)
 * @return string 16 hex-символов или пустая строка
 */
function history_get_or_create_key(array &$page): string {
    $existing = (string)($page['history_key'] ?? '');
    if (preg_match('/^[a-f0-9]{16}$/i', $existing)) {
        return $existing;
    }

    $key = bin2hex(random_bytes(8));
    $page['history_key'] = $key;

    $pageId = (string)($page['id'] ?? '');
    if ($pageId !== '' && preg_match('/^[a-z0-9\-_]+$/i', $pageId)) {
        savePageData($pageId, $page);
    }

    return $key;
}

/**
 * Удаляет самые старые версии, оставляя не больше $limit штук.
 * Сортировка по имени файла (timestamp = имя).
 *
 * @param string $historyKey Ключ истории
 * @param int    $limit      Максимум хранимых версий (1..100)
 * @return int Количество удалённых файлов
 */
function history_rotate(string $historyKey, int $limit): int {
    $limit = max(1, min(100, $limit));
    $dir = history_get_dir($historyKey);
    if ($dir === '' || !is_dir($dir)) {
        return 0;
    }

    $files = glob($dir . '*.json');
    if (!is_array($files) || count($files) <= $limit) {
        return 0;
    }

    usort($files, function($a, $b) {
        return strcmp(basename($a), basename($b));
    });

    $toDelete = array_slice($files, 0, count($files) - $limit);
    $deleted = 0;
    foreach ($toDelete as $file) {
        if (@unlink($file)) {
            $deleted++;
        }
    }

    return $deleted;
}

/**
 * Сохраняет снапшот страницы в историю.
 * Вызывается ПЕРЕД перезаписью текущего файла.
 *
 * Снапшот НЕ пишется, если:
 * - история отключена;
 * - старое состояние ≡ новое (пользователь ничего не менял);
 * - такое же состояние уже есть в последнем снапшоте.
 *
 * @param array  $oldPage  Данные страницы ДО сохранения (то, что на диске)
 * @param array  $newPage  Данные страницы ПОСЛЕ сохранения (то, что будет записано)
 * @param string $savedBy  Логин админа (или 'system')
 * @return bool true при успешной записи
 */
function history_save_snapshot(array $oldPage, array $newPage, string $savedBy = 'system'): bool {
    if (!history_is_enabled()) {
        return false;
    }

    $oldHash = md5(json_encode(history_normalize_content(history_extract_content($oldPage))));
    $newHash = md5(json_encode(history_normalize_content(history_extract_content($newPage))));
    if ($oldHash === $newHash) {
        return false;
    }

    $pageData = $oldPage;

    $pageId = (string)($pageData['id'] ?? '');
    if ($pageId === '' || !preg_match('/^[a-z0-9\-_]+$/i', $pageId)) {
        return false;
    }

    // Ключ берём из новой версии — его назначает фильтр page_data_before_save
    $historyKey = (string)($newPage['history_key'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/i', $historyKey)) {
        // Fallback для страниц без ключа
        $historyKey = history_get_or_create_key($pageData);
    }
    $pageData['history_key'] = $historyKey;

    if ($historyKey === '') {
        return false;
    }

    if (!history_ensure_dir($historyKey)) {
        return false;
    }

    // Дубликат последнего снапшота не пишем
    $existingFiles = glob(HISTORY_DIR . $historyKey . DIRECTORY_SEPARATOR . '*.json');
    if (is_array($existingFiles) && !empty($existingFiles)) {
        usort($existingFiles, function($a, $b) {
            return strcmp(basename($a), basename($b));
        });
        $lastFile = end($existingFiles);

        $lastData = _jsonToArray($lastFile);
        if (!empty($lastData)) {
            $lastHash = md5(json_encode(history_normalize_content(history_extract_content($lastData))));
            if ($lastHash === $newHash) {
                return false;
            }
        }
    }

    // Формируем снапшот: полный JSON + _history
    $snapshot = $pageData;
    $snapshot['_history'] = [
        'page_id'     => $pageId,
        'snapshot_at' => time(),
        'saved_by'    => $savedBy,
        'size_bytes'  => 0,
    ];

    $json = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) {
        return false;
    }

    $snapshot['_history']['size_bytes'] = strlen($json);
    $json = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

    $timestamp = $snapshot['_history']['snapshot_at'];
    $targetPath = HISTORY_DIR . $historyKey . DIRECTORY_SEPARATOR . $timestamp . '.json';

    if (!safeFileWrite($targetPath, $json)) {
        return false;
    }

    history_rotate($historyKey, history_get_limit());

    return true;
}

/**
 * Возвращает список версий страницы (свежие сверху).
 *
 * @param string $historyKey Ключ истории
 * @return array Массив записей: [timestamp, snapshot_at, saved_by, size_bytes, page_id]
 */
function history_get_list(string $historyKey): array {
    $dir = history_get_dir($historyKey);
    if ($dir === '' || !is_dir($dir)) {
        return [];
    }

    $files = glob($dir . '*.json');
    if (!is_array($files) || empty($files)) {
        return [];
    }

    $list = [];
    foreach ($files as $file) {
        $timestamp = (int)basename($file, '.json');
        if ($timestamp <= 0) {
            continue;
        }

        $data = _jsonToArray($file);
        if (empty($data) || empty($data['_history'])) {
            continue;
        }

        $meta = $data['_history'];

        $list[] = [
            'timestamp'   => $timestamp,
            'snapshot_at' => (int)($meta['snapshot_at'] ?? $timestamp),
            'saved_by'    => (string)($meta['saved_by'] ?? ''),
            'size_bytes'  => (int)($meta['size_bytes'] ?? 0),
            'page_id'     => (string)($meta['page_id'] ?? ''),
        ];
    }

    usort($list, function($a, $b) {
        return $b['timestamp'] - $a['timestamp'];
    });

    return $list;
}

/**
 * Читает конкретный снапшот версии страницы.
 * Возвращает данные БЕЗ служебного блока _history.
 *
 * @param string $historyKey Ключ истории
 * @param int    $timestamp  Unix timestamp версии
 * @return array|null Данные страницы или null
 */
function history_get_snapshot(string $historyKey, int $timestamp): ?array {
    if ($timestamp <= 0) {
        return null;
    }

    $dir = history_get_dir($historyKey);
    if ($dir === '' || !is_dir($dir)) {
        return null;
    }

    $file = $dir . $timestamp . '.json';
    if (!file_exists($file)) {
        return null;
    }

    $data = _jsonToArray($file);
    if (empty($data)) {
        return null;
    }

    unset($data['_history']);

    return $data;
}

/**
 * Список контентных полей страницы — участвуют в снапшоте,
 * сравнении и откате. Один источник правды.
 *
 * Не входят:
 * - status, publish_at, unpublish_at — жизненный цикл, не контент.
 * - slug_history — накопительная история адресов.
 * - id, slug, history_key, preview_token — служебные.
 *
 * @return array
 */
function history_content_fields(): array {
    return [
        'title',
        'template',
        'meta',
        'show_header',
        'show_footer',
        'rows',
    ];
}

/**
 * Извлекает из страницы только контентные поля.
 *
 * @param array $page Данные страницы
 * @return array Массив из контентных полей (отсутствующие = null)
 */
function history_extract_content(array $page): array {
    $result = [];
    foreach (history_content_fields() as $field) {
        $result[$field] = $page[$field] ?? null;
    }
    return $result;
}

/**
 * Нормализует контент для стабильного сравнения:
 * - вырезает служебное поле _jsId в rows[].columns[].modules[]
 * - рекурсивно сортирует ключи через ksort
 *
 * @param array $content
 * @return array
 */
function history_normalize_content(array $content): array {
    if (isset($content['rows']) && is_array($content['rows'])) {
        foreach ($content['rows'] as &$row) {
            if (!is_array($row)) continue;

            unset($row['_jsId']);

            if (!empty($row['columns']) && is_array($row['columns'])) {
                foreach ($row['columns'] as &$col) {
                    if (!is_array($col)) continue;

                    unset($col['_jsId']);

                    if (!empty($col['modules']) && is_array($col['modules'])) {
                        foreach ($col['modules'] as &$mod) {
                            if (!is_array($mod)) continue;
                            unset($mod['_jsId']);
                        }
                        unset($mod);
                    }
                }
                unset($col);
            }
        }
        unset($row);
    }

    return history_normalize_sort($content);
}

/**
 * Рекурсивно сортирует ключи массива (по возрастанию) для стабильного json_encode.
 *
 * @param mixed $value
 * @return mixed
 */
function history_normalize_sort($value) {
    if (!is_array($value)) {
        return $value;
    }

    foreach ($value as &$item) {
        $item = history_normalize_sort($item);
    }
    unset($item);

    ksort($value);
    return $value;
}

/**
 * Удаляет одну версию истории.
 *
 * @param string $historyKey Ключ истории
 * @param int    $timestamp  Unix timestamp версии
 * @return array ['success' => bool, 'error' => string]
 */
function history_delete_version(string $historyKey, int $timestamp): array {
    if ($timestamp <= 0) {
        return ['success' => false, 'error' => 'Невалидный timestamp.'];
    }

    $dir = history_get_dir($historyKey);
    if ($dir === '') {
        return ['success' => false, 'error' => 'Невалидный ключ истории.'];
    }

    $file = $dir . $timestamp . '.json';
    if (!file_exists($file)) {
        return ['success' => false, 'error' => 'Версия не найдена.'];
    }

    if (!@unlink($file)) {
        return ['success' => false, 'error' => 'Не удалось удалить версию.'];
    }

    return ['success' => true, 'error' => ''];
}

/**
 * Удаляет всю историю одной страницы (все версии + папку).
 *
 * @param string $historyKey Ключ истории
 * @return int Количество удалённых файлов
 */
function history_clear_page(string $historyKey): int {
    $dir = history_get_dir($historyKey);
    if ($dir === '' || !is_dir($dir)) {
        return 0;
    }

    $files = glob($dir . '*.json');
    $deleted = 0;
    if (is_array($files)) {
        foreach ($files as $file) {
            if (@unlink($file)) {
                $deleted++;
            }
        }
    }

    @rmdir($dir);

    return $deleted;
}

/**
 * Собирает статистику по всей истории сайта.
 *
 * @return array ['pages' => int, 'versions' => int, 'size_bytes' => int]
 */
function history_get_stats(): array {
    $stats = ['pages' => 0, 'versions' => 0, 'size_bytes' => 0];

    if (!is_dir(HISTORY_DIR)) {
        return $stats;
    }

    $pageDirs = glob(HISTORY_DIR . '*', GLOB_ONLYDIR);
    if (!is_array($pageDirs)) {
        return $stats;
    }

    foreach ($pageDirs as $dir) {
        $key = basename($dir);
        if (!preg_match('/^[a-f0-9]{16}$/i', $key)) {
            continue;
        }

        $files = glob($dir . DIRECTORY_SEPARATOR . '*.json');
        if (!is_array($files) || empty($files)) {
            continue;
        }

        $stats['pages']++;
        $stats['versions'] += count($files);

        foreach ($files as $file) {
            $size = @filesize($file);
            if ($size !== false) {
                $stats['size_bytes'] += $size;
            }
        }
    }

    return $stats;
}

/**
 * Восстанавливает страницу из снапшота истории.
 * Сначала делает снапшот текущего состояния (чтобы откат был обратимым).
 *
 * ВАЖНО: восстанавливается только контент.
 * id, slug, preview_token, history_key — не трогаются.
 *
 * @param string $pageId    ID страницы
 * @param int    $timestamp Unix timestamp снапшота
 * @return array ['success' => bool, 'error' => string, 'message' => string]
 */
function history_restore_page(string $pageId, int $timestamp): array {
    if (!preg_match('/^[a-z0-9\-_]+$/i', $pageId)) {
        return ['success' => false, 'error' => 'Невалидный ID страницы.', 'message' => ''];
    }

    $current = loadPageById($pageId);
    if (!$current) {
        return ['success' => false, 'error' => 'Страница не найдена.', 'message' => ''];
    }

    $historyKey = (string)($current['history_key'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/i', $historyKey)) {
        return ['success' => false, 'error' => 'У страницы нет истории.', 'message' => ''];
    }

    $snapshot = history_get_snapshot($historyKey, $timestamp);
    if (!$snapshot) {
        return ['success' => false, 'error' => 'Версия не найдена.', 'message' => ''];
    }

    // Снапшот текущего состояния — чтобы откат был обратимым
    history_save_snapshot($current, $snapshot, $_SESSION['admin_login'] ?? 'system');

    $newPage = $current;

    // Восстанавливаем только контентные поля
    foreach (history_content_fields() as $field) {
        if (array_key_exists($field, $snapshot)) {
            $newPage[$field] = $snapshot[$field];
        }
    }

    // Служебные поля — принудительно из текущей
    $newPage['id']            = $current['id'];
    $newPage['slug']          = $current['slug'] ?? '';
    $newPage['history_key']   = $historyKey;

    if (array_key_exists('preview_token', $current)) {
        $newPage['preview_token'] = $current['preview_token'];
    }

    // Хук «до восстановления версии» (для будущих плагинов)
    do_action('page_before_restore', $pageId);

    if (!savePageData($pageId, $newPage)) {
        return ['success' => false, 'error' => 'Не удалось сохранить восстановленную версию.', 'message' => ''];
    }

    clearPageCacheById($pageId);

    // Плагины: страница восстановлена к версии истории
    do_action('page_restored', $pageId);

    $dateStr = date('d.m.Y H:i', $timestamp);
    return [
        'success' => true,
        'error'   => '',
        'message' => 'Страница восстановлена к версии от ' . $dateStr . '.',
    ];
}

/**
 * POST-обработчик: откат страницы к версии истории.
 *
 * @param string $pageId
 * @param int    $timestamp
 * @return void
 */
function history_handle_restore(string $pageId, int $timestamp): void {
    $result = history_restore_page($pageId, $timestamp);

    if ($result['success']) {
        logAction('page_restore', 'Страница "' . $pageId . '" восстановлена к версии от ' . date('d.m.Y H:i', $timestamp), 'INFO');
        setFlash($result['message']);
    } else {
        logAction('page_restore', 'Ошибка отката: ' . $result['error'] . ' (ID: ' . $pageId . ', ts: ' . $timestamp . ')', 'ERROR');
        setFlash($result['error'], 'error');
    }

    header('Location: ?tab=pages&action=edit&id=' . urlencode($pageId));
    exit;
}

/**
 * POST-обработчик: удаление одной версии истории.
 *
 * @param string $pageId
 * @param int    $timestamp
 * @return void
 */
function history_handle_delete_version(string $pageId, int $timestamp): void {
    $page = loadPageById($pageId);
    if (!$page || !preg_match('/^[a-z0-9\-_]+$/i', $pageId)) {
        setFlash('Страница не найдена.', 'error');
        header('Location: ?tab=pages');
        exit;
    }

    $historyKey = (string)($page['history_key'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/i', $historyKey)) {
        setFlash('У страницы нет истории.', 'error');
        header('Location: ?tab=pages&action=edit&id=' . urlencode($pageId));
        exit;
    }

    $result = history_delete_version($historyKey, $timestamp);

    if ($result['success']) {
        logAction('page_history_delete', 'Удалена версия истории страницы "' . $pageId . '" (ts: ' . $timestamp . ')', 'INFO');
        setFlash('Версия удалена.');
    } else {
        logAction('page_history_delete', 'Ошибка удаления версии: ' . $result['error'] . ' (ID: ' . $pageId . ')', 'ERROR');
        setFlash($result['error'], 'error');
    }

    header('Location: ?tab=pages&action=edit&id=' . urlencode($pageId));
    exit;
}

/**
 * POST-обработчик: полная очистка истории одной страницы.
 *
 * @param string $pageId
 * @return void
 */
function history_handle_clear_page(string $pageId): void {
    $page = loadPageById($pageId);
    if (!$page || !preg_match('/^[a-z0-9\-_]+$/i', $pageId)) {
        setFlash('Страница не найдена.', 'error');
        header('Location: ?tab=pages');
        exit;
    }

    $historyKey = (string)($page['history_key'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/i', $historyKey)) {
        setFlash('У страницы нет истории.', 'error');
        header('Location: ?tab=pages&action=edit&id=' . urlencode($pageId));
        exit;
    }

    $deleted = history_clear_page($historyKey);

    if ($deleted > 0) {
        logAction('page_history_clear', 'Очищена история страницы "' . $pageId . '" (' . $deleted . ' версий)', 'INFO');
        setFlash('История страницы очищена. Удалено версий: ' . $deleted . '.');
    } else {
        setFlash('История уже пуста.');
    }

    header('Location: ?tab=pages&action=edit&id=' . urlencode($pageId));
    exit;
}

/**
 * AJAX-обработчик: полностью очищает историю всех страниц.
 *
 * @return void
 */
function history_handle_clear_all(): void {
    $deletedVersions = 0;
    $deletedPages    = 0;

    if (is_dir(HISTORY_DIR)) {
        $pageDirs = glob(HISTORY_DIR . '*', GLOB_ONLYDIR);
        if (is_array($pageDirs)) {
            foreach ($pageDirs as $dir) {
                $key = basename($dir);
                if (!preg_match('/^[a-f0-9]{16}$/i', $key)) {
                    continue;
                }

                $files = glob($dir . DIRECTORY_SEPARATOR . '*.json');
                if (is_array($files)) {
                    foreach ($files as $file) {
                        if (@unlink($file)) {
                            $deletedVersions++;
                        }
                    }
                }

                if (@rmdir($dir)) {
                    $deletedPages++;
                }
            }
        }
    }

    if ($deletedVersions > 0) {
        logAction('history_clear', 'История очищена: ' . $deletedPages . ' страниц, ' . $deletedVersions . ' версий', 'INFO');
    }

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => true,
        'deleted_pages'    => $deletedPages,
        'deleted_versions' => $deletedVersions,
        'message' => $deletedVersions > 0
            ? 'Удалено версий: ' . $deletedVersions . ' (страниц: ' . $deletedPages . ').'
            : 'История уже пуста.',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// history_key: новый странице — новый ключ, существующей — ключ из старой версии.
add_filter('page_data_before_save', function($pageData, $id, $oldPage) {
    if (!is_array($pageData)) {
        return $pageData;
    }

    $key = '';

    if (is_array($oldPage)) {
        $key = (string)($oldPage['history_key'] ?? '');
    }

    if (!preg_match('/^[a-f0-9]{16}$/i', $key)) {
        $key = bin2hex(random_bytes(8));
    }

    $pageData['history_key'] = $key;
    return $pageData;
}, 10, 3);

// Снапшот текущего состояния — до перезаписи файла страницы.
add_action('page_before_save', function($id, $newPage, $oldPage) {
    if (!is_array($oldPage) || empty($oldPage)) {
        return;
    }

    history_save_snapshot($oldPage, $newPage, $_SESSION['admin_login'] ?? 'system');
}, 10, 3);

// Клон получает собственный ключ — иначе две страницы делили бы одну историю.
add_action('page_cloned', function($sourceId, $newId) {
    $clone = loadPageById($newId);
    if (!$clone) {
        return;
    }

    $clone['history_key'] = bin2hex(random_bytes(8));
    savePageData($newId, $clone);
}, 10, 2);

// Окончательное удаление страницы из корзины — чистим её историю.
add_action('trash_item_purged', function($trashData) {
    if (!is_array($trashData)) {
        return;
    }

    if (($trashData['_trash']['type'] ?? '') !== 'page') {
        return;
    }

    $key = (string)($trashData['history_key'] ?? '');
    if (preg_match('/^[a-f0-9]{16}$/i', $key)) {
        history_clear_page($key);
    }
});

// POST-действия истории. CSRF проверяет ядро до admin_init.
add_action('admin_init', function() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    if (isset($_POST['restore_page_version'])) {
        history_handle_restore($_POST['page_id'] ?? '', intval($_POST['version_ts'] ?? 0));
    } elseif (isset($_POST['delete_history_version'])) {
        history_handle_delete_version($_POST['page_id'] ?? '', intval($_POST['version_ts'] ?? 0));
    } elseif (isset($_POST['clear_page_history'])) {
        history_handle_clear_page($_POST['page_id'] ?? '');
    } elseif (isset($_POST['clear_all_history'])) {
        history_handle_clear_all();
    }
});

// Кнопка «Открыть историю» в форме редактирования страницы.
add_action('edit_page_history_block', function($editPage) {
    if (!history_is_enabled()) {
        return;
    }

    $historyKey = (string)($editPage['history_key'] ?? '');
    $historyCount = ($historyKey !== '' && preg_match('/^[a-f0-9]{16}$/i', $historyKey))
        ? count(history_get_list($historyKey))
        : 0;
    ?>
    <div class="editor-row" style="align-items: flex-start !important;">
        <div class="editor-field">
            <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                История изменений
            </label>
            <button type="button"
                    onclick="window.openHistoryModal()"
                    class="w-full lg:w-auto px-4 py-2.5 bg-slate-100 border border-slate-200 text-slate-700 text-sm font-bold rounded-xl hover:bg-slate-200 transition-all whitespace-nowrap flex items-center justify-center gap-2">
                <span class="icon-history text-sm"></span>
                Открыть историю
                <?php if ($historyCount > 0): ?>
                    <span class="px-2 py-0.5 bg-slate-700 text-white text-[10px] font-bold rounded-full"><?php echo $historyCount; ?></span>
                <?php endif; ?>
            </button>
            <p class="text-[10px] text-slate-400 mt-2">
                Сохранённые версии страницы. Откат восстанавливает контент, не меняя URL и preview-ссылку.
            </p>
        </div>
    </div>
    <?php
}, 10, 1);

// Модалка истории на странице редактирования.
add_action('edit_page_modals', function($pageId) {
    if (!history_is_enabled()) {
        return;
    }

    include __DIR__ . '/admin-modal.php';
}, 10, 1);

// Секция настроек «История изменений» в Настройках сайта.
register_plugin_section('history', 'История изменений', function() {
    include __DIR__ . '/admin-section.php';
});

// Сохранение настроек плагина.
add_filter('save_settings_data', function($newSettings) {
    $defaults = [
        'history_enabled' => false,
        'history_limit'   => 20,
    ];
    $fields = [
        'history_enabled',
        'history_limit',
    ];

    save_plugin_settings($newSettings, 'history_enabled', $defaults, $fields);
    return $newSettings;
});

// Действия логирования.
register_log_action('page_restore', 'Откат страницы к версии', 'История', 'history');
register_log_action('page_history_delete', 'Удаление версии истории', 'История', 'history');
register_log_action('page_history_clear', 'Очистка истории страницы', 'История', 'history');
register_log_action('history_clear', 'Очистка всей истории', 'История', 'history');

// Удаление плагина — сбрасываем только свои настройки, data/history/ остаётся.
add_action('plugin_before_delete', function($id) {
    if ($id !== 'history') {
        return;
    }

    $settings = getSettingsData();
    unset($settings['history_enabled'], $settings['history_limit']);
    saveData('settings', $settings);
});
