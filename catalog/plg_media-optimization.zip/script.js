/**
 * Медиа (WebP) — AJAX-скрипты для админки
 */
(function() {
    'use strict';

    /**
     * Удаление всех сгенерированных .webp
     */
    window.deleteAllWebp = function() {
        if (!confirm('Удалить все .webp-файлы, у которых есть оригинал? Оригиналы останутся.')) {
            return;
        }

        // Находим кнопку и блокируем её
        const btn = event.target.closest('button');
        const originalText = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="icon-loader animate-spin text-sm"></span> Удаление...';

        const formData = new FormData();
        formData.append('csrf_token', window.mediaOptimizationCsrfToken || '');
        formData.append('delete_all_webp', '1');

        fetch('index.php?tab=config_vars', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
                location.reload();
            } else {
                alert('Ошибка: ' + data.error);
                btn.disabled = false;
                btn.innerHTML = originalText;
            }
        })
        .catch(() => {
            alert('Ошибка соединения.');
            btn.disabled = false;
            btn.innerHTML = originalText;
        });
    };

    /**
     * Массовая конвертация существующих изображений шагами
     */
    window.convertExistingImages = function() {
        if (!confirm('Конвертировать все jpg/png без .webp? Оригиналы сохранятся.')) {
            return;
        }

        const btn = event.target.closest('button');
        const progressBox = document.getElementById('webp-convert-progress');
        const statusEl = document.getElementById('webp-convert-status');
        const percentEl = document.getElementById('webp-convert-percent');
        const barEl = document.getElementById('webp-convert-bar');

        btn.disabled = true;
        btn.innerHTML = '<span class="icon-loader animate-spin text-sm"></span> Обработка...';
        progressBox.classList.remove('hidden');

        let step = 0;

        function processStep() {
            const formData = new FormData();
            formData.append('csrf_token', window.mediaOptimizationCsrfToken || '');
            formData.append('convert_existing_images_step', '1');
            formData.append('step', step);
            formData.append('per_step', 10);

            fetch('index.php?tab=config_vars', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (!data.success) {
                    alert('Ошибка: ' + data.error);
                    btn.disabled = false;
                    btn.innerHTML = 'Конвертировать существующие';
                    return;
                }

                const percent = data.total > 0 ? Math.round((data.processed / data.total) * 100) : 100;
                statusEl.textContent = `Обработано ${data.processed} из ${data.total}`;
                percentEl.textContent = percent + '%';
                barEl.style.width = percent + '%';

                if (data.is_finished) {
                    alert(`Готово! Сконвертировано файлов: ${data.converted}`);
                    location.reload();
                } else {
                    step++;
                    setTimeout(processStep, 100);
                }
            })
            .catch(() => {
                alert('Ошибка соединения.');
                btn.disabled = false;
                btn.innerHTML = 'Конвертировать существующие';
            });
        }

        processStep();
    };
})();