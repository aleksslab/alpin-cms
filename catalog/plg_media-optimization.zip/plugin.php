<?php
/**
 * Плагин: Медиа (WebP)
 *
 * Отвечает за конвертацию изображений в WebP, статистику и массовую обработку.
 * Функции вывода (mediaLazyAttrs, mediaImageSrc) остаются в ядре, так как
 * используются модулями для рендеринга.
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

// =========================================================================
// 1. ФУНКЦИИ КОНВЕРТАЦИИ И СТАТИСТИКИ
// =========================================================================

/**
 * Проверяет, доступна ли конвертация в WebP на этом сервере.
 * Результат кешируется в памяти.
 *
 * @return bool true, если есть GD с imagewebp или Imagick с WebP
 */
function isWebpSupported(): bool {
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    if (extension_loaded('gd') && function_exists('imagewebp')) {
        return $cache = true;
    }
    if (extension_loaded('imagick')) {
        try {
            $formats = Imagick::queryFormats('WEBP');
            return $cache = !empty($formats);
        } catch (Exception $e) {
            return $cache = false;
        }
    }
    return $cache = false;
}

/**
 * Конвертирует изображение в WebP.
 * Создаёт файл foo.webp рядом с оригиналом. Оригинал НЕ удаляется.
 * Если .webp уже существует — возвращает его путь без перезаписи.
 *
 * @param string $sourcePath Полный путь к исходному файлу
 * @param int    $quality    Качество (1..100), по умолчанию 82
 * @return string|null Путь к .webp или null при ошибке
 */
function convertToWebp(string $sourcePath, int $quality = 82): ?string {
    if (!is_file($sourcePath)) {
        return null;
    }

    $ext = strtolower(pathinfo($sourcePath, PATHINFO_EXTENSION));

    // Только jpg / jpeg / png
    if (!in_array($ext, ['jpg', 'jpeg', 'png'], true)) {
        return null;
    }

    $quality = max(1, min(100, $quality));

    // Целевой путь: foo.jpg → foo.webp
    $targetPath = preg_replace('#\.(jpe?g|png)$#i', '.webp', $sourcePath);

    // Если .webp уже есть — не перезаписываем
    if (is_file($targetPath)) {
        return $targetPath;
    }

    try {
        // GD (приоритет)
        if (extension_loaded('gd') && function_exists('imagewebp')) {
            $image = null;
            if ($ext === 'png') {
                $image = @imagecreatefrompng($sourcePath);
            } else {
                $image = @imagecreatefromjpeg($sourcePath);
            }

            if ($image === false) {
                return null;
            }

            if ($ext === 'png') {
                imagepalettetotruecolor($image);
                imagealphablending($image, true);
                imagesavealpha($image, true);
            }

            $ok = @imagewebp($image, $targetPath, $quality);
            imagedestroy($image);

            if (!$ok || !is_file($targetPath)) {
                @unlink($targetPath);
                return null;
            }

            return $targetPath;
        }

        // Imagick (fallback)
        if (extension_loaded('imagick')) {
            $im = new Imagick($sourcePath);
            $im->setImageFormat('webp');
            $im->setImageCompressionQuality($quality);
            $im->writeImage($targetPath);
            $im->clear();
            $im->destroy();

            if (!is_file($targetPath)) {
                return null;
            }

            return $targetPath;
        }

    } catch (Exception $e) {
        if (is_file($targetPath)) {
            @unlink($targetPath);
        }
        return null;
    }

    return null;
}

/**
 * Считает, сколько jpg/png-файлов (в images/ и корне) не имеют парного .webp.
 *
 * @return int Количество файлов без .webp
 */
function countImagesWithoutWebp(): int {
    $files = array_merge(
        getImageFiles(APP_ROOT . DIRECTORY_SEPARATOR . 'images', true),
        getImageFiles(APP_ROOT, false)
    );

    $seen = [];
    $count = 0;

    foreach ($files as $original) {
        $real = realpath($original);
        if ($real === false || isset($seen[$real])) continue;
        $seen[$real] = true;

        $webp = preg_replace('#\.(jpe?g|png)$#i', '.webp', $original);
        if (!is_file($webp)) {
            $count++;
        }
    }

    return $count;
}

/**
 * Рекурсивно собирает файлы jpg/jpeg/png в директории.
 *
 * @param string $rootDir   Путь к директории
 * @param bool   $recursive true — обходить подпапки, false — только верхний уровень
 * @return array Массив абсолютных путей к файлам
 */
function getImageFiles(string $rootDir, bool $recursive = true): array {
    if (!is_dir($rootDir)) {
        return [];
    }

    if (!$recursive) {
        return array_merge(
            glob($rootDir . DIRECTORY_SEPARATOR . '*.jpg') ?: [],
            glob($rootDir . DIRECTORY_SEPARATOR . '*.jpeg') ?: [],
            glob($rootDir . DIRECTORY_SEPARATOR . '*.png') ?: []
        );
    }

    $files = [];
    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($rootDir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($iterator as $file) {
            if (!$file->isFile()) continue;
            $ext = strtolower($file->getExtension());
            if (in_array($ext, ['jpg', 'jpeg', 'png'], true)) {
                $files[] = $file->getPathname();
            }
        }
    } catch (Exception $e) {
        return [];
    }

    return $files;
}

/**
 * Собирает статистику по .webp-файлам в images/ и корне сайта.
 * Считает только .webp, у которых есть "парный" оригинал.
 *
 * @return array ['count' => int, 'size_bytes' => int]
 */
function getWebpStats(): array {
    $stats = ['count' => 0, 'size_bytes' => 0];

    $files = array_merge(
        getImageFiles(APP_ROOT . DIRECTORY_SEPARATOR . 'images', true),
        getImageFiles(APP_ROOT, false)
    );

    $seen = [];

    foreach ($files as $original) {
        $webp = preg_replace('#\.(jpe?g|png)$#i', '.webp', $original);
        if (!is_file($webp)) continue;

        $real = realpath($webp);
        if ($real === false || isset($seen[$real])) continue;
        $seen[$real] = true;

        $stats['count']++;
        $size = @filesize($webp);
        if ($size !== false) {
            $stats['size_bytes'] += $size;
        }
    }

    return $stats;
}

/**
 * Удаляет все .webp-файлы, у которых есть "парный" оригинал.
 * Оригиналы (jpg/png) НЕ удаляются.
 *
 * @return array ['deleted' => int, 'kept' => int, 'error' => string]
 */
function deleteAllWebp(): array {
    $deleted = 0;
    $kept = 0;
    $errors = 0;

    $webpFiles = [];

    // images/ — рекурсивно
    $imagesDir = APP_ROOT . DIRECTORY_SEPARATOR . 'images';
    if (is_dir($imagesDir)) {
        try {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($imagesDir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($iterator as $file) {
                if ($file->isFile() && strtolower($file->getExtension()) === 'webp') {
                    $webpFiles[] = $file->getPathname();
                }
            }
        } catch (Exception $e) {
            // ignore
        }
    }

    // корень — только верхний уровень
    $rootWebp = glob(APP_ROOT . DIRECTORY_SEPARATOR . '*.webp') ?: [];
    $webpFiles = array_merge($webpFiles, $rootWebp);

    $seen = [];

    foreach ($webpFiles as $webp) {
        $real = realpath($webp);
        if ($real === false || isset($seen[$real])) continue;
        $seen[$real] = true;

        $base = substr($webp, 0, -5);

        $hasOriginal = false;
        foreach (['.jpg', '.jpeg', '.png'] as $ext) {
            if (is_file($base . $ext)) {
                $hasOriginal = true;
                break;
            }
        }

        if (!$hasOriginal) {
            $kept++;
            continue;
        }

        if (@unlink($webp)) {
            $deleted++;
        } else {
            $errors++;
        }
    }

    $error = '';
    if ($errors > 0) {
        $error = 'Не удалось удалить файлов: ' . $errors . '.';
    }

    return ['deleted' => $deleted, 'kept' => $kept, 'error' => $error];
}

/**
 * Конвертирует пачку существующих изображений (jpg/png без .webp).
 * Используется AJAX-шагами.
 *
 * @param int $step    Номер шага (0-based)
 * @param int $perStep Сколько файлов за шаг (1..50)
 * @return array ['processed' => int, 'converted' => int, 'total' => int, 'is_finished' => bool]
 */
function convertExistingImagesStep(int $step, int $perStep = 10): array {
    $perStep = max(1, min(50, $perStep));
    $step = max(0, $step);

    $allFiles = array_merge(
        getImageFiles(APP_ROOT . DIRECTORY_SEPARATOR . 'images', true),
        getImageFiles(APP_ROOT, false)
    );

    $seen = [];
    $pending = [];

    foreach ($allFiles as $file) {
        $real = realpath($file);
        if ($real === false || isset($seen[$real])) continue;
        $seen[$real] = true;

        $webp = preg_replace('#\.(jpe?g|png)$#i', '.webp', $file);
        if (!is_file($webp)) {
            $pending[] = $file;
        }
    }

    $total = count($pending);
    $offset = $step * $perStep;
    $slice = array_slice($pending, $offset, $perStep);

    $settings = getSettingsData();
    $quality = max(1, min(100, (int)($settings['media_quality'] ?? 82)));

    $converted = 0;
    foreach ($slice as $file) {
        if (convertToWebp($file, $quality) !== null) {
            $converted++;
        }
    }

    $processed = $offset + count($slice);
    $isFinished = $processed >= $total;

    return [
        'processed'   => $processed,
        'converted'   => $converted,
        'total'       => $total,
        'is_finished' => $isFinished,
    ];
}

// =========================================================================
// 2. AJAX-ОБРАБОТЧИКИ
// =========================================================================

add_action('admin_init', function() {
    // Удаление всех .webp
    if (isset($_POST['delete_all_webp'])) {
        header('Content-Type: application/json; charset=utf-8');
        $result = deleteAllWebp();

        if ($result['deleted'] > 0) {
            logAction('media_webp_delete', 'Удалено .webp: ' . $result['deleted'] . ' (оставлено без оригинала: ' . $result['kept'] . ')', 'INFO');
        }

        $message = 'Удалено .webp: ' . $result['deleted'] . '.';
        if ($result['kept'] > 0) {
            $message .= ' Оставлено (нет оригинала): ' . $result['kept'] . '.';
        }
        if (!empty($result['error'])) {
            $message .= ' ' . $result['error'];
        }

        echo json_encode([
            'success' => true,
            'deleted' => $result['deleted'],
            'kept'    => $result['kept'],
            'error'   => $result['error'],
            'message' => $message,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Конвертация шагами
    if (isset($_POST['convert_existing_images_step'])) {
        header('Content-Type: application/json; charset=utf-8');

        if (!isWebpSupported()) {
            echo json_encode([
                'success' => false,
                'error'   => 'WebP-конвертация не поддерживается на этом сервере.',
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $step = intval($_POST['step'] ?? 0);
        $perStep = intval($_POST['per_step'] ?? 10);

        $result = convertExistingImagesStep($step, $perStep);

        echo json_encode([
            'success'     => true,
            'processed'   => $result['processed'],
            'converted'   => $result['converted'],
            'total'       => $result['total'],
            'is_finished' => $result['is_finished'],
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
});

// =========================================================================
// 3. РЕГИСТРАЦИЯ СЕКЦИИ И СОХРАНЕНИЕ НАСТРОЕК
// =========================================================================

// Регистрируем секцию в настройках сайта
register_plugin_section('media', 'Медиа (WebP)', function() {
    include __DIR__ . '/admin-section.php';
});

// Сохранение настроек
add_filter('save_settings_data', function($newSettings) {
    // Если форма плагина отправлялась (проверяем по полю media_quality)
    if (isset($_POST['media_quality']) || isset($_POST['media_webp_enabled'])) {
        $newSettings['media_lazy_enabled'] = isset($_POST['media_lazy_enabled']) && $_POST['media_lazy_enabled'] == '1';
        $newSettings['media_webp_enabled'] = isWebpSupported() && isset($_POST['media_webp_enabled']) && $_POST['media_webp_enabled'] == '1';
        $newSettings['media_quality'] = max(1, min(100, intval($_POST['media_quality'] ?? 82)));
    } else {
        // Если форма не отправлялась — сохраняем старые значения
        $current = getSettingsData();
        $newSettings['media_lazy_enabled'] = !empty($current['media_lazy_enabled']);
        $newSettings['media_webp_enabled'] = !empty($current['media_webp_enabled']);
        $newSettings['media_quality'] = $current['media_quality'] ?? 82;
    }
    return $newSettings;
});