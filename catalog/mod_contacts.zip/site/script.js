/**
 * Контакты — скрипты для сайта
 */
(function() {
    'use strict';

    let isSubmitting = false;

    function initContacts() {
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                if (isSubmitting) return;
                sendContactForm(e.target);
            });
        }

        initMaps();
    }

    /**
     * Разрешена ли категория «Функциональные».
     *
     * Без плагина согласия карта грузится как раньше.
     *
     * @returns {boolean}
     */
    function isConsentAllowed() {
        if (!window.AlpinConsent || typeof window.AlpinConsent.isAllowed !== 'function') {
            return true;
        }

        return window.AlpinConsent.isAllowed('functional');
    }

    /**
     * Отклонил ли посетитель категорию «Функциональные».
     *
     * Отличается от «ещё не спрашивали»: до первого согласия false.
     *
     * @returns {boolean}
     */
    function isConsentDenied() {
        return !!window.AlpinConsent
            && typeof window.AlpinConsent.isDenied === 'function'
            && window.AlpinConsent.isDenied('functional');
    }

    /**
     * Показывает причину заглушки: запрет в настройках cookie или вопрос.
     *
     * @param {Element} container
     * @returns {void}
     */
    function syncConsentNotice(container) {
        const denied = isConsentDenied();
        const defaultText = container.querySelector('[data-consent-text-default]');
        const deniedText = container.querySelector('[data-consent-text-denied]');
        const openBtn = container.querySelector('[data-consent-open]');

        if (defaultText) {
            defaultText.hidden = denied;
        }
        if (deniedText) {
            deniedText.hidden = !denied;
        }
        if (openBtn) {
            openBtn.hidden = !denied;
        }
    }

    /**
     * Вставляет iframe карты вместо заглушки.
     *
     * @param {Element} container
     * @returns {void}
     */
    function loadMap(container) {
        const src = container.getAttribute('data-map-src');
        if (!src || container.querySelector('iframe')) {
            return;
        }

        const placeholder = container.querySelector('.contacts-map__consent');
        if (placeholder) {
            placeholder.hidden = true;
        }

        const iframe = document.createElement('iframe');
        iframe.src = src;
        iframe.width = '100%';
        iframe.height = '100%';
        iframe.loading = 'lazy';
        iframe.setAttribute('allowfullscreen', '');
        iframe.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
        iframe.setAttribute('title', container.getAttribute('data-map-title') || 'Карта');
        iframe.style.border = '0';
        iframe.style.display = 'block';

        container.appendChild(iframe);
    }

    /**
     * Показывает заглушку с кнопкой вместо карты.
     *
     * @param {Element} container
     * @returns {void}
     */
    function showMapPlaceholder(container) {
        const placeholder = container.querySelector('.contacts-map__consent');
        if (placeholder) {
            placeholder.hidden = false;
        }
        syncConsentNotice(container);
    }

    /**
     * Карты на странице: при согласии грузим сразу, иначе показываем заглушку.
     *
     * @returns {void}
     */
    function initMaps() {
        document.querySelectorAll('.contacts-map').forEach(function(container) {
            if (isConsentAllowed()) {
                loadMap(container);
                return;
            }

            showMapPlaceholder(container);
        });
    }

    // Кнопка «Показать карту»: разовая загрузка, сохранённое решение не меняет.
    document.addEventListener('click', function(event) {
        if (!event.target || !event.target.closest) return;

        const trigger = event.target.closest('[data-map-consent-load]');
        if (!trigger) return;

        event.preventDefault();

        const container = trigger.closest('.contacts-map');
        if (container) {
            loadMap(container);
        }
    });

    // Согласие выдали на этой же странице — карту можно грузить сразу.
    // Решение отозвали — обновляем причину заглушки (без перезагрузки,
    // если решения раньше не было).
    document.addEventListener('alpin:consent', function() {
        document.querySelectorAll('.contacts-map').forEach(function(container) {
            if (isConsentAllowed()) {
                loadMap(container);
                return;
            }

            if (!container.querySelector('iframe')) {
                showMapPlaceholder(container);
            }
        });
    });

    // Кнопка «Настройки cookie» на заглушке открывает панель плагина.
    document.addEventListener('click', function(event) {
        if (!event.target || !event.target.closest) return;

        const trigger = event.target.closest('[data-consent-open]');
        if (!trigger) return;

        event.preventDefault();

        if (window.AlpinConsent && typeof window.AlpinConsent.open === 'function') {
            window.AlpinConsent.open();
        }
    });

    function sendContactForm(form) {
        if (isSubmitting) return;
        isSubmitting = true;

        const fields = document.getElementById('formFields');
        const messagesContainer = document.getElementById('contacts-form-messages');
        if (!fields || !messagesContainer) {
            isSubmitting = false;
            return;
        }

        const container = messagesContainer.closest('.id-form-container') || messagesContainer.parentElement;
        const originalHeight = container.offsetHeight;
        const originalWidth = container.offsetWidth;

        container.style.minHeight = originalHeight + 'px';
        container.style.minWidth = originalWidth + 'px';

        messagesContainer.innerHTML = '';

        const formData = new FormData(form);
        formData.append('module', 'contacts');
        
        // Находим заголовок модуля
        const headerEl = document.querySelector('.contacts-module h2') || document.querySelector('.grid h2');
        formData.append('module_title', headerEl ? headerEl.textContent : 'Контактная форма');
        
        fields.classList.add('hidden');

        const loader = document.createElement('div');
        loader.id = 'form-loading-contacts';
        loader.className = 'w-full py-12 flex flex-col items-center justify-center text-center space-y-4 animate-fade-in';
        loader.innerHTML = `
            <span class="loader"></span>
            <p class="text-slate-500 font-medium text-sm tracking-wide uppercase">Отправка вашего обращения...</p>
        `;
        messagesContainer.appendChild(loader);

        fetch('includes/mailer.php', {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            if (!response.ok) throw new Error();
            return response.json();
        })
        .then(function(data) {
            const loaderEl = document.getElementById('form-loading-contacts');
            if (loaderEl) loaderEl.remove();

            const isSuccess = data.status === 'success';
            const borderClass = isSuccess ? 'border-emerald-100' : 'border-slate-200';
            const icon = isSuccess ? 'icon-shield-check text-emerald-500' : 'icon-x text-slate-400';
            const text = isSuccess ? 'text-[var(--primary-dark)]' : 'text-slate-800';

            const msg = document.createElement('div');
            msg.className = `form-messages w-full bg-white border ${borderClass} p-8 rounded-2xl flex flex-col items-center justify-center text-center space-y-4 shadow-sm animate-fade-in`;
            msg.innerHTML = `
                <div class="w-14 h-14 rounded-full bg-slate-50 flex items-center justify-center shadow-inner">
                    <span class="${icon} text-2xl"></span>
                </div>
                <h4 class="text-xl font-bold ${text}"></h4>
                <p class="text-slate-600 text-sm font-medium leading-relaxed max-w-sm"></p>
            `;
            const headEl = msg.querySelector('h4');
            const messageEl = msg.querySelector('p');
            if (headEl) headEl.textContent = data.head || '';
            if (messageEl) messageEl.textContent = data.message || '';
            messagesContainer.appendChild(msg);

            if (isSuccess) form.reset();
        })
        .catch(function() {
            const loaderEl = document.getElementById('form-loading-contacts');
            if (loaderEl) loaderEl.remove();

            const msg = document.createElement('div');
            msg.className = 'form-messages w-full bg-white border border-slate-200 p-8 rounded-2xl flex flex-col items-center justify-center text-center space-y-4 shadow-sm';
            msg.innerHTML = `
                <div class="w-14 h-14 rounded-full bg-slate-50 flex items-center justify-center shadow-inner">
                    <span class="icon-x text-rose-500 text-2xl"></span>
                </div>
                <h4 class="text-xl font-bold text-slate-800">Ошибка соединения</h4>
                <p class="text-slate-600 text-sm font-medium leading-relaxed max-w-sm">Не удалось отправить обращение. Проверьте интернет или попробуйте позже.</p>
            `;
            messagesContainer.appendChild(msg);
        })
        .finally(function() {
            setTimeout(function() {
                messagesContainer.innerHTML = '';
                fields.classList.remove('hidden');
                container.style.minHeight = '';
                container.style.minWidth = '';
                isSubmitting = false;
            }, 10000);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initContacts);
    } else {
        initContacts();
    }
})();