<?php
/**
 * Плагин: Проводник (файлы)
 *
 * Файловый менеджер админки: просмотр структуры проекта, загрузка файлов,
 * правка кода (ACE), CHMOD, создание и удаление объектов.
 *
 * Серверная часть собрана в fm*-функции ниже. Точка входа — fm_handle_api_request()
 * на admin_init: при наличии GET-параметра fm_api_action отдаёт JSON и завершает запрос.
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

// =========================================================================
// 1. БЕЗОПАСНОСТЬ ПУТЕЙ И ВВОДА
// =========================================================================

/**
 * Возвращает строковый POST-параметр (защита от массивов в $_POST).
 *
 * @param string $key Имя параметра
 * @return string
 */
function fmPostString(string $key): string {
    $value = $_POST[$key] ?? '';
    return is_string($value) ? $value : '';
}

/**
 * Возвращает строковый GET-параметр (защита от массивов в $_GET).
 *
 * @param string $key Имя параметра
 * @return string
 */
function fmGetString(string $key): string {
    $value = $_GET[$key] ?? '';
    return is_string($value) ? $value : '';
}

/**
 * Возвращает POST-параметр как массив (защита от строк в $_POST).
 *
 * @param string $key Имя параметра
 * @return array
 */
function fmPostArray(string $key): array {
    $value = $_POST[$key] ?? [];
    return is_array($value) ? $value : [];
}

/**
 * Безопасно нормализует и проверяет относительный путь.
 * Возвращает нормализованный путь или null при небезопасном значении.
 *
 * @param string $path Путь из запроса
 * @return string|null
 */
function fmSafePath(string $path): ?string {
    $path = str_replace('\\', '/', $path);
    $path = trim($path, '/');

    if ($path === '') {
        return '';
    }

    // Whitelist символов
    if (!preg_match('#^[a-zA-Z0-9\-_./]+$#', $path)) {
        return null;
    }

    // Запрет на .., //, начало с /
    if (strpos($path, '..') !== false || strpos($path, '//') !== false) {
        return null;
    }

    return $path;
}

/**
 * Безопасно собирает абсолютный путь внутри APP_ROOT.
 * Возвращает абсолютный путь или null при выходе за пределы.
 *
 * @param string $relativePath Нормализованный относительный путь
 * @return string|null
 */
function fmSafeAbsolute(string $relativePath): ?string {
    $realRoot = realpath(APP_ROOT);
    if ($realRoot === false) {
        return null;
    }

    $full = APP_ROOT;
    if ($relativePath !== '') {
        $full .= DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
    }

    // Проверяем, что итоговый путь внутри APP_ROOT
    $check = file_exists($full) ? realpath($full) : realpath(dirname($full));

    if ($check === false) {
        return null;
    }

    // На Windows регистр не важен — нормализуем
    if (DIRECTORY_SEPARATOR === '\\') {
        if (stripos($check, $realRoot) !== 0) {
            return null;
        }
    } else {
        if (strpos($check, $realRoot) !== 0) {
            return null;
        }
    }

    return $full;
}

/**
 * Проверяет, попадает ли путь в blacklist (config/data, config/backups, config/core).
 *
 * @param string $relativePath Нормализованный относительный путь
 * @return bool true — путь запрещён
 */
function fmIsBlacklisted(string $relativePath): bool {
    // Базовый blacklist: системные папки + оба варианта логов (старый и новый)
    $blacklist = ['config/data', 'config/backups', 'config/core', 'config/logs', 'data/logs'];

    // Пользовательский путь к логам (если задан и находится внутри APP_ROOT)
    $logSettings = function_exists('getLogSettings') ? getLogSettings() : [];
    $customLogPath = trim($logSettings['storage_path'] ?? '');
    if ($customLogPath !== '') {
        $realRoot = realpath(APP_ROOT);
        $realLogs = realpath($customLogPath);
        if ($realRoot !== false && $realLogs !== false && strpos($realLogs, $realRoot) === 0) {
            $relativeLogs = str_replace('\\', '/', trim(str_replace($realRoot, '', $realLogs), '/\\'));
            if ($relativeLogs !== '' && !in_array($relativeLogs, $blacklist, true)) {
                $blacklist[] = $relativeLogs;
            }
        }
    }

    $normalized = str_replace('\\', '/', $relativePath);

    foreach ($blacklist as $blocked) {
        if ($normalized === $blocked || strpos($normalized, $blocked . '/') === 0) {
            return true;
        }
    }

    return false;
}

/**
 * Проверяет расширение файла по whitelist (для get_code/save_code).
 *
 * @param string $fileName Имя файла
 * @return bool true — расширение разрешено
 */
function fmIsAllowedExtension(string $fileName): bool {
    $allowed = ['php', 'css', 'js', 'json', 'html', 'htm', 'txt', 'md', 'xml', 'svg', 'htaccess'];

    if ($fileName === '.htaccess') {
        return true;
    }

    $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    return in_array($ext, $allowed, true);
}

/**
 * Проверяет, является ли файл чувствительным (по имени).
 *
 * Базовый список хранит плагин; другие плагины добавляют свои файлы
 * через фильтр sensitive_files.
 *
 * @param string $fileName Имя файла
 * @return bool true — файл запрещён
 */
function fmIsSensitiveFile(string $fileName): bool {
    $sensitive = apply_filters('sensitive_files', [
        '.pepper',
        'credentials.json',
        'login_attempts.json',
    ]);

    return is_array($sensitive) && in_array($fileName, $sensitive, true);
}

/**
 * Форматирует путь для записи в лог: пустой путь — корень сайта.
 *
 * @param string $relativePath Нормализованный относительный путь
 * @return string
 */
function fmLogPath(string $relativePath): string {
    return $relativePath === '' ? '/' : $relativePath;
}

/**
 * Возвращает слово «файл» в правильной форме для числа.
 *
 * @param int $count Количество файлов
 * @return string
 */
function fmFilesWord(int $count): string {
    $mod100 = $count % 100;
    $mod10  = $count % 10;

    if ($mod100 >= 11 && $mod100 <= 14) {
        return 'файлов';
    }
    if ($mod10 === 1) {
        return 'файл';
    }
    if ($mod10 >= 2 && $mod10 <= 4) {
        return 'файла';
    }

    return 'файлов';
}

// =========================================================================
// 2. JSON-ОТВЕТ
// =========================================================================

/**
 * Отправляет JSON-ответ и завершает запрос.
 *
 * @param array $payload  Тело ответа
 * @param int   $httpCode HTTP-код (0 — не менять)
 * @return void
 */
function fmRespond(array $payload, int $httpCode = 0): void {
    if ($httpCode > 0) {
        http_response_code($httpCode);
    }

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// =========================================================================
// 3. ДЕЙСТВИЯ
// =========================================================================

/**
 * Сканирование директории: папки и файлы с размером, датой и правами.
 *
 * @param string $requestedDir    Относительный путь запрошенной папки
 * @param string $currentFullPath Абсолютный путь запрошенной папки
 * @return void
 */
function fmActionList(string $requestedDir, string $currentFullPath): void {
    $foldersList = [];
    $filesList   = [];

    $items = scandir($currentFullPath);
    $jsonParentPath = '/' . (!empty($requestedDir) ? $requestedDir . '/' : '');

    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }

        $itemFullPath = $currentFullPath . DIRECTORY_SEPARATOR . $item;

        if (is_dir($itemFullPath)) {
            $foldersList[] = [
                'name'     => $item,
                'path'     => $jsonParentPath,
                'size'     => '—',
                'modified' => date('d.m.Y H:i', filemtime($itemFullPath)),
                'perms'    => substr(sprintf('%o', fileperms($itemFullPath)), -4),
            ];
        } elseif (is_file($itemFullPath)) {
            $ext   = strtolower(pathinfo($item, PATHINFO_EXTENSION));
            $bytes = filesize($itemFullPath);

            if ($bytes >= 1073741824) {
                $sizeStr = round($bytes / 1073741824, 2) . ' GB';
            } elseif ($bytes >= 1048576) {
                $sizeStr = round($bytes / 1048576, 2) . ' MB';
            } elseif ($bytes >= 1024) {
                $sizeStr = round($bytes / 1024, 2) . ' KB';
            } else {
                $sizeStr = $bytes . ' B';
            }

            $filesList[] = [
                'name'     => $item,
                'path'     => $jsonParentPath,
                'ext'      => $ext,
                'size'     => $sizeStr,
                'modified' => date('d.m.Y H:i', filemtime($itemFullPath)),
                'perms'    => substr(sprintf('%o', fileperms($itemFullPath)), -4),
            ];
        }
    }

    fmRespond([
        'currentDir' => $requestedDir,
        'folders'    => $foldersList,
        'files'      => $filesList,
    ]);
}

/**
 * Удаление файла или пустой папки.
 *
 * @return void
 */
function fmActionDelete(): void {
    $itemName    = fmPostString('name');
    $itemPathRaw = fmPostString('path');

    // Валидация itemName — только имя файла, без слэшей
    if (!preg_match('#^[a-zA-Z0-9\-_.]+$#', $itemName)) {
        logAction('file_delete', 'Невалидное имя: ' . $itemName, 'ERROR');
        fmRespond(['error' => 'Недопустимое имя файла']);
    }

    $itemPath = fmSafePath($itemPathRaw);
    if ($itemPath === null) {
        logAction('file_delete', 'Path traversal: ' . $itemPathRaw, 'ERROR');
        fmRespond(['error' => 'Недопустимый путь']);
    }

    // Blacklist
    $fullRelative = ($itemPath !== '' ? $itemPath . '/' : '') . $itemName;
    if (fmIsBlacklisted($fullRelative)) {
        logAction('file_delete', 'Попытка доступа к защищённой папке: ' . $fullRelative, 'ERROR');
        fmRespond(['error' => 'Доступ к этой папке запрещён']);
    }

    $basePath = fmSafeAbsolute($itemPath);
    if ($basePath === null) {
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $fullPath = $basePath . DIRECTORY_SEPARATOR . $itemName;

    if (!file_exists($fullPath)) {
        fmRespond(['error' => 'Файл или папка не найдены на сервере']);
    }

    if (is_dir($fullPath)) {
        $dirEntries = scandir($fullPath);
        if (count($dirEntries) > 2) {
            fmRespond(['error' => 'Нельзя удалить папку, пока внутри неё есть файлы или другие подкаталоги!']);
        }

        if (@rmdir($fullPath)) {
            fmRespond(['success' => 'Папка успешно удалена']);
        }

        fmRespond(['error' => 'Не удалось удалить папку. Проверьте права доступа на сервере.']);
    }

    if (is_file($fullPath)) {
        if (@unlink($fullPath)) {
            logAction('file_delete', 'Файл "' . $itemName . '" удалён (путь: ' . fmLogPath($itemPath) . ')', 'INFO');
            fmRespond(['success' => 'Файл успешно удален']);
        }

        logAction('file_delete', 'Ошибка удаления файла "' . $itemName . '"', 'ERROR');
        fmRespond(['error' => 'Не удалось удалить файл.']);
    }

    fmRespond(['error' => 'Неизвестный тип объекта']);
}

/**
 * Массовое удаление файлов в одной папке.
 *
 * Принимает path (родительская папка) и names[] (имена файлов).
 * Папки не удаляются — такие имена попадают в errors.
 *
 * @return void
 */
function fmActionDeleteMany(): void {
    $itemPathRaw = fmPostString('path');
    $names       = fmPostArray('names');

    if (empty($names)) {
        fmRespond(['error' => 'Не выбрано ни одного файла']);
    }

    $itemPath = fmSafePath($itemPathRaw);
    if ($itemPath === null) {
        logAction('file_delete', 'Path traversal: ' . $itemPathRaw, 'ERROR');
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $basePath = fmSafeAbsolute($itemPath);
    if ($basePath === null) {
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $deleted = 0;
    $errors  = [];

    foreach ($names as $name) {
        if (!is_string($name) || !preg_match('#^[a-zA-Z0-9\-_.]+$#', $name)) {
            $errors[] = 'Невалидное имя: ' . (is_string($name) ? $name : '—');
            continue;
        }

        $fullRelative = ($itemPath !== '' ? $itemPath . '/' : '') . $name;
        if (fmIsBlacklisted($fullRelative)) {
            $errors[] = 'Доступ запрещён: ' . $name;
            continue;
        }

        $fullPath = $basePath . DIRECTORY_SEPARATOR . $name;

        // Массово удаляем только файлы: папки — по одной через контекстное меню
        if (!is_file($fullPath)) {
            $errors[] = 'Не файл: ' . $name;
            continue;
        }

        if (@unlink($fullPath)) {
            $deleted++;
        } else {
            $errors[] = 'Не удалось удалить: ' . $name;
        }
    }

    if ($deleted > 0) {
        logAction('file_delete', 'Удалено: ' . $deleted . ' ' . fmFilesWord($deleted) . ' (путь: ' . fmLogPath($itemPath) . ')', 'INFO');
    }

    if ($deleted === 0) {
        fmRespond([
            'error'   => 'Не удалось удалить файлы',
            'deleted' => 0,
            'errors'  => $errors,
        ]);
    }

    $message = 'Удалено: ' . $deleted . ' ' . fmFilesWord($deleted);
    if (!empty($errors)) {
        $message .= '. Пропущено: ' . count($errors);
    }

    fmRespond([
        'success' => true,
        'deleted' => $deleted,
        'message' => $message,
        'errors'  => $errors,
    ]);
}

/**
 * Переименование файла или папки.
 *
 * @return void
 */
function fmActionRename(): void {
    $oldName     = fmPostString('old_name');
    $newName     = fmPostString('new_name');
    $itemPathRaw = fmPostString('path');

    if (!preg_match('#^[a-zA-Z0-9\-_.]+$#', $oldName) || !preg_match('#^[a-zA-Z0-9\-_.]+$#', $newName)) {
        fmRespond(['error' => 'Недопустимое имя файла']);
    }

    $itemPath = fmSafePath($itemPathRaw);
    if ($itemPath === null) {
        logAction('file_rename', 'Path traversal: ' . $itemPathRaw, 'ERROR');
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $fullRelative = ($itemPath !== '' ? $itemPath . '/' : '') . $oldName;
    if (fmIsBlacklisted($fullRelative)) {
        logAction('file_rename', 'Попытка доступа к защищённой папке: ' . $fullRelative, 'ERROR');
        fmRespond(['error' => 'Доступ к этой папке запрещён']);
    }

    $basePath = fmSafeAbsolute($itemPath);
    if ($basePath === null) {
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $sourcePath = $basePath . DIRECTORY_SEPARATOR . $oldName;
    $targetPath = $basePath . DIRECTORY_SEPARATOR . $newName;

    if (!file_exists($sourcePath)) {
        fmRespond(['error' => 'Исходный элемент не найден на сервере']);
    }

    if (file_exists($targetPath)) {
        fmRespond(['error' => 'Элемент с таким именем уже существует в этой папке!']);
    }

    if (@rename($sourcePath, $targetPath)) {
        logAction('file_rename', 'Файл "' . $oldName . '" переименован в "' . $newName . '"', 'INFO');
        fmRespond(['success' => 'Элемент успешно переименован']);
    }

    logAction('file_rename', 'Ошибка переименования "' . $oldName . '"', 'ERROR');
    fmRespond(['error' => 'Не удалось переименовать элемент.']);
}

/**
 * Чтение кода файла для ACE-редактора.
 *
 * @return void
 */
function fmActionGetCode(): void {
    // CSRF-проверка
    $clientToken  = fmPostString('csrf_token');
    $sessionToken = $_SESSION['csrf_token'] ?? '';
    if (empty($sessionToken) || !hash_equals($sessionToken, $clientToken)) {
        logAction('file_access', 'get_code без CSRF', 'ERROR');
        fmRespond(['error' => 'CSRF-токен невалиден'], 403);
    }

    $fileName    = fmPostString('name');
    $filePathRaw = fmPostString('path');

    // Валидация имени файла
    if (!preg_match('#^[a-zA-Z0-9\-_.]+$#', $fileName) && $fileName !== '.htaccess') {
        fmRespond(['error' => 'Недопустимое имя файла']);
    }

    // Whitelist расширений
    if (!fmIsAllowedExtension($fileName)) {
        logAction('file_access', 'Запрещённое расширение: ' . $fileName, 'ERROR');
        fmRespond(['error' => 'Редактирование файлов этого типа запрещено']);
    }

    // Blacklist имён
    if (fmIsSensitiveFile($fileName)) {
        logAction('file_access', 'Попытка доступа к чувствительному файлу: ' . $fileName, 'ERROR');
        fmRespond(['error' => 'Доступ к этому файлу запрещён']);
    }

    $itemPath = fmSafePath($filePathRaw);
    if ($itemPath === null) {
        logAction('file_access', 'Path traversal: ' . $filePathRaw, 'ERROR');
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $fullRelative = ($itemPath !== '' ? $itemPath . '/' : '') . $fileName;
    if (fmIsBlacklisted($fullRelative)) {
        logAction('file_access', 'Защищённая папка: ' . $fullRelative, 'ERROR');
        fmRespond(['error' => 'Доступ к этой папке запрещён']);
    }

    $basePath = fmSafeAbsolute($itemPath);
    if ($basePath === null) {
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $fullPath = $basePath . DIRECTORY_SEPARATOR . $fileName;

    if (file_exists($fullPath) && is_file($fullPath)) {
        fmRespond([
            'success' => true,
            'code'    => file_get_contents($fullPath),
        ]);
    }

    fmRespond(['error' => 'Файл не найден на сервере']);
}

/**
 * Сохранение кода файла (создаёт файл, если его нет).
 *
 * @return void
 */
function fmActionSaveCode(): void {
    $fileName    = fmPostString('name');
    $filePathRaw = fmPostString('path');
    $codeData    = fmPostString('code');

    // Валидация имени
    if (!preg_match('#^[a-zA-Z0-9\-_.]+$#', $fileName) && $fileName !== '.htaccess') {
        fmRespond(['error' => 'Недопустимое имя файла']);
    }

    // Whitelist расширений
    if (!fmIsAllowedExtension($fileName)) {
        logAction('file_edit', 'Запрещённое расширение: ' . $fileName, 'ERROR');
        fmRespond(['error' => 'Сохранение файлов этого типа запрещено']);
    }

    // Blacklist имён
    if (fmIsSensitiveFile($fileName)) {
        logAction('file_edit', 'Попытка записи в чувствительный файл: ' . $fileName, 'ERROR');
        fmRespond(['error' => 'Запись в этот файл запрещена']);
    }

    $itemPath = fmSafePath($filePathRaw);
    if ($itemPath === null) {
        logAction('file_edit', 'Path traversal: ' . $filePathRaw, 'ERROR');
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $fullRelative = ($itemPath !== '' ? $itemPath . '/' : '') . $fileName;
    if (fmIsBlacklisted($fullRelative)) {
        logAction('file_edit', 'Защищённая папка: ' . $fullRelative, 'ERROR');
        fmRespond(['error' => 'Доступ к этой папке запрещён']);
    }

    $basePath = fmSafeAbsolute($itemPath);
    if ($basePath === null) {
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $fullPath = $basePath . DIRECTORY_SEPARATOR . $fileName;

    // Если файла нет — создаём
    $isNew = !file_exists($fullPath);

    if (file_put_contents($fullPath, $codeData) !== false) {
        if ($isNew) {
            logAction('file_edit', 'Создан новый файл "' . $fileName . '" (путь: ' . fmLogPath($itemPath) . ')', 'INFO');
            fmRespond(['success' => 'Файл успешно создан на сервере!']);
        }

        logAction('file_edit', 'Файл "' . $fileName . '" сохранён (путь: ' . fmLogPath($itemPath) . ')', 'INFO');
        fmRespond(['success' => 'Файл успешно сохранен на сервере!']);
    }

    logAction('file_edit', 'Ошибка записи файла "' . $fileName . '"', 'ERROR');
    fmRespond(['error' => 'Не удалось сохранить файл. Проверьте права доступа.']);
}

/**
 * Загрузка файлов в текущую папку (транслитерация имён, проверка mime).
 *
 * @param string $requestedDir    Относительный путь целевой папки
 * @param string $currentFullPath Абсолютный путь целевой папки
 * @return void
 */
function fmActionUpload(string $requestedDir, string $currentFullPath): void {
    if (!isset($_FILES['filemanager_files'])) {
        fmRespond(['success' => false, 'error' => 'Файлы для загрузки не найдены.']);
    }

    if (!is_dir($currentFullPath)) {
        fmRespond(['success' => false, 'error' => 'Целевая директория не существует.']);
    }

    // Blacklist для текущей папки
    if (fmIsBlacklisted($requestedDir)) {
        logAction('file_upload', 'Загрузка в защищённую папку: ' . fmLogPath($requestedDir), 'ERROR');
        fmRespond(['success' => false, 'error' => 'Загрузка в эту папку запрещена']);
    }

    $uploadedFiles = [];
    if (is_array($_FILES['filemanager_files']['name'])) {
        foreach ($_FILES['filemanager_files']['name'] as $index => $name) {
            $uploadedFiles[] = [
                'name'     => $_FILES['filemanager_files']['name'][$index],
                'tmp_name' => $_FILES['filemanager_files']['tmp_name'][$index],
                'error'    => $_FILES['filemanager_files']['error'][$index],
                'size'     => $_FILES['filemanager_files']['size'][$index],
            ];
        }
    } else {
        $uploadedFiles[] = $_FILES['filemanager_files'];
    }

    $allowedExtensions = ['php', 'css', 'js', 'json', 'html', 'htaccess', 'txt', 'jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'];
    $successCount = 0;

    foreach ($uploadedFiles as $file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            continue;
        }

        if ($file['size'] > MAX_UPLOAD_SIZE) {
            fmRespond(['success' => false, 'error' => "Файл \"{$file['name']}\" превышает лимит (" . (MAX_UPLOAD_SIZE / 1024 / 1024) . " МБ)."]);
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (empty($ext) && strpos($file['name'], '.') === 0) {
            $ext = strtolower(substr($file['name'], 1));
        }

        if (!in_array($ext, $allowedExtensions, true)) {
            fmRespond(['success' => false, 'error' => "Формат файла \"{$file['name']}\" заблокирован!"]);
        }

        // Проверка mime для картинок
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'], true)) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime  = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            if (stripos($mime, 'image/') !== 0) {
                fmRespond(['success' => false, 'error' => "Файл \"{$file['name']}\" не является валидным изображением."]);
            }
        }

        // Именование
        if ($file['name'] === '.htaccess') {
            $finalName = '.htaccess';
        } else {
            $originalName = pathinfo($file['name'], PATHINFO_FILENAME);
            $translitName = cms_transliterate($originalName);
            $cleanName    = preg_replace('/[^a-z0-9._-]/i', '', $translitName);
            $cleanName    = preg_replace('/_+/', '_', $cleanName);
            $cleanName    = trim($cleanName, '_');

            if ($cleanName === '' || mb_strlen($cleanName) > 50) {
                $cleanName = 'file';
            }

            $potentialName = $cleanName . '.' . $ext;
            $checkPath     = $currentFullPath . DIRECTORY_SEPARATOR . $potentialName;

            if (!file_exists($checkPath)) {
                $finalName = $potentialName;
            } else {
                $randomSalt    = bin2hex(random_bytes(2));
                $potentialName = $cleanName . '_' . $randomSalt . '.' . $ext;
                $checkPath     = $currentFullPath . DIRECTORY_SEPARATOR . $potentialName;

                if (file_exists($checkPath)) {
                    $randomSalt    = bin2hex(random_bytes(2));
                    $potentialName = $cleanName . '_' . $randomSalt . '.' . $ext;
                }
                $finalName = $potentialName;
            }
        }

        $targetPath = $currentFullPath . DIRECTORY_SEPARATOR . $finalName;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            // Сообщаем ядру, что файл загружен
            do_action('after_file_upload', $targetPath);

            $successCount++;
        } else {
            logAction('file_upload', 'Ошибка загрузки в папку ' . fmLogPath($requestedDir), 'ERROR');
            fmRespond(['success' => false, 'error' => "Не удалось сохранить файл \"{$file['name']}\"."]);
        }
    }

    logAction('file_upload', 'Загружено: ' . $successCount . ' ' . fmFilesWord($successCount) . ' в папку ' . fmLogPath($requestedDir), 'INFO');
    fmRespond(['success' => true, 'message' => 'Успешно загружено: ' . $successCount . ' ' . fmFilesWord($successCount)]);
}

/**
 * Изменение прав доступа (CHMOD).
 *
 * @return void
 */
function fmActionChmod(): void {
    $itemName    = fmPostString('name');
    $itemPathRaw = fmPostString('path');
    $modeInput   = fmPostString('mode');

    if (!preg_match('#^[a-zA-Z0-9\-_.]+$#', $itemName)) {
        fmRespond(['error' => 'Недопустимое имя файла']);
    }

    if (!preg_match('#^0?[0-7]{3}$#', $modeInput)) {
        fmRespond(['error' => 'Недопустимая маска прав']);
    }

    if ($itemName === '') {
        fmRespond(['error' => 'Не указано имя объекта']);
    }

    $itemPath = fmSafePath($itemPathRaw);
    if ($itemPath === null) {
        logAction('file_chmod', 'Path traversal: ' . $itemPathRaw, 'ERROR');
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $fullRelative = ($itemPath !== '' ? $itemPath . '/' : '') . $itemName;
    if (fmIsBlacklisted($fullRelative)) {
        logAction('file_chmod', 'Защищённая папка: ' . $fullRelative, 'ERROR');
        fmRespond(['error' => 'Доступ запрещён']);
    }

    $basePath = fmSafeAbsolute($itemPath);
    if ($basePath === null) {
        fmRespond(['error' => 'Недопустимый путь']);
    }

    $fullPath = $basePath . DIRECTORY_SEPARATOR . $itemName;

    if (!file_exists($fullPath)) {
        fmRespond(['error' => 'Файл или папка не найдены']);
    }

    $octalMode = octdec($modeInput);

    if (@chmod($fullPath, $octalMode)) {
        clearstatcache(true, $fullPath);
        $actualPerms = substr(sprintf('%o', fileperms($fullPath)), -4);

        if ($actualPerms !== $modeInput) {
            logAction('file_chmod', 'Частичные права на "' . $itemName . '"', 'INFO');
            fmRespond([
                'error'     => "Сервер применил только частичные права: {$actualPerms}.",
                'new_perms' => $actualPerms,
            ]);
        }

        logAction('file_chmod', 'Права ' . $modeInput . ' для "' . $itemName . '"', 'INFO');
        fmRespond([
            'success'   => "Права доступа изменены на {$actualPerms}",
            'new_perms' => $actualPerms,
        ]);
    }

    logAction('file_chmod', 'Ошибка chmod "' . $itemName . '"', 'ERROR');
    fmRespond(['error' => 'Не удалось изменить права.']);
}

/**
 * Создание папки в текущем каталоге.
 *
 * @param string $requestedDir    Относительный путь текущей папки
 * @param string $currentFullPath Абсолютный путь текущей папки
 * @return void
 */
function fmActionCreateDir(string $requestedDir, string $currentFullPath): void {
    $dirName = fmPostString('name');
    $dirName = str_replace(['..', '/', '\\', '?', '*', ':', '"', '<', '>', '|', '+', '=', ',', ';'], '', $dirName);
    $dirName = trim($dirName);

    if ($dirName === '') {
        fmRespond(['error' => 'Имя папки пустое или содержит запрещённые символы']);
    }

    if (fmIsBlacklisted($requestedDir . '/' . $dirName)) {
        logAction('file_create_dir', 'Попытка создания в защищённой папке: ' . $requestedDir . '/' . $dirName, 'ERROR');
        fmRespond(['error' => 'Создание в этой папке запрещено']);
    }

    $targetPath = $currentFullPath . DIRECTORY_SEPARATOR . $dirName;

    if (file_exists($targetPath)) {
        if (is_dir($targetPath)) {
            fmRespond(['error' => 'Папка с таким именем уже существует']);
        }
        fmRespond(['error' => 'Невозможно создать папку: есть файл с таким именем!']);
    }

    if (@mkdir($targetPath, 0755)) {
        logAction('file_create_dir', 'Создана папка "' . $dirName . '"', 'INFO');
        fmRespond(['success' => "Папка \"{$dirName}\" успешно создана"]);
    }

    logAction('file_create_dir', 'Ошибка создания папки "' . $dirName . '"', 'ERROR');
    fmRespond(['error' => 'Не удалось создать папку.']);
}

/**
 * Создание пустого файла в текущем каталоге.
 *
 * @param string $requestedDir    Относительный путь текущей папки
 * @param string $currentFullPath Абсолютный путь текущей папки
 * @return void
 */
function fmActionCreateFile(string $requestedDir, string $currentFullPath): void {
    $fileName = fmPostString('name');
    $fileName = str_replace(['..', '/', '\\', '?', '*', ':', '"', '<', '>', '|', '+', '=', ',', ';'], '', $fileName);
    $fileName = trim($fileName);

    if ($fileName === '') {
        fmRespond(['error' => 'Имя файла пустое или содержит запрещённые символы']);
    }

    if (fmIsBlacklisted($requestedDir . '/' . $fileName)) {
        logAction('file_create_file', 'Попытка создания в защищённой папке: ' . $requestedDir . '/' . $fileName, 'ERROR');
        fmRespond(['error' => 'Создание в этой папке запрещено']);
    }

    $targetPath = $currentFullPath . DIRECTORY_SEPARATOR . $fileName;

    if (file_exists($targetPath)) {
        if (is_file($targetPath)) {
            fmRespond(['error' => 'Файл с таким именем уже существует']);
        }
        fmRespond(['error' => 'Невозможно создать файл: есть папка с таким именем!']);
    }

    if (@file_put_contents($targetPath, '') !== false) {
        logAction('file_create_file', 'Создан файл "' . $fileName . '"', 'INFO');
        fmRespond(['success' => "Файл \"{$fileName}\" успешно создан"]);
    }

    logAction('file_create_file', 'Ошибка создания файла "' . $fileName . '"', 'ERROR');
    fmRespond(['error' => 'Не удалось создать файл.']);
}

/**
 * Транслитерация строки (для модалки создания).
 *
 * @return void
 */
function fmActionTranslit(): void {
    $textInput  = fmPostString('text');
    $resultText = cms_transliterate($textInput);

    fmRespond([
        'success'        => true,
        'transliterated' => $resultText,
    ]);
}

// =========================================================================
// 4. РОУТИНГ AJAX-ЗАПРОСОВ ПРОВОДНИКА
// =========================================================================

/**
 * Обрабатывает AJAX-запросы проводника (GET/AJAX-параметр fm_api_action).
 *
 * Вызывается на admin_init — после проверки авторизации и CSRF.
 * При несовпадении параметра молча выходит, не мешая остальным запросам.
 *
 * @return void
 */
function fm_handle_api_request(): void {
    if (!isset($_GET['fm_api_action'])) {
        return;
    }

    if (empty($_SESSION['admin_auth'])) {
        fmRespond(['error' => 'Доступ запрещен. Требуется авторизация.'], 403);
    }

    $dirRaw = fmGetString('dir');
    if ($dirRaw === '') {
        $dirRaw = fmPostString('dir');
    }

    $requestedDir = fmSafePath($dirRaw);
    if ($requestedDir === null) {
        logAction('file_list', 'Path traversal: ' . $dirRaw, 'ERROR');
        fmRespond(['error' => 'Недопустимый путь'], 400);
    }

    $currentFullPath = fmSafeAbsolute($requestedDir);
    if ($currentFullPath === null) {
        fmRespond(['error' => 'Недопустимый путь'], 400);
    }

    // Страховка: если папка не существует, сбрасываем в корень сайта
    if (!file_exists($currentFullPath) || !is_dir($currentFullPath)) {
        $currentFullPath = APP_ROOT;
        $requestedDir    = '';
    }

    $action = fmGetString('action');
    if ($action === '') {
        $action = 'list';
    }

    switch ($action) {
        case 'list':
            fmActionList($requestedDir, $currentFullPath);
            break;

        case 'delete':
            fmActionDelete();
            break;

        case 'delete_many':
            fmActionDeleteMany();
            break;

        case 'rename':
            fmActionRename();
            break;

        case 'get_code':
            fmActionGetCode();
            break;

        case 'save_code':
            fmActionSaveCode();
            break;

        case 'upload':
            fmActionUpload($requestedDir, $currentFullPath);
            break;

        case 'chmod':
            fmActionChmod();
            break;

        case 'create_dir':
            fmActionCreateDir($requestedDir, $currentFullPath);
            break;

        case 'create_file':
            fmActionCreateFile($requestedDir, $currentFullPath);
            break;

        case 'translit':
            fmActionTranslit();
            break;
    }

    fmRespond(['error' => 'Неизвестное действие'], 400);
}

add_action('admin_init', 'fm_handle_api_request');
