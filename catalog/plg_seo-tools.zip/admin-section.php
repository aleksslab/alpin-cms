<?php
/**
 * Секция «Технический SEO» (плагин seo-tools).
 * Внедряется в конец ядровой вкладки «SEO настройки» через register_plugin_settings.
 */
if (!defined('APP_ROOT') || empty($_SESSION['admin_auth'])) {
    die('Доступ запрещен');
}

$settingsData = getSettingsData();

$seoSitemapEnabled  = $settingsData['seo_sitemap_enabled'] ?? true;
$seoRobotsEnabled   = $settingsData['seo_robots_enabled'] ?? true;
$seoAutoRegenerate  = $settingsData['seo_auto_regenerate'] ?? false;
$lastSeoRegenerate  = (int)($settingsData['last_seo_regenerate'] ?? 0);

$sitemapFile   = APP_ROOT . '/sitemap.xml';
$robotsFile    = APP_ROOT . '/robots.txt';
$sitemapExists = file_exists($sitemapFile);
$robotsExists  = file_exists($robotsFile);
?>
<!-- ТЕХНИЧЕСКИЙ SEO (плагин seo-tools) -->
<div class="border-t border-slate-200/60 pt-4 mt-2">
    <h4 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Технический SEO</h4>

    <div class="space-y-3">
        <!-- Sitemap -->
        <label class="matrix-label">
            <input type="hidden" name="seo_sitemap_enabled" value="0">
            <input type="checkbox" name="seo_sitemap_enabled" value="1" <?php echo $seoSitemapEnabled ? 'checked' : ''; ?>>
            <span class="text-sm font-medium text-slate-700">Генерировать sitemap.xml</span>
        </label>

        <!-- Robots -->
        <label class="matrix-label">
            <input type="hidden" name="seo_robots_enabled" value="0">
            <input type="checkbox" name="seo_robots_enabled" value="1" <?php echo $seoRobotsEnabled ? 'checked' : ''; ?>>
            <span class="text-sm font-medium text-slate-700">Генерировать robots.txt</span>
        </label>

        <!-- Автообновление -->
        <label class="matrix-label">
            <input type="hidden" name="seo_auto_regenerate" value="0">
            <input type="checkbox" name="seo_auto_regenerate" value="1" <?php echo $seoAutoRegenerate ? 'checked' : ''; ?>>
            <span class="text-sm font-medium text-slate-700">Автообновлять при изменении страниц</span>
        </label>
        <p class="text-[10px] text-slate-400 ml-6 -mt-2">
            Если выключено — файлы обновляются только вручную или через cron.
        </p>
    </div>

    <!-- Статус и ссылки -->
    <div class="mt-4 p-3 bg-white rounded-xl border border-slate-200">
        <div class="flex flex-wrap items-center justify-between gap-3">
            <div class="text-xs text-slate-500">
                <?php if ($lastSeoRegenerate > 0): ?>
                    Последняя генерация: <strong class="text-slate-700"><?php echo date('d.m.Y H:i', $lastSeoRegenerate); ?></strong>
                <?php else: ?>
                    <span class="text-slate-400 italic">Последняя генерация: не выполнялась</span>
                <?php endif; ?>
            </div>

            <div class="flex flex-wrap items-center gap-2">
                <?php if ($sitemapExists): ?>
                    <a href="/sitemap.xml" target="_blank" class="text-xs text-[var(--primary-color)] hover:underline font-semibold flex items-center gap-1">
                        <span class="icon-external-link text-sm"></span> sitemap.xml
                    </a>
                <?php endif; ?>
                <?php if ($robotsExists): ?>
                    <a href="/robots.txt" target="_blank" class="text-xs text-[var(--primary-color)] hover:underline font-semibold flex items-center gap-1">
                        <span class="icon-external-link text-sm"></span> robots.txt
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="mt-3 pt-3 border-t border-slate-100">
            <button type="button" onclick="window.regenerateSeoFiles(event)"
                    class="px-4 py-2 bg-slate-100 border border-slate-200 text-slate-700 text-sm font-bold rounded-xl hover:bg-slate-200 transition-all cursor-pointer flex items-center gap-2">
                <span class="icon-refresh-cw text-sm"></span>
                <?php if ($lastSeoRegenerate > 0): ?>
                    Пересобрать
                <?php else: ?>
                    Генерировать
                <?php endif; ?>
            </button>
            <p class="text-[10px] text-slate-400 mt-2">
                Файлы создаются в корне сайта: <span class="font-mono">sitemap.xml</span>, <span class="font-mono">robots.txt</span>.
            </p>
        </div>

        <!-- URL крона -->
        <div class="mt-3 pt-3 border-t border-slate-100">
            <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                URL для планировщика хостинга (cron)
            </label>
            <div class="flex flex-col lg:flex-row gap-2">
                <input type="text"
                       readonly
                       value="<?php echo e(getBaseUrl()); ?>/config/cron/run.php?task=seo&token=<?php echo e(getCronToken()); ?>"
                       class="w-full min-w-0 px-4 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-[11px] font-mono text-slate-600 select-all focus:outline-none">
                <button type="button"
                        onclick="copyToClipboard(this)"
                        class="w-full lg:w-auto lg:flex-initial lg:w-[140px] px-4 py-2.5 bg-slate-100 border border-slate-200 text-slate-700 text-sm font-bold rounded-xl hover:bg-slate-200 transition-all whitespace-nowrap flex items-center justify-center gap-2">
                    <span class="icon-copy text-sm"></span> Копировать
                </button>
            </div>
            <p class="text-[10px] text-slate-400 mt-2">
                Рекомендуемая частота: 1 раз в сутки. Использует общий токен крона.
            </p>
        </div>
    </div>
</div>
<script>
(function () {
    'use strict';

    // Ручная пересборка sitemap.xml / robots.txt.
    // Отправляет POST на admin_init-обработчик плагина (CSRF проверяет ядро).
    window.regenerateSeoFiles = function (evt) {
        var csrfInput = document.querySelector('input[name="csrf_token"]');
        var csrfToken = csrfInput ? csrfInput.value : '';
        if (!csrfToken) {
            alert('Ошибка: CSRF-токен не найден. Обновите страницу.');
            return;
        }

        var btn = evt && evt.target ? evt.target.closest('button') : null;
        var originalHtml = btn ? btn.innerHTML : '';

        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<span class="icon-refresh-cw text-sm inline-block animate-spin"></span> Генерация...';
        }

        fetch('index.php?tab=config_vars', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'regenerate_seo_files=1&csrf_token=' + encodeURIComponent(csrfToken)
        })
        .then(function (response) { return response.json(); })
        .then(function (data) {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }

            if (data.success) {
                // Перезагружаем страницу, чтобы обновить дату и ссылки
                window.location.reload();
            } else {
                alert(data.error || 'Ошибка генерации');
            }
        })
        .catch(function () {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }
            alert('Ошибка соединения');
        });
    };
})();
</script>
