<?php
/**
 * Плагин: SEO-инструменты.
 *
 * Генерация sitemap.xml и robots.txt: автоматически при изменении страниц,
 * вручную из секции «SEO настройки» и по крону (`config/cron/run.php?task=seo`).
 *
 * Настройки хранятся в data/settings.json (ключи `seo_*`). Файлы создаются
 * в корне сайта. Секция настроек внедряется в ядровую вкладку «SEO настройки».
 */

if (!defined('APP_ROOT')) {
    die('Прямой доступ запрещён');
}

/**
 * Генерирует sitemap.xml в корне сайта.
 *
 * Включает только published-страницы без истёкшего unpublish_at.
 * Главная получает priority 1.0, остальные — 0.8.
 *
 * @return array ['success' => bool, 'count' => int, 'error' => string]
 */
function seo_generate_sitemap(): array {
    $pagesDir = DATA_DIR . 'pages/';
    if (!is_dir($pagesDir)) {
        return ['success' => false, 'count' => 0, 'error' => 'Папка страниц не найдена.'];
    }

    // Протокол и хост
    $baseUrl = getBaseUrl();

    $files = glob($pagesDir . '*.json');
    $urls = [];
    $now = time();

    foreach ($files as $file) {
        $page = _jsonToArray($file);
        if (empty($page)) {
            continue;
        }

        // Только опубликованные
        if (($page['status'] ?? '') !== 'published') {
            continue;
        }

        // Не истёкшие по unpublish_at
        if (!empty($page['unpublish_at']) && (int)$page['unpublish_at'] <= $now) {
            continue;
        }

        $slug = $page['slug'] ?? $page['id'] ?? '';

        if ($slug === '') {
            $loc = $baseUrl . '/';
            $priority = '1.0';
        } else {
            $loc = $baseUrl . '/' . trim($slug, '/');
            $priority = '0.8';
        }

        $urls[] = [
            'loc'        => $loc,
            'lastmod'    => date('c', filemtime($file)),
            'changefreq' => 'weekly',
            'priority'   => $priority,
        ];
    }

    // Сортировка: главная вперёд, потом по алфавиту
    usort($urls, function($a, $b) {
        if ($a['priority'] === '1.0' && $b['priority'] !== '1.0') return -1;
        if ($a['priority'] !== '1.0' && $b['priority'] === '1.0') return 1;
        return strcmp($a['loc'], $b['loc']);
    });

    // Формируем XML
    $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

    foreach ($urls as $url) {
        $xml .= "    <url>\n";
        $xml .= "        <loc>" . htmlspecialchars($url['loc'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</loc>\n";
        $xml .= "        <lastmod>" . $url['lastmod'] . "</lastmod>\n";
        $xml .= "        <changefreq>" . $url['changefreq'] . "</changefreq>\n";
        $xml .= "        <priority>" . $url['priority'] . "</priority>\n";
        $xml .= "    </url>\n";
    }

    $xml .= '</urlset>' . "\n";

    $targetPath = APP_ROOT . DIRECTORY_SEPARATOR . 'sitemap.xml';

    if (!safeFileWrite($targetPath, $xml)) {
        return ['success' => false, 'count' => 0, 'error' => 'Не удалось записать sitemap.xml.'];
    }

    return ['success' => true, 'count' => count($urls), 'error' => ''];
}

/**
 * Генерирует robots.txt в корне сайта.
 *
 * @return array ['success' => bool, 'error' => string]
 */
function seo_generate_robots(): array {
    // Протокол и хост
    $baseUrl = getBaseUrl();

    $lines = [
        'User-agent: *',
        'Disallow: /config/',
        'Disallow: /data/',
        'Disallow: /cache/',
        'Disallow: /*?preview=',
        'Allow: /',
        '',
        'Sitemap: ' . $baseUrl . '/sitemap.xml',
        '',
    ];

    $content = implode("\n", $lines);
    $targetPath = APP_ROOT . DIRECTORY_SEPARATOR . 'robots.txt';

    if (!safeFileWrite($targetPath, $content)) {
        return ['success' => false, 'error' => 'Не удалось записать robots.txt.'];
    }

    return ['success' => true, 'error' => ''];
}

/**
 * Генерирует sitemap.xml и robots.txt (если соответствующая галочка включена).
 *
 * Проверяет настройки `seo_sitemap_enabled` и `seo_robots_enabled`.
 * Если галочка выключена — соответствующий файл не создаётся (или удаляется,
 * если существовал ранее).
 *
 * @return array ['sitemap' => array, 'robots' => array]
 */
function seo_generate_files(): array {
    $settings = getSettingsData();

    $sitemapEnabled = $settings['seo_sitemap_enabled'] ?? true;
    $robotsEnabled  = $settings['seo_robots_enabled'] ?? true;

    $result = [
        'sitemap' => ['success' => true, 'skipped' => true, 'error' => ''],
        'robots'  => ['success' => true, 'skipped' => true, 'error' => ''],
    ];

    // Sitemap
    if ($sitemapEnabled) {
        $result['sitemap'] = seo_generate_sitemap();
    } else {
        // Удаляем существующий файл
        $path = APP_ROOT . DIRECTORY_SEPARATOR . 'sitemap.xml';
        if (file_exists($path)) {
            @unlink($path);
        }
    }

    // Robots
    if ($robotsEnabled) {
        $result['robots'] = seo_generate_robots();
    } else {
        $path = APP_ROOT . DIRECTORY_SEPARATOR . 'robots.txt';
        if (file_exists($path)) {
            @unlink($path);
        }
    }

    // Обновляем метку времени последней генерации
    $settings['last_seo_regenerate'] = time();
    saveData('settings', $settings);

    return $result;
}

/**
 * Проверяет галочку «Автообновление» и вызывает генерацию, если включена.
 *
 * @return void
 */
function seo_maybe_regenerate(): void {
    $settings = getSettingsData();
    if (!empty($settings['seo_auto_regenerate'])) {
        seo_generate_files();
    }
}

/**
 * Cron-задача: генерация SEO-файлов.
 *
 * @return bool true при успешном выполнении.
 */
function seo_run_cron(): bool {
    $result = seo_generate_files();
    return !empty($result['sitemap']['success']) || !empty($result['robots']['success']);
}

// Подписки на события ядра: страница сохранена/удалена/восстановлена/клонирована,
// сменилась главная — при включённой авторегенерации обновляем файлы.
add_action('page_saved',    function() { seo_maybe_regenerate(); });
add_action('page_deleted',  function() { seo_maybe_regenerate(); });
add_action('page_restored', function() { seo_maybe_regenerate(); });
add_action('page_cloned',   function() { seo_maybe_regenerate(); });
add_action('home_changed',  function() { seo_maybe_regenerate(); });

// Восстановление бэкапа. Реагируем только если заменён каталог data/: тогда
// изменились страницы и настройки. Одиночный восстановленный sitemap.xml
// пересборкой не затираем.
add_action('backup_restored', function($archiveName, $items) {
    if (!is_array($items) || !in_array('data', $items, true)) {
        return;
    }

    // settings.json заменён на диске — сбрасываем кеш запроса,
    // иначе ниже прочитаются настройки «до восстановления».
    clearDataCache('settings');

    seo_maybe_regenerate();
}, 10, 2);

// Смена галочек sitemap/robots — файлы нужно пересобрать (или удалить) сразу,
// даже если авторегенерация выключена.
add_action('settings_saved', function($oldSettings, $newSettings) {
    $oldSitemap = (bool)($oldSettings['seo_sitemap_enabled'] ?? true);
    $oldRobots  = (bool)($oldSettings['seo_robots_enabled'] ?? true);
    $newSitemap = (bool)($newSettings['seo_sitemap_enabled'] ?? true);
    $newRobots  = (bool)($newSettings['seo_robots_enabled'] ?? true);

    if ($oldSitemap !== $newSitemap || $oldRobots !== $newRobots) {
        seo_generate_files(); // принудительно: галочки менялись
    }
});

// Ручная пересборка из секции «SEO настройки».
// CSRF проверяет ядро до admin_init (config/index.php), здесь — только разбор POST.
add_action('admin_init', function() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['regenerate_seo_files'])) {
        return;
    }

    $result = seo_generate_files();

    if (!empty($result['sitemap']['success']) || !empty($result['robots']['success'])) {
        logAction('seo_regenerate', 'Пересобраны SEO-файлы', 'INFO');
        echo json_encode(['success' => true, 'message' => 'Файлы пересобраны']);
    } else {
        $error = $result['sitemap']['error'] ?: ($result['robots']['error'] ?? 'Неизвестная ошибка');
        logAction('seo_regenerate', 'Ошибка: ' . $error, 'ERROR');
        echo json_encode(['success' => false, 'error' => $error]);
    }
    exit;
});

// Секция настроек внутри ядровой вкладки «SEO настройки».
register_plugin_settings([
    'tab'      => 'seo',
    'position' => 'after',
    'callback' => function() { include __DIR__ . '/admin-section.php'; }
]);

// Сохранение настроек плагина.
add_filter('save_settings_data', function($newSettings) {
    $defaults = [
        'seo_sitemap_enabled' => true,
        'seo_robots_enabled'  => true,
        'seo_auto_regenerate' => false,
    ];
    $fields = [
        'seo_sitemap_enabled',
        'seo_robots_enabled',
        'seo_auto_regenerate',
    ];

    save_plugin_settings($newSettings, 'seo_sitemap_enabled', $defaults, $fields);
    return $newSettings;
});

// Задача в общем реестре кронов ядра (виртуальный крон — при заходе админа).
register_cron_task('seo', 'seo_run_cron', [
    'interval' => 86400,
    'virtual'  => true,
    'enabled'  => true,
    'label'    => 'Обновление sitemap.xml и robots.txt',
]);

// Действие логирования
register_log_action('seo_regenerate', 'Пересборка SEO-файлов', 'SEO', 'search');

// Сброс настроек при удалении плагина (до удаления файлов плагина).
add_action('plugin_before_delete', function($id) {
    if ($id !== 'seo-tools') {
        return;
    }

    $settings = getSettingsData();
    unset(
        $settings['seo_sitemap_enabled'],
        $settings['seo_robots_enabled'],
        $settings['seo_auto_regenerate'],
        $settings['last_seo_regenerate']
    );
    saveData('settings', $settings);
});
