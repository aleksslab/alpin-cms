<?php
if (!defined('APP_ROOT') || empty($_SESSION['admin_auth'])) {
    die('Доступ запрещен');
}
?>

<div class="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-6">
    <div>
        <h1 class="text-3xl font-bold text-slate-800 mb-2">Тестовый плагин</h1>
        <p class="text-slate-500 text-sm">Пример для разработки собственных расширений.</p>
    </div>
</div>

<div class="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
    <div class="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center">
        <div class="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 mx-auto mb-4">
            <span class="icon-check-circle text-3xl"></span>
        </div>
        <h3 class="text-lg font-bold text-emerald-900 mb-2">Плагин успешно работает!</h3>
        <p class="text-sm text-emerald-800 max-w-lg mx-auto">
            Если вы видите этот текст, значит, вы установили тестовый плагин и он корректно добавил свою вкладку в админку.
        </p>
    </div>

    <div class="border-t border-slate-200/60 pt-6">
        <h4 class="text-sm font-bold text-slate-800 mb-3">Как это работает:</h4>
        <ul class="space-y-2 text-sm text-slate-600">
            <li class="flex items-start gap-2">
                <span class="icon-check text-emerald-500 mt-0.5 flex-shrink-0"></span>
                <span><strong>Манифест</strong> (<code class="bg-slate-100 px-1 rounded">plugin.json</code>) зарегистрировал вкладку в меню.</span>
            </li>
            <li class="flex items-start gap-2">
                <span class="icon-check text-emerald-500 mt-0.5 flex-shrink-0"></span>
                <span><strong>Файл</strong> <code class="bg-slate-100 px-1 rounded">admin-page.php</code> вывел этот текст.</span>
            </li>
            <li class="flex items-start gap-2">
                <span class="icon-check text-emerald-500 mt-0.5 flex-shrink-0"></span>
                <span><strong>Логика плагина</strong> (<code class="bg-slate-100 px-1 rounded">plugin.php</code>) может перехватывать события ядра.</span>
            </li>
        </ul>
    </div>

    <div class="border-t border-slate-200/60 pt-6">
        <h4 class="text-sm font-bold text-slate-800 mb-3">Где находится код:</h4>
        <div class="bg-slate-50 rounded-xl p-4 font-mono text-xs text-slate-700 space-y-1">
            <div>config/plugins/test-tab/plugin.json</div>
            <div>config/plugins/test-tab/plugin.php</div>
            <div>config/plugins/test-tab/admin-page.php</div>
        </div>
    </div>

    <div class="border-t border-slate-200/60 pt-6">
        <a href="https://github.com/AlekSSLab/alpin-cms/blob/main/docs/for-developers/PLUGINS.md" target="_blank" class="inline-flex items-center gap-2 px-4 py-2 bg-[var(--primary-color)] text-white text-sm font-bold rounded-xl hover:bg-[var(--primary-dark)] transition-all shadow-lg shadow-[var(--primary-color)]/20">
            <span class="icon-book-open text-sm"></span> Документация по плагинам
        </a>
    </div>
</div>