<?php
if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

// Пример хука: добавляем суффикс к заголовку страницы
add_filter('page_title', function($title) {
    return $title . ' (Test Plugin)';
});