<?php
$settings = getSettingsData();
$paletteDark = getThemePalette($settings, 'dark');
?>
    </div> <!-- Закрываем theme-palette-light -->
    
    <!-- Блок: Тёмная тема -->
    <div id="theme-palette-dark" class="theme-palette-block hidden">
        <!-- Фоны тёмной темы -->
        <div class="border-t border-slate-200/60 pt-4">
            <h4 class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Палитра (тёмная тема)</h4>
            <div class="mb-4">
                <h5 class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Фоны</h5>
                <div class="grid grid-cols-1 lg:grid-cols-3! gap-3">
                    <?php 
                    $bgFields = ['bg_main' => 'Фон страницы', 'bg_card' => 'Фон карточек', 'bg_section' => 'Фон секций'];
                    foreach ($bgFields as $key => $label): 
                        $val = $paletteDark[$key] ?? '#0F172A';
                    ?>
                    <div class="editor-field color-picker-sync">
                        <label class="block text-[9px] font-medium text-slate-500 mb-1"><?php echo $label; ?></label>
                        <div class="flex gap-2 items-center">
                            <input type="color" name="theme_dark_<?php echo $key; ?>" value="<?php echo e($val); ?>" class="w-10 h-9 p-0.5 border border-slate-200 rounded cursor-pointer flex-shrink-0">
                            <input type="text" name="theme_dark_<?php echo $key; ?>_text" value="<?php echo e($val); ?>" class="w-full px-2 py-1.5 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[var(--primary-color)] font-mono">
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- Текст и границы тёмной темы -->
        <div>
            <h5 class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Текст и границы (тёмная тема)</h5>
            <div class="grid grid-cols-1 lg:grid-cols-3! gap-3">
                <?php 
                $textFields = ['text_main' => 'Основной текст', 'text_muted' => 'Второстепенный текст', 'border_color' => 'Цвет границ'];
                foreach ($textFields as $key => $label): 
                    $val = $paletteDark[$key] ?? '#F1F5F9';
                ?>
                <div class="editor-field color-picker-sync">
                    <label class="block text-[9px] font-medium text-slate-500 mb-1"><?php echo $label; ?></label>
                    <div class="flex gap-2 items-center">
                        <input type="color" name="theme_dark_<?php echo $key; ?>" value="<?php echo e($val); ?>" class="w-10 h-9 p-0.5 border border-slate-200 rounded cursor-pointer flex-shrink-0">
                        <input type="text" name="theme_dark_<?php echo $key; ?>_text" value="<?php echo e($val); ?>" class="w-full px-2 py-1.5 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[var(--primary-color)] font-mono">
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div> <!-- Закрываем внешний блок табов -->

<!-- Скрипт для переключения табов -->
<script>
(function() {
    var tabs = document.querySelectorAll('.theme-tab-btn');
    var blocks = document.querySelectorAll('.theme-palette-block');
    
    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            var target = this.getAttribute('data-theme-tab');
            
            tabs.forEach(function(t) {
                t.classList.remove('bg-white', 'text-slate-800', 'shadow-sm');
                t.classList.add('text-slate-500', 'hover:text-slate-700');
            });
            this.classList.remove('text-slate-500', 'hover:text-slate-700');
            this.classList.add('bg-white', 'text-slate-800', 'shadow-sm');
            
            blocks.forEach(function(block) {
                block.classList.add('hidden');
            });
            var activeBlock = document.getElementById('theme-palette-' + target);
            if (activeBlock) {
                activeBlock.classList.remove('hidden');
            }
        });
    });
})();
</script>