<?php
$settings = getSettingsData();
$themeDefault = $settings['theme_default'] ?? 'light';
?>
<!-- Начало табов (выбор темы) -->
<div class="border-t border-slate-200/60 pt-4 mt-4">
    <!-- Шапка блока: заголовок и табы -->
    <div class="flex flex-wrap items-center justify-between gap-4 mb-5">
        <h4 class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Настройка палитры</h4>
        
        <!-- Табы -->
        <div class="flex p-1 bg-slate-100 rounded-xl w-full sm:w-auto">
            <button type="button" class="theme-tab-btn flex-1 sm:flex-initial px-6 py-1.5 text-xs font-bold rounded-lg transition-all bg-white text-slate-800 shadow-sm cursor-pointer flex items-center justify-center gap-1.5" data-theme-tab="light">
                <span class="icon-sun text-sm"></span> Светлая
            </button>
            <button type="button" class="theme-tab-btn flex-1 sm:flex-initial px-6 py-1.5 text-xs font-bold rounded-lg transition-all text-slate-500 hover:text-slate-700 cursor-pointer flex items-center justify-center gap-1.5" data-theme-tab="dark">
                <span class="icon-moon text-sm"></span> Тёмная
            </button>
        </div>
    </div>

    <!-- Настройки плагина (селект + чекбокс) -->
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div class="editor-field">
            <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Тема по умолчанию</label>
            <select name="theme_default" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                <option value="light" <?php echo $themeDefault === 'light' ? 'selected' : ''; ?>>Светлая</option>
                <option value="dark" <?php echo $themeDefault === 'dark' ? 'selected' : ''; ?>>Тёмная</option>
            </select>
        </div>
        
        <div class="editor-field flex items-center sm:pt-6">
            <label class="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" name="theme_toggle_enabled" value="1" <?php echo !empty($settings['theme_toggle_enabled']) ? 'checked' : ''; ?> class="w-4 h-4 text-[var(--primary-color)] rounded border-slate-300 focus:ring-[var(--primary-color)]">
                <span class="text-sm font-medium text-slate-700">Показывать переключатель в хедере</span>
            </label>
        </div>
    </div>
    
    <!-- Открываем контейнер для светлой темы (его закроем в after) -->
    <div id="theme-palette-light" class="theme-palette-block">