<?php
if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

// 1. FOUC-защита (до рендера body)
add_action('render_head_start', function() {
    $settings = getSettingsData();
    $themeDefault = $settings['theme_default'] ?? 'light';
    if (!in_array($themeDefault, ['light', 'dark'], true)) {
        $themeDefault = 'light';
    }
    echo '<script>
    (function() {
        var def = "' . e($themeDefault) . '";
        var t = localStorage.getItem("site-theme") || def;
        if (t === "dark") {
            document.documentElement.setAttribute("data-theme", "dark");
        }
    })();
    </script>';
});

// 2. CSS и переменные (в конце head)
add_action('render_head_end', function() {
    echo '<link href="css/dark-theme.css" rel="stylesheet" type="text/css"/>';
    
    $settings = getSettingsData();
    $themeDark = getThemePalette($settings, 'dark');
    
    echo '<style>
    [data-theme="dark"] {
        --bg-main: ' . e($themeDark['bg_main']) . ';
        --bg-card: ' . e($themeDark['bg_card']) . ';
        --bg-section: ' . e($themeDark['bg_section']) . ';
        --text-main: ' . e($themeDark['text_main']) . ';
        --text-muted: ' . e($themeDark['text_muted']) . ';
        --border-color: ' . e($themeDark['border_color']) . ';
        
        --bg-hover: #334155;
        --bg-input: #0F172A;
    }
    </style>';
});

// 3. JS переключателя (в конце body)
add_action('render_body_end', function() {
    $settings = getSettingsData();
    if (!empty($settings['theme_toggle_enabled'])) {
        echo '<script src="js/dark-theme.js" type="text/javascript"></script>';
    }
});

// 4. Настройки (в админке)
register_plugin_settings([
    'tab' => 'colors',
    'position' => 'before',
    'callback' => function() { include __DIR__ . '/admin-before.php'; }
]);
register_plugin_settings([
    'tab' => 'colors',
    'position' => 'after',
    'callback' => function() { include __DIR__ . '/admin-after.php'; }
]);

// 5. Сохранение
add_filter('save_settings_data', function($newSettings) {
    // Если форма плагина отправлялась (проверяем по триггеру)
    if (isset($_POST['theme_dark_bg_main'])) {
        // Сохраняем тёмную палитру
        $dark = [];
        $fields = ['bg_main', 'bg_card', 'bg_section', 'text_main', 'text_muted', 'border_color'];
        foreach ($fields as $key) {
            $dark[$key] = trim($_POST['theme_dark_' . $key] ?? '');
        }
        $newSettings['theme']['dark'] = $dark;
        $newSettings['theme_default'] = ($_POST['theme_default'] === 'dark') ? 'dark' : 'light';
        $newSettings['theme_toggle_enabled'] = isset($_POST['theme_toggle_enabled']);
    } else {
        // Форма плагина не отправлялась — берем старые значения
        $current = getSettingsData();
        $newSettings['theme']['dark'] = $current['theme']['dark'] ?? [];
        $newSettings['theme_default'] = $current['theme_default'] ?? 'light';
        $newSettings['theme_toggle_enabled'] = !empty($current['theme_toggle_enabled']);
    }
    
    return $newSettings;
});

// 6. Сброс настроек при отключении
add_action('plugin_after_toggle', function($id, $active) {
    if ($id === 'dark-theme' && !$active) {
        $settings = getSettingsData();
        $settings['theme_toggle_enabled'] = false;
        saveData('settings', $settings);
    }
});

// 7. Сброс настроек при удалении (до удаления файлов)
add_action('plugin_before_delete', function($id) {
    if ($id === 'dark-theme') {
        $settings = getSettingsData();
        $settings['theme_toggle_enabled'] = false;
        saveData('settings', $settings);
    }
});