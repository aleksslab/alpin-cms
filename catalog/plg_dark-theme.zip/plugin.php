<?php
if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

/**
 * Приводит значение цвета палитры к безопасному виду.
 *
 * Значение попадает внутрь <style> как значение CSS-переменной, поэтому
 * `e()` недостаточно: строка `red; } body { display: none } .x {` не
 * содержит HTML-спецсимволов, но ломает CSS. Пропускаем только hex,
 * rgb()/rgba(), hsl()/hsla() и именованные цвета; остальное — дефолт.
 *
 * @param mixed  $value    Значение из настроек или POST
 * @param string $fallback Цвет по умолчанию для этой переменной
 * @return string
 */
function dark_theme_safe_color($value, string $fallback): string {
    $color = trim((string)$value);

    if ($color === '') {
        return $fallback;
    }

    // #abc, #abcd, #aabbcc, #aabbccdd
    if (preg_match('/^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $color)) {
        return $color;
    }

    // rgb(1, 2, 3), rgba(1 2 3 / 40%), hsl(210, 40%, 95%)
    if (preg_match('/^(?:rgb|rgba|hsl|hsla)\(\s*[0-9.,%\s\/]+\)$/i', $color)) {
        return $color;
    }

    // Именованные цвета: red, rebeccapurple
    if (preg_match('/^[a-z]{3,20}$/i', $color)) {
        return $color;
    }

    return $fallback;
}

// 1. FOUC-защита (до рендера body)
add_action('render_head_start', function() {
    $settings = getSettingsData();
    $themeDefault = $settings['theme_default'] ?? 'light';
    if (!in_array($themeDefault, ['light', 'dark'], true)) {
        $themeDefault = 'light';
    }
    echo '<script>
    (function() {
        var def = "' . e($themeDefault) . '";
        var t = localStorage.getItem("site-theme") || def;
        if (t === "dark") {
            document.documentElement.setAttribute("data-theme", "dark");
        }
    })();
    </script>';
});

// 2. CSS и переменные (в конце head)
add_action('render_head_end', function() {
    echo '<link href="css/dark-theme.css?v=' . (int)@filemtime(APP_ROOT . '/css/dark-theme.css') . '" rel="stylesheet" type="text/css"/>';
    
    $settings = getSettingsData();
    $themeDark = getThemePalette($settings, 'dark');
    $darkDefaults = getThemePalette([], 'dark');

    echo '<style>
    [data-theme="dark"] {
        --bg-main: ' . e(dark_theme_safe_color($themeDark['bg_main'], $darkDefaults['bg_main'])) . ';
        --bg-card: ' . e(dark_theme_safe_color($themeDark['bg_card'], $darkDefaults['bg_card'])) . ';
        --bg-section: ' . e(dark_theme_safe_color($themeDark['bg_section'], $darkDefaults['bg_section'])) . ';
        --text-main: ' . e(dark_theme_safe_color($themeDark['text_main'], $darkDefaults['text_main'])) . ';
        --text-muted: ' . e(dark_theme_safe_color($themeDark['text_muted'], $darkDefaults['text_muted'])) . ';
        --border-color: ' . e(dark_theme_safe_color($themeDark['border_color'], $darkDefaults['border_color'])) . ';
        
        --bg-hover: #334155;
        --bg-input: #0F172A;
    }
    </style>';
});

// 3. JS переключателя (в конце body)
add_action('render_body_end', function() {
    $settings = getSettingsData();
    if (!empty($settings['theme_toggle_enabled'])) {
        echo '<script src="js/dark-theme.js?v=' . (int)@filemtime(APP_ROOT . '/js/dark-theme.js') . '" type="text/javascript"></script>';
    }
});

// 4. Настройки (в админке)
register_plugin_settings([
    'tab' => 'colors',
    'position' => 'before',
    'callback' => function() { include __DIR__ . '/admin-before.php'; }
]);
register_plugin_settings([
    'tab' => 'colors',
    'position' => 'after',
    'callback' => function() { include __DIR__ . '/admin-after.php'; }
]);

// 5. Сохранение
add_filter('save_settings_data', function($newSettings) {
    // Дефолты палитры берём из ядра, чтобы не дублировать значения
    $darkDefaults = getThemePalette([], 'dark');

    $defaults = [
        'theme_default'        => 'light',
        'theme_toggle_enabled' => false,
    ];
    $fields = [
        'theme_default'        => 'theme_default',
        'theme_toggle_enabled' => 'theme_toggle_enabled',
    ];
    foreach ($darkDefaults as $key => $val) {
        $defaults['theme.dark.' . $key] = $val;
        $fields['theme_dark_' . $key]   = 'theme.dark.' . $key;
    }

    $submitted = save_plugin_settings($newSettings, 'theme_dark_bg_main', $defaults, $fields);

    // Валидация значений, которую хелпер не делает
    if ($submitted) {
        foreach ($darkDefaults as $key => $val) {
            $postedColor = $_POST['theme_dark_' . $key] ?? '';
            $newSettings['theme']['dark'][$key] = dark_theme_safe_color($postedColor, $val);
        }
        $newSettings['theme_default'] = (($_POST['theme_default'] ?? '') === 'dark') ? 'dark' : 'light';
        $newSettings['theme_toggle_enabled'] = !empty($_POST['theme_toggle_enabled']);
    }

    return $newSettings;
});

// 6. Сброс настроек при отключении
add_action('plugin_after_toggle', function($id, $active) {
    if ($id === 'dark-theme' && !$active) {
        $settings = getSettingsData();
        $settings['theme_toggle_enabled'] = false;
        saveData('settings', $settings);
    }
});

// 7. Сброс настроек при удалении (до удаления файлов)
add_action('plugin_before_delete', function($id) {
    if ($id === 'dark-theme') {
        $settings = getSettingsData();
        $settings['theme_toggle_enabled'] = false;
        saveData('settings', $settings);
    }
});