<?php
/**
 * Плагин: Резервное копирование
 *
 * Создание, восстановление и скачивание ZIP-архивов.
 * Задача крона регистрируется в общем реестре ядра.
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}
/**
 * 5. ОБРАБОТКА НАСТРОЕК РЕЗЕРВНОГО КОПИРОВАНИЯ И ХРАНЕНИЯ JSON-БАЗЫ
 */

/**
 * Вспомогательная внутренняя функция: обратимое шифрование пароля бэкапа (OpenSSL)
 */
function backups_encrypt_password(string $password): string {
    if (empty($password)) return '';
    
    $pepperFile = APP_ROOT . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . '.pepper';
    $pepper = file_exists($pepperFile) ? trim(file_get_contents($pepperFile)) : '';
    $key = hash_hmac('sha256', 'cms_backup_secure_salt', $pepper);
    
    $ivLength = openssl_cipher_iv_length('aes-256-cbc');
    $iv = openssl_random_pseudo_bytes($ivLength);
    $encrypted = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $iv);
    
    return base64_encode($iv . $encrypted);
}

/**
 * Вспомогательная внутренняя функция: обратимая расшифровка пароля бэкапа
 */
function backups_decrypt_password(string $encryptedBase64): string {
    if (empty($encryptedBase64)) return '';
    
    $pepperFilePath = APP_ROOT . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . '.pepper';
    $pepper = file_exists($pepperFilePath) ? trim(file_get_contents($pepperFilePath)) : '';
    $key = hash_hmac('sha256', 'cms_backup_secure_salt', $pepper);
    
    $data = base64_decode($encryptedBase64);
    $ivLength = openssl_cipher_iv_length('aes-256-cbc');
    $iv = substr($data, 0, $ivLength);
    $encryptedText = substr($data, $ivLength);
    
    return openssl_decrypt($encryptedText, 'aes-256-cbc', $key, 0, $iv) ?: '';
}

/**
 * Вспомогательная внутренняя функция: чтение текущего JSON-конфига бэкапов на сервере
 */
function backups_get_settings(): array {
    $configFile = APP_ROOT . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'backup_config.json';
    if (!file_exists($configFile)) {
        return [
            'backup_type' => 'full',
            'targets' => ['data', 'images'],
            'storage_path' => 'config/backups/',
            'encrypt_archive' => false,
            'archive_password' => '',
            'cron_enabled' => false,
            'cron_virtual' => false,
            'cron_period' => 24
        ];
    }
    return json_decode(file_get_contents($configFile), true) ?? [];
}

/**
 * Внутренняя служебная функция: расчет абсолютного пути к папке бэкапов
 */
function backups_get_storage_dir(): string {
    // Если есть временные настройки — используем их
    if (isset($GLOBALS['_temp_backup_settings'])) {
        $settings = $GLOBALS['_temp_backup_settings'];
    } else {
        $settings = backups_get_settings();
    }
    $storagePath = trim($settings['storage_path'] ?? 'config/backups/');
    
    // Стандартизируем разделители под текущую ОС
    $storagePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $storagePath);

    $isAbsoluteWindows = (preg_match('/^[a-zA-Z]:[\\\\\/]/', $storagePath) === 1);
    $isAbsoluteLinux = (strpos($storagePath, DIRECTORY_SEPARATOR) === 0);

    if (DIRECTORY_SEPARATOR === '\\' && $isAbsoluteLinux && !$isAbsoluteWindows) {
        $isAbsoluteLinux = false; 
    }

    if ($isAbsoluteWindows || $isAbsoluteLinux) {
        $realStorageDir = $storagePath;
    } else {
        $cleanPath = trim($storagePath, DIRECTORY_SEPARATOR . '.');
        $rawPath = APP_ROOT . DIRECTORY_SEPARATOR . $cleanPath;
        
        if (strpos($storagePath, '..') !== false) {
            $parts = explode(DIRECTORY_SEPARATOR, $rawPath);
            $absolutes = [];
            foreach ($parts as $part) {
                if ('.' == $part || '' == $part) continue;
                if ('..' == $part) {
                    array_pop($absolutes);
                } else {
                    $absolutes[] = $part;
                }
            }
            $assembledPath = implode('/', $absolutes);
            
            if (preg_match('/^[a-zA-Z]:/', $assembledPath) === 1) {
                $realStorageDir = $assembledPath;
            } else {
                $realStorageDir = '/' . $assembledPath;
            }
        } else {
            $realStorageDir = APP_ROOT . DIRECTORY_SEPARATOR . $cleanPath;
        }
    }

    return rtrim($realStorageDir, DIRECTORY_SEPARATOR);
}

/**
 * Вспомогательная функция: рекурсивный сбор всех файлов в папке
 */
function backups_get_files_recursive(string $dir): array {
    $files = [];
    if (!is_dir($dir)) return $files;
    
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            $files = array_merge($files, backups_get_files_recursive($path));
        } else {
            // Сохраняем относительный путь от корня сайта, чтобы архив распаковывался красиво
            $relativePath = str_replace(APP_ROOT . DIRECTORY_SEPARATOR, '', $path);
            $files[] = str_replace('\\', '/', $relativePath);
        }
    }
    return $files;
}

/**
 * Вспомогательная внутренняя функция: рекурсивное и чистое удаление папки с диска
 * Не стирает папку с архивами бэкапов при полном откате!
 */
function backups_delete_dir_recursive(string $dir): bool {
    if (!is_dir($dir)) return false;

    // Узнаем, где лежит папка бэкапов
    $storageDir = backups_get_storage_dir();
    
    // Если текущая удаляемая папка — это и есть наша папка бэкапов, МЫ ЕЁ НЕ ТРОГАЕМ!
    if (realpath($dir) === realpath($storageDir)) {
        return true; 
    }

    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        
        // Дополнительная проверка для вложенных файлов папки бэкапов
        if (strpos(realpath($path), realpath($storageDir)) === 0) {
            continue;
        }

        if (is_dir($path)) {
            backups_delete_dir_recursive($path);
        } else {
            @unlink($path);
        }
    }
    
    // Не удаляем саму родительскую папку, если она содержит внутри себя защищенную папку бэкапов
    if (strpos(realpath($storageDir), realpath($dir)) === 0) {
        return true;
    }

    return @rmdir($dir);
}


/**
 * ЕДИНЫЙ СИСТЕМНЫЙ ДВИЖОК АРХИВАЦИИ
 */
function backups_execute_engine(string $archivePath, array $filesList, bool $encrypt, string $encryptedPassword, bool $overwrite = true): bool {
    $zip = new ZipArchive();
    $mode = $overwrite ? ZipArchive::CREATE | ZipArchive::OVERWRITE : 0;

    $opened = false;
    for ($retry = 0; $retry < 5; $retry++) {
        if ($zip->open($archivePath, $mode) === true) {
            $opened = true;
            break;
        }
        usleep(50000);
    }

    if (!$opened) {
        return false;
    }

    $clearPassword = '';
    if ($encrypt && !empty($encryptedPassword)) {
        $clearPassword = backups_decrypt_password($encryptedPassword);
    }

    if ($clearPassword !== '') {
        $zip->setPassword($clearPassword);
    }

    foreach ($filesList as $relativePath) {
        $absolutePath = APP_ROOT . DIRECTORY_SEPARATOR . $relativePath;
        if (file_exists($absolutePath) && is_file($absolutePath)) {
            $zip->addFile($absolutePath, $relativePath);
            
            if ($clearPassword !== '') {
                $zip->setEncryptionName($relativePath, ZipArchive::EM_AES_256, $clearPassword);
            }
        }
    }

    $zip->close();
    clearstatcache(true, $archivePath);
    return true;
}

/**
 * ХЭНДЛЕР А: СОХРАНЕНИЕ НАСТРОЕК КОНФИГУРАЦИИ БЭКАПОВ (С ОЧИСТКОЙ ПАРОЛЕЙ И ПРОБЕЛОВ)
 */
function backups_handle_save_settings(): array {
    $clientToken = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || $clientToken !== $_SESSION['csrf_token']) {
        return ['success' => '', 'error' => 'Критическая ошибка безопасности: невалидный токен сессии.'];
    }

    $configFile = APP_ROOT . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'backup_config.json';
    
    // Считываем текущую конфигурацию из JSON до перезаписи, чтобы сохранить неизменяемые параметры
    $current = backups_get_settings();

    // Определяем режим бэкапа и типы объектов
    $backupType = $_POST['backup_type'] ?? 'full';
    if ($backupType === 'full') {
        // РЕЖИМ FULL: Папки в конфиг не пишем, ядро само заберет весь корень монолитом
        $targets = [];
    } else {
        // РЕЖИМ CUSTOM: Берем строго то, что админ накликал на экране в матрице
        $targets = !empty($_POST['targets']) && is_array($_POST['targets']) ? $_POST['targets'] : [];
        
        // Защита от дурака: если переключили в выборочный режим, но сняли вообще все галочки
        if (empty($targets)) {
            setFlash('Ошибка конфигурации: необходимо отметить хотя бы один объект для архивации!', 'error');
            header('Location: index.php?tab=backups');
            exit;
        }
        
        // Фильтруем прилетевшие имена папок от возможных инъекций путей
        $targets = array_map(function($v) {
            $v = trim($v);
            // Блокируем опасные символы (path traversal)
            if (strpos($v, '..') !== false || strpos($v, '/') !== false || strpos($v, '\\') !== false) {
                return '';
            }
            return $v;
        }, $targets);
        $targets = array_values(array_filter($targets));
    }

    
    // Проверяем флаг шифрования из нативной POST-формы
    $encryptArchive = isset($_POST['encrypt_archive']);

    // СБОР И КОРРЕКЦИЯ ПАРОЛЯ СВЕРХУ-ВНИЗ
    $rawPassword = $_POST['archive_password'] ?? '';
    $cleanPassword = trim($rawPassword); // 1. Очищаем от случайных пробелов на входе

    if (!$encryptArchive) {
        // 2. Если шифрование снято — намертво забываем и стираем пароль
        $finalEncryptedPassword = '';
    } else {
        // Если шифрование ВКЛЮЧЕНО
        if ($cleanPassword !== '' && $cleanPassword !== '........') {
            // Пользователь ввёл новый чистый пароль — шифруем его в OpenSSL
            $finalEncryptedPassword = backups_encrypt_password($cleanPassword);
        } else {
            // В поле пустые точки (пароль не менялся) — подтягиваем ранее сохранённый ключ из переменной $current
            $finalEncryptedPassword = $current['archive_password'] ?? '';
        }
    }

    // === СОХРАНЯЕМ ПУТЬ ===
    $storagePath = trim($_POST['storage_path'] ?? 'config/backups/');

    // === ПРОВЕРКА: используем backups_get_storage_dir() для нормализации ===
    // Сначала сохраняем временно, чтобы получить реальный путь
    $tempSettings = [
        'storage_path' => $storagePath
    ];
    // Временно сохраняем в глобальную переменную для backups_get_storage_dir()
    $GLOBALS['_temp_backup_settings'] = $tempSettings;
    
    // Получаем нормализованный путь
    $realPath = backups_get_storage_dir();
    
    // Проверяем, можно ли создать папку
    if (!is_dir($realPath)) {
        if (!@mkdir($realPath, 0755, true)) {
            setFlash('Ошибка: не удалось создать папку для хранения бэкапов по указанному пути. Проверьте права на запись.', 'error', 5);
            header('Location: index.php?tab=backups');
            exit;
        }
    }
    
    // Проверяем, можно ли записать файл
    $testFile = $realPath . DIRECTORY_SEPARATOR . '.test_write';
    if (!safeFileWrite($testFile, 'test')) {
        setFlash('Ошибка: нет прав на запись в указанную папку. Проверьте права доступа CHMOD.', 'error', 5);
        header('Location: index.php?tab=backups');
        exit;
    }
    @unlink($testFile);
    
    // Убираем временную переменную
    unset($GLOBALS['_temp_backup_settings']);
    
    $settings = [
        'backup_type'      => $backupType, 
        'targets'          => $targets,             
        'storage_path'     => trim($_POST['storage_path'] ?? 'config/backups/'),
        'encrypt_archive'  => $encryptArchive, // Записываем честный булев флаг true/false
        'archive_password' => $finalEncryptedPassword, // Записываем выверенный очищенный хэш
        'cron_enabled'     => isset($_POST['cron_enabled']),
        'cron_virtual'     => isset($_POST['cron_virtual']),
        'cron_period'      => intval($_POST['cron_period'] ?? 24)
    ];

    $dir = dirname($configFile);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    safeFileWrite($configFile, json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

    setFlash('Конфигурация резервного копирования успешно сохранена!');
    header('Location: index.php?tab=backups');
    exit;
}

/**
 * ХЭНДЛЕР Б: ИНИЦИАЛИЗАЦИЯ И СБОР МАССИВА ФАЙЛОВ ДЛЯ АРХИВАЦИИ
 */
function backups_handle_init(): array {
    $clientToken = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || $clientToken !== $_SESSION['csrf_token']) {
        return ['success' => '', 'error' => 'Критическая ошибка безопасности: невалидный токен сессии.'];
    }

    // 1. Загружаем текущие параметры бэкапа и единый путь хранения
    $settings = backups_get_settings();
    $realStorageDir = backups_get_storage_dir();

    // Гарантируем существование папки хранения
    if (!is_dir($realStorageDir)) {
        if (!@mkdir($realStorageDir, 0755, true)) {
            return ['success' => '', 'error' => 'Не удалось создать директорию для хранения архивов. Проверьте системные права.'];
        }
    }

    // Всегда проверяем .htaccess в папке бэкапов (если она внутри APP_ROOT)
    if (strpos($realStorageDir, APP_ROOT) === 0) {
        $htaccessFile = $realStorageDir . DIRECTORY_SEPARATOR . '.htaccess';
        $htaccessData = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order Deny,Allow\n    Deny from all\n</IfModule>\n";

        $needWrite = false;
        if (!file_exists($htaccessFile)) {
            $needWrite = true;
        } else {
            $currentContent = @file_get_contents($htaccessFile);
            if ($currentContent === false || strpos($currentContent, 'Require all denied') === false) {
                $needWrite = true;
            }
        }

        if ($needWrite) {
            @file_put_contents($htaccessFile, $htaccessData);
        }
    }

    $filesToArchive = [];
    $backupType = $settings['backup_type'] ?? 'full';

    // Вычисляем относительный путь папки бэкапов для гарантированного отсечения рекурсий
    $canonicalRoot = realpath(APP_ROOT);
    $canonicalStorage = realpath($realStorageDir);
    $relativeStorageDir = '';
    if ($canonicalRoot && $canonicalStorage && strpos($canonicalStorage, $canonicalRoot) === 0) {
        $relativeStorageDir = trim(str_replace($canonicalRoot, '', $canonicalStorage), DIRECTORY_SEPARATOR . '/');
        $relativeStorageDir = str_replace('\\', '/', $relativeStorageDir);
    }

    // 2. ОПРЕДЕЛЯЕМ ОБЪЕКТЫ НА ОСНОВЕ ВЫБРАННОГО РЕЖИМА
    if ($backupType === 'full') {
        // Сценарий А: ПОЛНЫЙ БЭКАП — Берем весь корень сайта целиком как монолит
        $allRootItems = backups_get_files_recursive(APP_ROOT);
        
        foreach ($allRootItems as $file) {
            // Исключаем только саму папку с архивами бэкапов
            if ($relativeStorageDir !== '' && strpos($file, $relativeStorageDir) === 0) {
                continue;
            }
            $filesToArchive[] = $file;
        }
    } else {
        // Сценарий Б: ВЫБОРOЧНЫЙ БЭКАП — Бежим по полноценному списку папок из матрицы чекбоксов
        $targets = $settings['targets'] ?? [];
        
        if (empty($targets)) {
            return ['success' => '', 'error' => 'Вы выбрали режим «Выборочно», но сняли все галочки объектов. Нечего архивировать!'];
        }

        foreach ($targets as $target) {
            $targetPath = APP_ROOT . DIRECTORY_SEPARATOR . $target;

            if (is_dir($targetPath)) {
                // Папка — рекурсивно
                $dirFiles = backups_get_files_recursive($targetPath);
                foreach ($dirFiles as $file) {
                    if ($relativeStorageDir !== '' && strpos($file, $relativeStorageDir) === 0) {
                        continue;
                    }
                    $filesToArchive[] = $file;
                }
            } elseif (is_file($targetPath)) {
                // Файл — добавляем напрямую
                $filesToArchive[] = $target;
            }
        }
    }

    if (empty($filesToArchive)) {
        return ['success' => '', 'error' => 'Структура выбранных директорий пуста или заблокирована.'];
    }

    // 3. Генерируем уникальное имя файла архива
    $encMarker = !empty($settings['encrypt_archive']) ? '_enc_' : '_';
    $archiveName = 'backup_' . $backupType . $encMarker . date('Ymd_His') . '.zip';
    $absoluteArchivePath = $realStorageDir . DIRECTORY_SEPARATOR . $archiveName;

    // 4. Разбиваем массив файлов на пачки для AJAX ProgressBar
    $chunkSize = 50; 
    $fileChunks = array_chunk($filesToArchive, $chunkSize);

    // 5. Записываем состояние сессии для пошагового выполнения
    $_SESSION['backup_task'] = [
        'archive_name' => $archiveName,
        'archive_path' => $absoluteArchivePath,
        'chunks'       => $fileChunks,
        'total_steps'  => count($fileChunks),
        'encrypt'      => !empty($settings['encrypt_archive']),
        'password'     => $settings['archive_password'] ?? ''
    ];

    return [
        'success'      => 'Сканирование завершено! Структура готова к пошаговой архивации.',
        'error'        => '',
        'total_steps'  => count($fileChunks),
        'archive_name' => $archiveName
    ];
}

/**
 * ХЭНДЛЕР В: ПОШАГОВАЯ АРХИВАЦИЯ ОЧЕРЕДИ ФАЙЛОВ (0% НАГРУЗКИ НА ПАМЯТЬ)
 */
function backups_handle_step(): array {
    $clientToken = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || $clientToken !== $_SESSION['csrf_token']) {
        return ['success' => '', 'error' => 'Критическая ошибка безопасности: невалидный токен сессии.'];
    }

    if (empty($_SESSION['backup_task'])) {
        logAction('backup_create', 'Системная ошибка: сессионная задача бэкапа не найдена', 'ERROR');
        return ['success' => '', 'error' => 'Системная ошибка: сессионная задача бэкапа не найдена.'];
    }

    $task = &$_SESSION['backup_task'];
    $currentStep = intval($_POST['step'] ?? 0);

    if ($currentStep < 0 || $currentStep >= $task['total_steps']) {
        logAction('backup_create', 'Некорректный номер шага архивации', 'ERROR');
        return ['success' => '', 'error' => 'Некорректный номер шага архивации.'];
    }

    $fileChunk = $task['chunks'][$currentStep] ?? [];
    
    if (!empty($fileChunk)) {
        $isFirstStep = ($currentStep === 0);
        
        $success = backups_execute_engine(
            $task['archive_path'], 
            $fileChunk, 
            $task['encrypt'], 
            $task['password'],
            $isFirstStep
        );

        if (!$success) {
            logAction('backup_create', 'Ошибка записи в ZIP-архив на шаге ' . $currentStep, 'ERROR');
            return ['success' => '', 'error' => 'Файловая система занята. Ошибка записи в ZIP-архив на шаге ' . $currentStep];
        }
    }
    
    $nextStep = $currentStep + 1;
    $isFinished = ($nextStep >= $task['total_steps']);

    // Если это был финальный шаг — очищаем временную задачу и фиксируем время
    if ($isFinished) {
        unset($_SESSION['backup_task']);
        logAction('backup_create', 'Создан бэкап: ' . $task['archive_name'], 'INFO');
        set_cron_last_run('backups', time());
    }

    return [
        'success'     => $isFinished ? 'Резервная копия успешно создана и сохранена в архив!' : 'Пачка файлов успешно упакована.',
        'error'       => '',
        'current_percent' => round(($nextStep / $task['total_steps']) * 100),
        'is_finished' => $isFinished,
        'next_step'   => $nextStep
    ];
}

/**
 * ХЭНДЛЕР Г: БЕЗОПАСНОЕ УДАЛЕНИЕ ФИЗИЧЕСКОГО ZIP-АРХИВА С СЕРВЕРА
 */
function backups_handle_delete(): array {
    $clientToken = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || $clientToken !== $_SESSION['csrf_token']) {
        setFlash('Критическая ошибка безопасности: невалидный токен сессии.', 'error');
        return ['success' => '', 'error' => 'CSRF error'];
    }

    $fileName = trim($_POST['delete_file'] ?? '');
    if (empty($fileName) || strpos($fileName, '/') !== false || strpos($fileName, '\\') !== false) {
        setFlash('Некорректное или опасное имя файла архива.', 'error');
        return ['success' => '', 'error' => 'Invalid file'];
    }

    $storageDir = backups_get_storage_dir();
    $absoluteFilePath = $storageDir . DIRECTORY_SEPARATOR . $fileName;

    if (file_exists($absoluteFilePath) && is_file($absoluteFilePath)) {
        if (@unlink($absoluteFilePath)) {
            logAction('backup_delete', 'Удалён бэкап: ' . $fileName, 'INFO');
            setFlash('Резервная копия успешно и безвозвратно удалена с сервера!');
            return ['success' => 'Deleted', 'error' => ''];
        }
        logAction('backup_delete', 'Ошибка удаления бэкапа: ' . $fileName . '. Проверьте системные права доступа CHMOD.', 'ERROR');
        setFlash('Не удалось удалить файл. Проверьте системные права доступа CHMOD.', 'error');
        return ['success' => '', 'error' => 'CHMOD error'];
    }

    // ИСПРАВЛЕНО: Если файла уже нет на диске, мы пишем ошибку во ФЛЭШ-СЕССИЮ, чтобы страница обновилась и красиво вывела тост!
    logAction('backup_delete', 'Ошибка удаления бэкапа: ' . $fileName . '. Указанный архив не найден на сервере.', 'ERROR');
    setFlash('Указанный архив не найден на сервере. Возможно, он уже удален.', 'error');
    return ['success' => '', 'error' => 'Not found'];
}

/**
 * ХЭНДЛЕР Д: БЕЗОПАСНОЕ СКАЧИВАНИЕ ZIP-АРХИВА ЧЕРЕЗ БИНАРНЫЙ ПОТОК PHP
 */
function backups_handle_download(): void {
    if (empty($_SESSION['admin_auth'])) {
        die('Доступ запрещен');
    }

    $fileName = trim($_GET['download_file'] ?? '');
    
    // Защита: отсекаем любые попытки хакинга путей (../)
    if (empty($fileName) || strpos($fileName, '/') !== false || strpos($fileName, '\\') !== false) {
        die('Некорректное имя файла архива.');
    }

    // Вызываем единую служебную функцию расчета путей
    $storageDir = backups_get_storage_dir();
    $absoluteFilePath = $storageDir . DIRECTORY_SEPARATOR . $fileName;

    if (file_exists($absoluteFilePath) && is_file($absoluteFilePath)) {
        // КРИТИЧЕСКИЙ ФИКС: Жестко чистим все буферы PHP, чтобы убрать случайные пробелы из кода
        while (ob_get_level()) {
            ob_end_clean();
        }

        // HTTP-заголовки для отдачи бинарного ZIP-потока
        header('Content-Description: File Transfer');
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($fileName) . '"');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($absoluteFilePath));
        
        // Транслируем файл напрямую с диска в браузер
        readfile($absoluteFilePath);
        exit; // Железно глушим скрипт, чтобы к архиву не приклеился HTML-код каркаса!
    }

    die('Запрошенный файл резервной копии не найден на сервере.');
}

/**
 * ЗАДАЧА КРОНА: АВТОМАТИЧЕСКИЙ БЭКАП (ВЫЗЫВАЕТСЯ ИЗ CRON/RUN.PHP)
 *
 * @return bool false только при реальной ошибке; true, если запускать нечего
 */
function backups_run_cron(): bool {
    $settings = backups_get_settings();

    if (empty($settings['cron_enabled'])) {
        return true;
    }

    $realStorageDir = backups_get_storage_dir();
    if (!is_dir($realStorageDir)) {
        @mkdir($realStorageDir, 0755, true);
    }

    $filesToArchive = [];
    $backupType = $settings['backup_type'] ?? 'full';

    // Вычисляем относительный путь папки бэкапов для гарантированного отсечения рекурсий
    $canonicalRoot = realpath(APP_ROOT);
    $canonicalStorage = realpath($realStorageDir);
    $relativeStorageDir = '';
    if ($canonicalRoot && $canonicalStorage && strpos($canonicalStorage, $canonicalRoot) === 0) {
        $relativeStorageDir = trim(str_replace($canonicalRoot, '', $canonicalStorage), DIRECTORY_SEPARATOR . '/');
        $relativeStorageDir = str_replace('\\', '/', $relativeStorageDir);
    }

    if ($backupType === 'full') {
        // Сценарий А: ПОЛНЫЙ БЭКАП КРОНА — Сканируем весь корень сайта монолитом
        $allRootItems = backups_get_files_recursive(APP_ROOT);
        foreach ($allRootItems as $file) {
            // Железно исключаем только саму папку с архивами бэкапов
            if ($relativeStorageDir !== '' && strpos($file, $relativeStorageDir) === 0) {
                continue;
            }
            $filesToArchive[] = $file;
        }
    } else {
        // Сценарий Б: ВЫБОРOЧНЫЙ БЭКАП КРОНА — Берем список папок из сохраненного массива targets
        $targets = $settings['targets'] ?? [];
        if (empty($targets)) {
            return true;
        }

        foreach ($targets as $target) {
            $targetPath = APP_ROOT . DIRECTORY_SEPARATOR . $target;

            if (is_dir($targetPath)) {
                $dirFiles = backups_get_files_recursive($targetPath);
                foreach ($dirFiles as $file) {
                    if ($relativeStorageDir !== '' && strpos($file, $relativeStorageDir) === 0) {
                        continue;
                    }
                    $filesToArchive[] = $file;
                }
            } elseif (is_file($targetPath)) {
                $filesToArchive[] = $target;
            }
        }
    }

    if (empty($filesToArchive)) {
        return true;
    }

    $encMarker = !empty($settings['encrypt_archive']) ? 'enc_' : '';
    $archiveBase = 'cron_' . $backupType . '_' . $encMarker . date('Ymd_His');
    $archiveName = $archiveBase . '.zip';
    $absoluteArchivePath = $realStorageDir . DIRECTORY_SEPARATOR . $archiveName;

    // Два запуска в одну секунду не должны перезаписывать один и тот же файл
    $suffix = 1;
    while (file_exists($absoluteArchivePath)) {
        $archiveName = $archiveBase . '_' . $suffix . '.zip';
        $absoluteArchivePath = $realStorageDir . DIRECTORY_SEPARATOR . $archiveName;
        $suffix++;
    }

    $success = backups_execute_engine(
        $absoluteArchivePath, 
        $filesToArchive, 
        !empty($settings['encrypt_archive']), 
        $settings['archive_password'] ?? '',
        true
    );

    if (!$success) {
        logAction('backup_create', 'Ошибка создания бэкапа по расписанию', 'ERROR');
        return false;
    }

    logAction('backup_create', 'Создан бэкап по расписанию: ' . $archiveName, 'INFO');

    // Время запуска фиксирует cron/run.php при захвате задачи
    return true;
}

/**
 * ХЭНДЛЕР Ж: БЕЗОПАСНОЕ ПОЛНОЕ ВОССТАНОВЛЕНИЕ (ОТКАТ) СИСТЕМЫ ИЗ ZIP-АРХИВА
 * Пофайловое извлечение через стримы (для обхода ограничений extractTo при AES-256)
 */
function backups_handle_restore(): array {
    $clientToken = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || $clientToken !== $_SESSION['csrf_token']) {
        setFlash('Критическая ошибка безопасности: невалидный токен сессии.', 'error');
        return ['success' => '', 'error' => 'CSRF error'];
    }

    $fileName = trim($_POST['restore_file'] ?? '');
    if (empty($fileName) || strpos($fileName, '/') !== false || strpos($fileName, '\\') !== false) {
        setFlash('Некорректное имя файла архива.', 'error');
        return ['success' => '', 'error' => 'Invalid file'];
    }

    $storageDir = backups_get_storage_dir();
    $absoluteArchivePath = $storageDir . DIRECTORY_SEPARATOR . $fileName;

    if (!file_exists($absoluteArchivePath) || !is_file($absoluteArchivePath)) {
        setFlash('Указанный файл архива не найден на сервере.', 'error');
        return ['success' => '', 'error' => 'Not found'];
    }

    $inputPassword = trim($_POST['restore_password'] ?? '');

    // ИСПРАВЛЕНО: Открываем архив строго в режиме чтения READONLY для стабильной работы криптоконтура Windows
    $zip = new ZipArchive();
    if ($zip->open($absoluteArchivePath, ZipArchive::RDONLY) !== true) {
        setFlash('Не удалось открыть ZIP-архив. Возможно, файл поврежден.', 'error');
        return ['success' => '', 'error' => 'Zip open error'];
    }

    // Устанавливаем глобальный пароль архива
    if ($inputPassword !== '') {
        $zip->setPassword($inputPassword);
    }
    
    // === ЗАЩИТА ОТ ZIP SLIP ===
    $zipSlipEntry = detectZipSlip($zip);
    if ($zipSlipEntry !== null) {
        $zip->close();
        logAction('backup_restore', 'ZIP Slip в бэкапе: ' . $zipSlipEntry, 'ERROR');
        setFlash('Архив содержит небезопасные имена файлов. Восстановление отменено.', 'error');
        return ['success' => '', 'error' => 'Zip slip'];
    }
    // === КОНЕЦ ЗАЩИТЫ ===

    // Создаем скрытый бункер для распаковки
    $stagingDir = APP_ROOT . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . '.restore_staging';
    if (is_dir($stagingDir)) {
        backups_delete_dir_recursive($stagingDir);
    }
    @mkdir($stagingDir, 0755, true);

    // --- СТАДИЯ А: ПОФАЙЛОВОЕ ИЗВЛЕЧЕНИЕ ЧЕРЕЗ СТАБИЛЬНЫЙ EXTRACTTO (AES-256) ---
    $extractSuccess = true;
    $extractedFilesCount = 0;

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        $relativePath = $stat['name'];

        // Пропускаем директории, мы воссоздадим их по путям файлов
        if (substr($relativePath, -1) === '/' || substr($relativePath, -1) === '\\') {
            continue;
        }

        // ИСПРАВЛЕНО: Перед извлечением принудительно привязываем пароль к конкретному индексу файла
        if ($inputPassword !== '') {
            $zip->setEncryptionIndex($i, ZipArchive::EM_AES_256, $inputPassword);
        }

        // Извлекаем файл встроенным методом extractTo, передавая имя файла поштучно
        if (@$zip->extractTo($stagingDir, $relativePath)) {
            $extractedFilesCount++;
        } else {
            $extractSuccess = false;
            break;
        }
    }
    $zip->close();

    // Жесткая проверка: если пароль не подошел или файлы извлеклись пустыми (0 байт)
    if (!$extractSuccess || $extractedFilesCount === 0) {
        backups_delete_dir_recursive($stagingDir);
        setFlash('Ошибка расшифровки архива. Введен неверный пароль!', 'error');
        return ['success' => '', 'error' => 'Decrypt error'];
    }

    // --- СТАДИЯ Б: РОТАЦИЯ ПАПОК (ЗАЩИТА ЯДРА И АРХИВОВ) ---
    $stagedItems = scandir($stagingDir);
    $itemsToRestore = [];
    foreach ($stagedItems as $item) {
        if ($item === '.' || $item === '..') continue;
        $itemsToRestore[] = $item;
    }

    if (empty($itemsToRestore)) {
        backups_delete_dir_recursive($stagingDir);
        setFlash('Структура архива пуста или повреждена.', 'error');
        return ['success' => '', 'error' => 'Empty archive'];
    }

    foreach ($itemsToRestore as $item) {
        $livePath = APP_ROOT . DIRECTORY_SEPARATOR . $item;
        $stagedPath = $stagingDir . DIRECTORY_SEPARATOR . $item;

        if (is_dir($stagedPath)) {
            $volatileDirs = ['data', 'images'];

            if (in_array($item, $volatileDirs)) {
                if (is_dir($livePath)) {
                    backups_delete_dir_recursive($livePath);
                }
            }
            
            if (!is_dir($livePath)) {
                @mkdir($livePath, 0755, true);
            }
            
            $storageDir = realpath(backups_get_storage_dir());

            $directoryIterator = new RecursiveDirectoryIterator($stagedPath, RecursiveDirectoryIterator::SKIP_DOTS);
            $iterator = new RecursiveIteratorIterator($directoryIterator, RecursiveIteratorIterator::SELF_FIRST);

            foreach ($iterator as $fileInfo) {
                $subPath = substr($fileInfo->getPathname(), strlen($stagedPath));
                $targetLivePath = $livePath . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $subPath);

                if ($storageDir && strpos(realpath($targetLivePath), $storageDir) === 0) {
                    continue;
                }

                if ($fileInfo->isDir()) {
                    if (!is_dir($targetLivePath)) {
                        @mkdir($targetLivePath, 0755, true);
                    }
                } else {
                    $targetDir = dirname($targetLivePath);
                    if (!is_dir($targetDir)) {
                        @mkdir($targetDir, 0755, true);
                    }
                    @copy($fileInfo->getPathname(), $targetLivePath);
                }
            }
        } else {
            @copy($stagedPath, $livePath);
        }
    }

    backups_delete_dir_recursive($stagingDir);

    logAction('backup_restore', 'Восстановлен бэкап: ' . $fileName, 'INFO');

    // Архив мог заменить data/ или images/ целиком — HTML-кеш описывает прежнюю систему.
    // clearPageCache() живёт в admin_controller.php, поэтому проверяем наличие.
    if (function_exists('clearPageCache')) {
        clearPageCache();
    }

    // Подписчики (SEO и другие плагины) узнают, что данные заменены из архива
    do_action('backup_restored', $fileName, $itemsToRestore);

    setFlash('Система успешно восстановлена из резервной копии! Все данные откатаны назад.');
    return ['success' => 'Restored', 'error' => ''];
}

/**
 * Обрабатывает POST/GET-запросы плагина в админке.
 * Вызывается на admin_init: ядро уже проверило авторизацию и CSRF.
 *
 * @return void
 */
function backups_handle_admin_requests(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['save_backup_settings'])) {
            backups_handle_save_settings();
            return;
        }

        if (isset($_POST['init_backup_process'])) {
            echo json_encode(backups_handle_init());
            exit;
        }

        if (isset($_POST['process_backup_step'])) {
            echo json_encode(backups_handle_step());
            exit;
        }

        if (isset($_POST['delete_backup_action'])) {
            backups_handle_delete();
            header('Location: index.php?tab=backups');
            exit;
        }

        if (isset($_POST['restore_backup_action'])) {
            backups_handle_restore();
            header('Location: index.php?tab=backups');
            exit;
        }
    }

    if (isset($_GET['download_file']) && ($_GET['tab'] ?? '') === 'backups') {
        backups_handle_download();
    }
}

add_action('admin_init', 'backups_handle_admin_requests');

// Регистрируем задачу в общем реестре ядра
$backupsCronSettings = backups_get_settings();
register_cron_task('backups', 'backups_run_cron', [
    'interval' => max(1, (int)($backupsCronSettings['cron_period'] ?? 24)) * 3600,
    'virtual'  => !empty($backupsCronSettings['cron_virtual']) && !empty($backupsCronSettings['cron_enabled']),
    'enabled'  => !empty($backupsCronSettings['cron_enabled']),
    'label'    => 'Резервное копирование',
]);

// Регистрируем действия логирования
register_log_action('backup_create', 'Создание бэкапа', 'Бэкапы', 'database-backup');
register_log_action('backup_restore', 'Восстановление из бэкапа', 'Бэкапы', 'database-backup');
register_log_action('backup_delete', 'Удаление бэкапа', 'Бэкапы', 'database-backup');

// Файл с (зашифрованным) паролем архива недоступен через проводник
add_filter('sensitive_files', function (array $files): array {
    $files[] = 'backup_config.json';
    return $files;
});