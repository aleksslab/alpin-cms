/**
 * Плагин «Резервное копирование»: управление архивами и пошаговой сборкой.
 */

(function () {
    'use strict';

    var initialized = false;

    /**
     * Переключает видимость полей формы в зависимости от выбранного режима.
     *
     * @return {void}
     */
    function toggleFields() {
        var form = document.getElementById('js-backup-form');
        if (!form) return;

        var typeRadio = form.querySelector('input[name="backup_type"]:checked');
        var targetsZone = document.getElementById('js-backup-targets-zone');
        var encryptToggle = document.getElementById('js-backup-encrypt-toggle');
        var passwordZone = document.getElementById('js-backup-password-zone');
        var passwordInput = document.getElementById('js-backup-password-input');
        var cronVirtual = form.querySelector('input[name="cron_virtual"]');
        var cronEnabled = form.querySelector('input[name="cron_enabled"]');
        var cronPeriodZone = document.getElementById('js-backup-cron-period-zone');
        var cronLinkZone = document.getElementById('js-backup-cron-link-zone');

        if (targetsZone) {
            targetsZone.classList.toggle('hidden', !typeRadio || typeRadio.value === 'full');
        }

        if (passwordZone) {
            var encryptOn = !!(encryptToggle && encryptToggle.checked);
            passwordZone.classList.toggle('hidden', !encryptOn);

            if (passwordInput) {
                passwordInput.required = encryptOn;
                if (!encryptOn) {
                    passwordInput.value = '';
                }
            }
        }

        if (cronPeriodZone && cronVirtual) {
            cronPeriodZone.classList.toggle('hidden', !cronVirtual.checked);
        }

        if (cronLinkZone && cronEnabled) {
            cronLinkZone.classList.toggle('hidden', !cronEnabled.checked);
        }
    }

    /**
     * Возвращает CSRF-токен формы бэкапов.
     *
     * @return {string}
     */
    function getCsrfToken() {
        var input = document.getElementById('js-backup-csrf-token');
        return input ? input.value : '';
    }

    /**
     * Сбрасывает интерфейс прогресса после ошибки.
     *
     * @param {HTMLElement|null} button Кнопка запуска
     * @param {HTMLElement|null} zone   Зона прогресса
     * @return {void}
     */
    function resetProgress(button, zone) {
        if (button) button.disabled = false;
        if (zone) zone.classList.add('hidden');
    }

    /**
     * Показывает всплывающее уведомление.
     *
     * @param {string} message Текст
     * @param {string} type    success|error
     * @return {void}
     */
    function showToast(message, type) {
        type = type || 'success';

        var container = document.getElementById('js-backups-toast-container');

        if (!container) {
            container = document.createElement('div');
            container.id = 'js-backups-toast-container';
            container.className = 'fixed top-24 right-4 md:right-6 z-[9999] flex flex-col gap-3 max-w-md w-full pointer-events-none';
            document.body.appendChild(container);
        }

        var toast = document.createElement('div');
        toast.className = 'pointer-events-auto p-4 text-sm rounded-xl flex items-center gap-3 animate-fade-in shadow-sm border';

        if (type === 'success') {
            toast.classList.add('text-emerald-800', 'bg-emerald-50', 'border-emerald-100');
        } else {
            toast.classList.add('text-rose-800', 'bg-rose-50', 'border-rose-100');
        }

        var icon = document.createElement('span');
        icon.className = (type === 'success' ? 'icon-shield-check text-[var(--primary-color)]' : 'icon-x text-rose-500') + ' text-lg';

        var text = document.createElement('div');
        text.textContent = message;

        toast.appendChild(icon);
        toast.appendChild(text);
        container.insertBefore(toast, container.firstChild);

        setTimeout(function () {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(-10px)';
            toast.style.transition = 'all 0.3s ease-in-out';

            setTimeout(function () {
                toast.remove();
            }, 300);
        }, 4000);
    }

    /**
     * Запускает пошаговую сборку архива.
     *
     * @return {void}
     */
    async function startGeneration() {
        var progressZone = document.getElementById('js-backup-progress-zone');
        var statusText = document.getElementById('js-backup-status-text');
        var percentText = document.getElementById('js-backup-percent-text');
        var progressBar = document.getElementById('js-backup-progress-bar');
        var button = document.getElementById('js-backup-start');

        if (!progressZone || !statusText || !percentText || !progressBar || !button) return;

        button.disabled = true;
        progressZone.classList.remove('hidden');

        statusText.innerText = 'Сканирование директорий и подсчет объектов...';
        percentText.innerText = '0%';
        progressBar.style.width = '0%';

        var csrfToken = getCsrfToken();

        try {
            var initData = new FormData();
            initData.append('init_backup_process', '1');
            initData.append('csrf_token', csrfToken);

            var initResponse = await fetch('index.php?tab=backups', {
                method: 'POST',
                body: initData
            });

            if (!initResponse.ok) {
                throw new Error('Ошибка инициализации сервера: ' + initResponse.status);
            }

            var initResult = await initResponse.json();

            if (initResult.error) {
                showToast('Ошибка: ' + initResult.error, 'error');
                resetProgress(button, progressZone);
                return;
            }

            var totalSteps = parseInt(initResult.total_steps || 1, 10);
            showToast('Структура проекта готова. Сборка архива...', 'success');

            var currentStep = 0;

            while (currentStep < totalSteps) {
                statusText.innerText = 'Упаковка файлов... Шаг ' + (currentStep + 1) + ' из ' + totalSteps;

                var stepData = new FormData();
                stepData.append('process_backup_step', '1');
                stepData.append('step', currentStep.toString());
                stepData.append('csrf_token', csrfToken);

                var stepResponse = await fetch('index.php?tab=backups', {
                    method: 'POST',
                    body: stepData
                });

                if (!stepResponse.ok) {
                    throw new Error('Ошибка на шаге ' + (currentStep + 1) + ': ' + stepResponse.status);
                }

                var stepResult = await stepResponse.json();

                if (stepResult.error) {
                    showToast('Критический сбой архивации: ' + stepResult.error, 'error');
                    resetProgress(button, progressZone);
                    return;
                }

                var percent = parseInt(stepResult.current_percent || 0, 10);
                percentText.innerText = percent + '%';
                progressBar.style.width = percent + '%';

                if (stepResult.is_finished) {
                    showToast(stepResult.success || 'Архив успешно создан!', 'success');
                    break;
                }

                currentStep = parseInt(stepResult.next_step || (currentStep + 1), 10);

                await new Promise(function (resolve) {
                    setTimeout(resolve, 150);
                });
            }

            statusText.innerText = 'Сборка завершена! Обновление реестра архивов...';
            setTimeout(function () {
                window.location.reload();
            }, 1500);
        } catch (error) {
            showToast('Критическая ошибка AJAX: ' + error.message, 'error');
            resetProgress(button, progressZone);
        }
    }

    /**
     * Скачивает архив.
     *
     * @param {string} fileName Имя файла
     * @return {void}
     */
    function downloadBackup(fileName) {
        if (!fileName) return;
        window.location.href = 'index.php?tab=backups&download_file=' + encodeURIComponent(fileName);
    }

    /**
     * Удаляет архив после подтверждения.
     *
     * @param {string} fileName Имя файла
     * @return {void}
     */
    function deleteBackup(fileName) {
        if (!fileName) return;

        if (!confirm('Вы действительно хотите навсегда и безвозвратно удалить архив "' + fileName + '" с сервера?')) {
            return;
        }

        submitBackupForm('delete_backup_action', [
            { name: 'delete_file', value: fileName }
        ]);
    }

    /**
     * Восстанавливает систему из архива.
     *
     * @param {string}  fileName    Имя файла
     * @param {boolean} isEncrypted Архив зашифрован
     * @return {void}
     */
    function restoreBackup(fileName, isEncrypted) {
        if (!fileName) return;

        var message = 'ВНИМАНИЕ!\n'
            + 'Вы собираетесь восстановить систему из архива "' + fileName + '".\n'
            + 'Текущие файлы будут ПОЛНОСТЬЮ СТЕРТЫ и заменены данными из бэкапа!\n\n'
            + 'Вы уверены, что хотите продолжить откат системы?';

        if (!confirm(message)) {
            return;
        }

        var archivePassword = '';

        if (isEncrypted) {
            archivePassword = prompt('Внимание: Данный архив зашифрован (AES-256).\nВведите пароль для распаковки:', '');

            if (archivePassword === null) {
                return;
            }

            archivePassword = archivePassword.trim();

            if (archivePassword === '') {
                showToast('Ошибка: Пароль не может быть пустым!', 'error');
                return;
            }
        }

        submitBackupForm('restore_backup_action', [
            { name: 'restore_file', value: fileName },
            { name: 'restore_password', value: archivePassword }
        ]);
    }

    /**
     * Отправляет скрытую POST-форму на вкладку бэкапов.
     *
     * @param {string} actionName Имя action-поля
     * @param {Array}  fields     Дополнительные поля [{name, value}]
     * @return {void}
     */
    function submitBackupForm(actionName, fields) {
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = 'index.php?tab=backups';

        var actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = actionName;
        actionInput.value = '1';
        form.appendChild(actionInput);

        fields.forEach(function (field) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = field.name;
            input.value = field.value;
            form.appendChild(input);
        });

        var tokenInput = document.createElement('input');
        tokenInput.type = 'hidden';
        tokenInput.name = 'csrf_token';
        tokenInput.value = getCsrfToken();
        form.appendChild(tokenInput);

        document.body.appendChild(form);
        form.submit();
    }

    /**
     * Подписывает делегированные обработчики и первично настраивает форму.
     *
     * @return {void}
     */
    function init() {
        if (initialized) return;
        if (!document.getElementById('js-backup-form')) return;

        initialized = true;
        toggleFields();

        document.addEventListener('click', function (event) {
            if (event.target.closest('#js-backup-start')) {
                startGeneration();
                return;
            }

            var actionButton = event.target.closest('[data-backup-action]');
            if (!actionButton) return;

            var action = actionButton.getAttribute('data-backup-action');
            var file = actionButton.getAttribute('data-backup-file') || '';

            if (!file) return;

            if (action === 'download') {
                downloadBackup(file);
            } else if (action === 'restore') {
                restoreBackup(file, actionButton.getAttribute('data-backup-encrypted') === '1');
            } else if (action === 'delete') {
                deleteBackup(file);
            }
        });

        document.addEventListener('change', function (event) {
            if (event.target.closest('#js-backup-form')) {
                toggleFields();
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
