/**
 * Cookie-согласие — клиентская логика.
 *
 * Решение посетителя хранится в cookie alpin_consent вместе с версией
 * согласия. Сниппеты лежат в инертных <template> (код в base64) и
 * выполняются только для разрешённых категорий. Серверный HTML от
 * согласия не зависит — страницу можно кешировать.
 */
(function () {
    'use strict';

    var COOKIE_NAME = 'alpin_consent';
    var configNode = document.getElementById('alpin-consent-config');
    if (!configNode) {
        return;
    }

    var config;
    try {
        config = JSON.parse(configNode.textContent || '{}');
    } catch (error) {
        return;
    }

    if (!config || !config.version || !config.categories) {
        return;
    }

    var root = document.getElementById('alpin-consent');
    var reopenBtn = document.getElementById('alpin-consent-reopen');
    var settingsPanel = root ? root.querySelector('.alpin-consent__settings') : null;
    var closeBtn = root ? root.querySelector('[data-consent-action="close"]') : null;

    /**
     * Категории, которые нельзя отключить.
     *
     * Только необходимые: остальные категории посетитель вправе отклонить
     * в любой момент, иначе согласие перестаёт быть согласием.
     *
     * @returns {Array}
     */
    function lockedCategories() {
        return ['necessary'];
    }

    /**
     * Категории, включённые в панели по умолчанию.
     *
     * Только необходимые. Предварительно отмеченные необязательные галочки
     * не считаются согласием, поэтому их посетитель ставит сам.
     *
     * @returns {Array}
     */
    function preferredCategories() {
        return lockedCategories();
    }

    /**
     * Читает cookie согласия.
     *
     * @returns {Array|null} Разрешённые категории или null, если решения нет
     */
    function readConsent() {
        var raw = getCookie(COOKIE_NAME);
        if (!raw) {
            return null;
        }

        var parts = raw.split('|');
        if (parts.length !== 2 || parts[0] !== config.version) {
            return null;
        }

        var allowed = parts[1] === '' ? [] : parts[1].split(',');

        return normalize(allowed);
    }

    /**
     * Приводит набор категорий к валидному виду.
     *
     * @param {Array} categories
     * @returns {Array}
     */
    function normalize(categories) {
        var result = lockedCategories();

        if (Array.isArray(categories)) {
            categories.forEach(function (id) {
                if (typeof id !== 'string' || result.indexOf(id) !== -1) {
                    return;
                }

                var known = config.categories.some(function (category) {
                    return category.id === id;
                });

                if (known) {
                    result.push(id);
                }
            });
        }

        return result;
    }

    /**
     * Сохраняет решение в cookie.
     *
     * @param {Array} categories
     * @returns {void}
     */
    function writeConsent(categories) {
        var days = parseInt(config.days, 10);
        if (!isFinite(days) || days < 1 || days > 3650) {
            days = 180;
        }

        var expires = new Date();
        expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);

        var value = config.version + '|' + categories.join(',');
        var cookie = COOKIE_NAME + '=' + value
            + ';expires=' + expires.toUTCString()
            + ';path=/;SameSite=Lax';

        if (window.location.protocol === 'https:') {
            cookie += ';Secure';
        }

        document.cookie = cookie;
    }

    /**
     * Удаляет cookie согласия.
     *
     * @returns {void}
     */
    function deleteConsent() {
        document.cookie = COOKIE_NAME + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;SameSite=Lax';
    }

    /**
     * Читает cookie по имени.
     *
     * @param {string} name
     * @returns {string}
     */
    function getCookie(name) {
        var prefix = name + '=';
        var parts = document.cookie ? document.cookie.split(';') : [];

        for (var i = 0; i < parts.length; i++) {
            var part = parts[i].replace(/^\s+/, '');
            if (part.indexOf(prefix) === 0) {
                return part.substring(prefix.length);
            }
        }

        return '';
    }

    /**
     * Декодирует base64 в строку UTF-8.
     *
     * @param {string} value
     * @returns {string}
     */
    function decodeBase64(value) {
        var binary;

        try {
            binary = window.atob(value);
        } catch (error) {
            return '';
        }

        var bytes = new Uint8Array(binary.length);
        var i;

        for (i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }

        if (window.TextDecoder) {
            try {
                return new TextDecoder('utf-8').decode(bytes);
            } catch (error) {
                // Падаем в резервный вариант ниже.
            }
        }

        var escaped = '';
        for (i = 0; i < bytes.length; i++) {
            escaped += '%' + ('0' + bytes[i].toString(16)).slice(-2);
        }

        try {
            return decodeURIComponent(escaped);
        } catch (error) {
            return binary;
        }
    }

    /**
     * Выполняет HTML-код сниппета.
     *
     * Скрипты, вставленные через innerHTML, браузер не выполняет, поэтому
     * каждый найденный <script> заменяется свежесозданным элементом.
     *
     * @param {string} code HTML-код сниппета
     * @returns {void}
     */
    function runSnippet(code) {
        if (!code) {
            return;
        }

        var holder = document.createElement('div');
        holder.className = 'alpin-consent__snippet';
        holder.innerHTML = code;

        var scripts = holder.querySelectorAll('script');
        var i;

        for (i = 0; i < scripts.length; i++) {
            var source = scripts[i];
            var script = document.createElement('script');
            var j;

            for (j = 0; j < source.attributes.length; j++) {
                script.setAttribute(source.attributes[j].name, source.attributes[j].value);
            }

            script.text = source.textContent;
            source.parentNode.replaceChild(script, source);
        }

        document.body.appendChild(holder);
    }

    /**
     * Активирует сниппеты категории.
     *
     * @param {string} category ID категории
     * @returns {void}
     */
    function activateCategory(category) {
        var templates = document.querySelectorAll('template[data-consent-cat="' + category + '"]');
        var i;

        for (i = 0; i < templates.length; i++) {
            var template = templates[i];

            if (template.getAttribute('data-consent-activated') === '1') {
                continue;
            }

            template.setAttribute('data-consent-activated', '1');
            runSnippet(decodeBase64(template.getAttribute('data-consent-code') || ''));
        }
    }

    /**
     * Разрешена ли категория.
     *
     * @param {string} category ID категории
     * @returns {boolean}
     */
    function isAllowed(category) {
        if (category === 'necessary') {
            return true;
        }

        if (lockedCategories().indexOf(category) !== -1) {
            return true;
        }

        var current = readConsent();

        return current !== null && current.indexOf(category) !== -1;
    }

    /**
     * Текущее состояние всех категорий.
     *
     * @returns {Object}
     */
    function snapshot() {
        var result = {};

        config.categories.forEach(function (category) {
            result[category.id] = isAllowed(category.id);
        });

        return result;
    }

    /**
     * Показывает или скрывает баннер.
     *
     * @param {boolean} visible
     * @param {boolean} withSettings Открыть панель категорий
     * @returns {void}
     */
    function toggleBanner(visible, withSettings) {
        if (!root) {
            return;
        }

        root.hidden = !visible;

        if (withSettings !== undefined) {
            setSettingsVisible(visible ? withSettings : false);
        }

        if (visible) {
            syncCheckboxes();
            updateClose();
        }
    }

    /**
     * Крестик закрытия виден только при сохранённом решении.
     *
     * Без решения закрывать баннер нельзя: молчание не считается согласием,
     * а закрытие без выбора оставило бы посетителя без понятного отказа.
     *
     * @returns {void}
     */
    function updateClose() {
        if (!closeBtn) {
            return;
        }

        closeBtn.hidden = readConsent() === null;
    }

    /**
     * Показывает или скрывает панель категорий.
     *
     * @param {boolean} visible
     * @returns {void}
     */
    function setSettingsVisible(visible) {
        if (settingsPanel) {
            settingsPanel.hidden = !visible;
        }
    }

    /**
     * Проставляет галочки по сохранённому решению.
     *
     * @returns {void}
     */
    function syncCheckboxes() {
        var boxes = root ? root.querySelectorAll('input[data-consent-cat]') : [];
        var current = readConsent();

        Array.prototype.forEach.call(boxes, function (box) {
            var id = box.getAttribute('data-consent-cat');

            if (box.disabled) {
                return;
            }

            if (current === null) {
                box.checked = preferredCategories().indexOf(id) !== -1;
                return;
            }

            box.checked = current.indexOf(id) !== -1;
        });
    }

    /**
     * Показывает кнопку повторного открытия настроек.
     *
     * @param {boolean} visible
     * @returns {void}
     */
    function toggleReopen(visible) {
        if (!reopenBtn) {
            return;
        }

        reopenBtn.hidden = !visible || !config.reopen;
    }

    /**
     * Сохраняет решение и применяет его.
     *
     * @param {Array}  categories
     * @param {string} action
     * @returns {void}
     */
    function applyConsent(categories, action) {
        var previous = readConsent();
        var next = normalize(categories);

        writeConsent(next);

        next.forEach(function (category) {
            activateCategory(category);
        });

        toggleBanner(false, false);
        toggleReopen(true);

        document.dispatchEvent(new CustomEvent('alpin:consent', {
            detail: {
                version: config.version,
                categories: snapshot(),
                action: action || 'save'
            }
        }));

        // Отзыв уже выданной категории: выгрузить чужой скрипт нельзя,
        // поэтому перезагружаем страницу — после неё сниппет не выполнится.
        if (previous !== null) {
            var revoked = previous.some(function (category) {
                return next.indexOf(category) === -1;
            });

            if (revoked) {
                window.location.reload();
            }
        }
    }

    /**
     * Собирает выбранные категории из панели.
     *
     * @returns {Array}
     */
    function readCheckboxes() {
        var boxes = root ? root.querySelectorAll('input[data-consent-cat]') : [];
        var result = lockedCategories();

        Array.prototype.forEach.call(boxes, function (box) {
            if (!box.checked || box.disabled) {
                return;
            }

            var id = box.getAttribute('data-consent-cat');
            if (result.indexOf(id) === -1) {
                result.push(id);
            }
        });

        return result;
    }

    /**
     * Все необязательные категории.
     *
     * @returns {Array}
     */
    function allCategories() {
        return config.categories.map(function (category) {
            return category.id;
        });
    }

    // === Публичный API для модулей и сторонних плагинов ===

    window.AlpinConsent = {
        /**
         * Версия согласия: меняется при правке категорий и сниппетов.
         */
        version: String(config.version),

        /**
         * Список категорий.
         */
        categories: allCategories(),

        /**
         * Разрешена ли категория.
         *
         * @param {string} category
         * @returns {boolean}
         */
        isAllowed: function (category) {
            return isAllowed(String(category));
        },

        /**
         * Категория отклонена сохранённым решением.
         *
         * Отличается от isAllowed(): до первого согласия вернёт false,
         * то есть «ещё не спрашивали», а не «запретили».
         *
         * @param {string} category
         * @returns {boolean}
         */
        isDenied: function (category) {
            return readConsent() !== null && !isAllowed(String(category));
        },

        /**
         * Состояние всех категорий.
         *
         * @returns {Object}
         */
        get: function () {
            return snapshot();
        },

        /**
         * Сохраняет выбор категорий.
         *
         * @param {Array} categories
         * @returns {void}
         */
        set: function (categories) {
            applyConsent(Array.isArray(categories) ? categories : [], 'api');
        },

        /**
         * Принять все категории.
         *
         * @returns {void}
         */
        acceptAll: function () {
            applyConsent(allCategories(), 'all');
        },

        /**
         * Только необходимые.
         *
         * @returns {void}
         */
        rejectAll: function () {
            applyConsent(lockedCategories(), 'necessary');
        },

        /**
         * Открыть настройки.
         *
         * @returns {void}
         */
        open: function () {
            toggleBanner(true, true);
        },

        /**
         * Забыть решение и спросить заново.
         *
         * @returns {void}
         */
        reset: function () {
            deleteConsent();
            toggleBanner(true, false);
            toggleReopen(false);
        }
    };

    // === Обработчики интерфейса ===

    document.addEventListener('click', function (event) {
        var target = event.target;
        if (!target || !target.closest) {
            return;
        }

        var policyBtn = target.closest('[data-consent-policy]');
        if (policyBtn) {
            event.preventDefault();
            if (typeof window.openPolicy === 'function') {
                window.openPolicy(policyBtn.getAttribute('data-consent-policy'));
            }
            return;
        }

        var actionBtn = target.closest('[data-consent-action]');
        if (actionBtn) {
            event.preventDefault();

            var action = actionBtn.getAttribute('data-consent-action');

            if (action === 'all') {
                applyConsent(allCategories(), 'all');
            } else if (action === 'necessary') {
                applyConsent(lockedCategories(), 'necessary');
            } else if (action === 'configure') {
                setSettingsVisible(true);
            } else if (action === 'back') {
                setSettingsVisible(false);
            } else if (action === 'close') {
                toggleBanner(false, false);
            } else if (action === 'save') {
                applyConsent(readCheckboxes(), 'save');
            }

            return;
        }

        if (target.closest('#alpin-consent-reopen')) {
            event.preventDefault();
            toggleBanner(true, readConsent() !== null);
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape' || !root || root.hidden) {
            return;
        }

        // Escape сначала закрывает панель категорий, потом уже баннер.
        if (settingsPanel && !settingsPanel.hidden) {
            setSettingsVisible(false);
            return;
        }

        if (readConsent() !== null) {
            toggleBanner(false, false);
        }
    });

    /**
     * Первичная инициализация.
     *
     * @returns {void}
     */
    function init() {
        var current = readConsent();

        // Необходимые сниппеты выполняются всегда.
        activateCategory('necessary');

        if (current === null) {
            if (config.banner) {
                toggleBanner(true, false);
            }
            return;
        }

        current.forEach(function (category) {
            activateCategory(category);
        });

        toggleBanner(false, false);
        toggleReopen(true);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
