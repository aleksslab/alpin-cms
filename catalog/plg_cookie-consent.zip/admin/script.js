/**
 * Cookie-согласие — скрипты админки.
 *
 * Добавление и удаление сниппетов в категориях. Делегирование на document:
 * секция может быть отрисована повторно, обработчики при этом не дублируются.
 */
(function () {
    'use strict';

    /**
     * Возвращает шаблон строки сниппета.
     *
     * @returns {HTMLTemplateElement|null}
     */
    function getTemplate() {
        return document.getElementById('cc-snippet-template');
    }

    /**
     * Возвращает контейнер сниппетов категории.
     *
     * @param {string} category ID категории
     * @returns {HTMLElement|null}
     */
    function getContainer(category) {
        if (!category) {
            return null;
        }

        return document.getElementById('cc-snippets-' + category);
    }

    /**
     * Добавляет пустой сниппет в категорию.
     *
     * @param {HTMLElement} button Кнопка «Добавить сниппет»
     * @returns {void}
     */
    function addSnippet(button) {
        var template = getTemplate();
        if (!template) {
            return;
        }

        var category = button.getAttribute('data-category') || '';
        var container = getContainer(category);
        if (!container) {
            return;
        }

        var index = parseInt(container.getAttribute('data-next') || '0', 10);
        if (isNaN(index) || index < 0) {
            index = 0;
        }

        var html = template.innerHTML
            .split('__CAT__').join(category)
            .split('__IDX__').join(String(index));

        var wrapper = document.createElement('div');
        wrapper.innerHTML = html;

        var snippet = wrapper.firstElementChild;
        if (!snippet) {
            return;
        }

        container.appendChild(snippet);
        container.setAttribute('data-next', String(index + 1));

        var nameInput = snippet.querySelector('input[type="text"]');
        if (nameInput) {
            nameInput.focus();
        }
    }

    /**
     * Удаляет строку сниппета.
     *
     * @param {HTMLElement} button Кнопка удаления
     * @returns {void}
     */
    function removeSnippet(button) {
        var snippet = button.closest('.cc-snippet');
        if (!snippet || !snippet.parentNode) {
            return;
        }

        snippet.parentNode.removeChild(snippet);
    }

    /**
     * Приводит счётчики data-next в соответствие с числом строк.
     *
     * Нужен после восстановления формы из кеша браузера: там может оказаться
     * больше строк, чем запомнил сервер.
     *
     * @returns {void}
     */
    function initCounters() {
        var containers = document.querySelectorAll('[id^="cc-snippets-"]');

        Array.prototype.forEach.call(containers, function (container) {
            var count = container.querySelectorAll('.cc-snippet').length;
            var next = parseInt(container.getAttribute('data-next') || '', 10);

            if (isNaN(next) || next < count) {
                container.setAttribute('data-next', String(count));
            }
        });
    }

    document.addEventListener('click', function (event) {
        var target = event.target;
        if (!target || !target.closest) {
            return;
        }

        var addButton = target.closest('.js-cc-add-snippet');
        if (addButton) {
            event.preventDefault();
            addSnippet(addButton);
            return;
        }

        var removeButton = target.closest('.js-cc-remove-snippet');
        if (removeButton) {
            event.preventDefault();
            removeSnippet(removeButton);
        }
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initCounters);
    } else {
        initCounters();
    }
})();
