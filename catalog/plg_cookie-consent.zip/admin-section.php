<?php
/**
 * Секция настроек: Cookie-согласие.
 */

if (!defined('APP_ROOT') || empty($_SESSION['admin_auth'])) {
    die('Доступ запрещен');
}

$ccSettings = cookie_consent_get_settings();
$ccDefaults = cookie_consent_defaults();
$ccCategories = cookie_consent_get_categories();
$ccCategoryDefaults = cookie_consent_category_defaults();
$ccRenderCategories = cookie_consent_render_categories();
$ccVersion = cookie_consent_version($ccRenderCategories);
$ccHasSnippets = cookie_consent_has_snippets($ccRenderCategories);
$ccBannerRequired = cookie_consent_banner_required($ccSettings, $ccRenderCategories);
$ccBannerPluginActive = function_exists('isPluginActive') && isPluginActive('cookie-banner');
$ccCustomJs = cookie_consent_custom_js_conflict();

$ccScriptFile = CONFIG_DIR . '/js/cookie-consent.js';
$ccScriptVersion = is_file($ccScriptFile) ? (int)filemtime($ccScriptFile) : 0;
?>

<div class="border border-slate-200 rounded-2xl overflow-hidden mb-5">
    <div class="section-header bg-slate-50 px-4 py-3 border-b border-slate-100 flex items-center justify-between cursor-pointer hover:bg-slate-100/50 transition-colors" onclick="window.toggleSection(this)">
        <div class="flex items-center gap-3">
            <span class="section-arrow icon-chevron-right text-xs text-slate-400"></span>
            <span class="text-sm font-bold text-slate-700">Cookie-согласие</span>
            <span class="text-[10px] text-slate-400">(категории, сниппеты, баннер)</span>
        </div>
        <?php if ($ccBannerRequired): ?>
            <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200">баннер включён</span>
        <?php else: ?>
            <span class="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 border border-slate-200">баннер выключен</span>
        <?php endif; ?>
    </div>
    <div class="section-content p-6 bg-slate-50 hidden">
        <input type="hidden" name="cookie_consent_section" value="1">

        <?php if ($ccBannerPluginActive): ?>
            <div class="mb-5 flex items-start gap-3 p-3 bg-amber-50 border border-amber-200 rounded-xl">
                <span class="icon-alert-triangle text-amber-500 mt-0.5"></span>
                <p class="text-xs text-amber-800">
                    Плагин «Cookie-баннер» активен. Пока работает Cookie-согласие, простой баннер не выводится,
                    а его настройки игнорируются — выключи его на вкладке «Плагины».
                </p>
            </div>
        <?php endif; ?>

        <?php if ($ccCustomJs): ?>
            <div class="mb-5 flex items-start gap-3 p-3 bg-rose-50 border border-rose-200 rounded-xl">
                <span class="icon-alert-triangle text-rose-500 mt-0.5"></span>
                <p class="text-xs text-rose-800">
                    В «Настройках сайта» заполнено поле «Произвольный JS». Такой код выводится в конце страницы
                    <strong>без согласия</strong>. Перенеси счётчики и пиксели в сниппеты ниже, иначе согласие обходится.
                </p>
            </div>
        <?php endif; ?>

        <div class="mb-5 flex flex-wrap items-center gap-3 text-[11px] text-slate-500">
            <span>Сниппетов в необязательных категориях: <strong><?php echo $ccHasSnippets ? 'есть' : 'нет'; ?></strong></span>
            <span class="text-slate-300">•</span>
            <span>Версия согласия: <code class="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200"><?php echo e($ccVersion); ?></code></span>
            <span class="text-slate-300">•</span>
            <span>При изменении состава сниппетов посетители спрашиваются заново.</span>
        </div>

        <div class="space-y-5">
            <div class="editor-field">
                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Заголовок баннера</label>
                <input type="text" name="cookie_consent_title" value="<?php echo e($ccSettings['cookie_consent_title']); ?>" placeholder="<?php echo e($ccDefaults['cookie_consent_title']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
            </div>

            <div class="editor-field">
                <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Текст баннера</label>
                <textarea name="cookie_consent_text" rows="4" class="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]" placeholder="<?php echo e($ccDefaults['cookie_consent_text']); ?>"><?php echo e($ccSettings['cookie_consent_text']); ?></textarea>
                <p class="text-[10px] text-slate-400 mt-1">
                    Плейсхолдеры <code class="font-mono bg-white px-1 rounded border border-slate-200">{policy}</code> и
                    <code class="font-mono bg-white px-1 rounded border border-slate-200">{cookie}</code> заменяются на ссылки.
                    HTML запрещён.
                </p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="editor-field">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">«Принять все»</label>
                    <input type="text" name="cookie_consent_accept_label" value="<?php echo e($ccSettings['cookie_consent_accept_label']); ?>" placeholder="<?php echo e($ccDefaults['cookie_consent_accept_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                </div>
                <div class="editor-field">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">«Только необходимые»</label>
                    <input type="text" name="cookie_consent_necessary_label" value="<?php echo e($ccSettings['cookie_consent_necessary_label']); ?>" placeholder="<?php echo e($ccDefaults['cookie_consent_necessary_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                </div>
                <div class="editor-field">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">«Настроить»</label>
                    <input type="text" name="cookie_consent_configure_label" value="<?php echo e($ccSettings['cookie_consent_configure_label']); ?>" placeholder="<?php echo e($ccDefaults['cookie_consent_configure_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                </div>
                <div class="editor-field">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">«Сохранить выбор»</label>
                    <input type="text" name="cookie_consent_save_label" value="<?php echo e($ccSettings['cookie_consent_save_label']); ?>" placeholder="<?php echo e($ccDefaults['cookie_consent_save_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="editor-field">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">«Назад» в панели категорий</label>
                    <input type="text" name="cookie_consent_back_label" value="<?php echo e($ccSettings['cookie_consent_back_label']); ?>" placeholder="<?php echo e($ccDefaults['cookie_consent_back_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    <p class="text-[10px] text-slate-400 mt-1">Возвращает к кнопкам «Принять все / Только необходимые».</p>
                </div>
                <div class="editor-field">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Положение баннера</label>
                    <select name="cookie_consent_position" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                        <?php foreach (cookie_consent_positions() as $ccPosValue => $ccPosLabel): ?>
                            <option value="<?php echo e($ccPosValue); ?>" <?php echo $ccSettings['cookie_consent_position'] === $ccPosValue ? 'selected' : ''; ?>><?php echo e($ccPosLabel); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="text-[10px] text-slate-400 mt-1">Баннер прижат к низу окна; на узких экранах занимает всю ширину.</p>
                </div>
            </div>

            <div class="border-t border-slate-200/60 pt-4 mt-2">
                <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Ссылки в баннере</div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Политика: подпись</label>
                        <input type="text" name="cookie_consent_policy_label" value="<?php echo e($ccSettings['cookie_consent_policy_label']); ?>" placeholder="<?php echo e($ccDefaults['cookie_consent_policy_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Политика: URL</label>
                        <input type="text" name="cookie_consent_policy_url" value="<?php echo e($ccSettings['cookie_consent_policy_url']); ?>" placeholder="Пусто — встроенная модалка" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Условия cookie: подпись</label>
                        <input type="text" name="cookie_consent_cookie_label" value="<?php echo e($ccSettings['cookie_consent_cookie_label']); ?>" placeholder="<?php echo e($ccDefaults['cookie_consent_cookie_label']); ?>" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                    <div class="editor-field">
                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Условия cookie: URL</label>
                        <input type="text" name="cookie_consent_cookie_url" value="<?php echo e($ccSettings['cookie_consent_cookie_url']); ?>" placeholder="Пусто — встроенная модалка" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:border-[var(--primary-color)]">
                    </div>
                </div>
                <p class="text-[10px] text-slate-400 mt-1">Пустой URL открывает встроенную модалку политики ядра.</p>
            </div>

            <div class="border-t border-slate-200/60 pt-4 mt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div class="editor-field">
                    <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Срок хранения согласия, дней</label>
                    <input type="number" name="cookie_consent_days" value="<?php echo (int)$ccSettings['cookie_consent_days']; ?>" min="1" max="3650" class="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-[var(--primary-color)]">
                    <p class="text-[10px] text-slate-400 mt-1">По умолчанию 180. Хранится в cookie <code class="font-mono bg-white px-1 rounded border border-slate-200">alpin_consent</code>.</p>
                </div>
                <div class="space-y-3">
                    <label class="flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                        <input type="hidden" name="cookie_consent_float_button" value="0">
                        <input type="checkbox" name="cookie_consent_float_button" value="1" <?php echo $ccSettings['cookie_consent_float_button'] ? 'checked' : ''; ?> class="w-4 h-4 text-[var(--primary-color)] rounded border-slate-300 focus:ring-[var(--primary-color)]">
                        Плавающая кнопка повторного открытия настроек
                    </label>
                    <label class="flex items-start gap-2 text-xs text-slate-600 cursor-pointer">
                        <input type="hidden" name="cookie_consent_force_banner" value="0">
                        <input type="checkbox" name="cookie_consent_force_banner" value="1" <?php echo $ccSettings['cookie_consent_force_banner'] ? 'checked' : ''; ?> class="w-4 h-4 mt-0.5 text-[var(--primary-color)] rounded border-slate-300 focus:ring-[var(--primary-color)]">
                        <span>Показывать баннер, даже если сниппетов нет<br><span class="text-[10px] text-slate-400">Нужно для карт и видео в модулях: они спрашивают категорию «Функциональные».</span></span>
                    </label>
                </div>
            </div>

            <div class="border-t border-slate-200/60 pt-4 mt-2">
                <div class="flex items-center justify-between mb-3">
                    <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Категории и сниппеты</div>
                    <div class="text-[10px] text-slate-400">Только необходимые включены по умолчанию</div>
                </div>

                <div class="flex items-start gap-2 text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 mb-3">
                    <span class="icon-alert-triangle text-sm shrink-0 mt-0.5"></span>
                    <span>Код сниппета выполняется с полными правами страницы: он может читать и менять содержимое, отправлять запросы от имени посетителя и получать доступ к формам. Вставляйте только проверенный код, а изменения записываются в журнал.</span>
                </div>

                <div class="space-y-3">
                    <?php foreach ($ccCategories as $ccId => $ccCategory): ?>
                        <?php
                        $ccIsNecessary = ($ccId === 'necessary');
                        $ccCategoryTitle = $ccCategory['title'];
                        ?>
                        <details class="border border-slate-200 rounded-xl bg-white overflow-hidden">
                            <summary class="px-4 py-3 cursor-pointer select-none flex items-center justify-between gap-3 hover:bg-slate-50">
                                <span class="flex items-center gap-2">
                                    <span class="text-sm font-semibold text-slate-700"><?php echo e($ccCategoryTitle); ?></span>
                                    <?php if ($ccIsNecessary): ?>
                                        <span class="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 border border-slate-200">всегда включена</span>
                                    <?php else: ?>
                                        <span class="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 border border-slate-200"><?php echo count($ccCategory['snippets']); ?> сниппетов</span>
                                    <?php endif; ?>
                                </span>
                                <span class="text-[10px] text-slate-400 font-mono"><?php echo e($ccId); ?></span>
                            </summary>
                            <div class="px-4 pb-4 pt-1 space-y-3 border-t border-slate-100">
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3">
                                    <div class="editor-field">
                                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Название</label>
                                        <input type="text" name="cookie_consent_cat[<?php echo e($ccId); ?>][title]" value="<?php echo e($ccCategory['title']); ?>" placeholder="<?php echo e($ccCategoryDefaults[$ccId]['title']); ?>" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[var(--primary-color)]">
                                    </div>
                                    <div class="editor-field">
                                        <label class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Описание</label>
                                        <input type="text" name="cookie_consent_cat[<?php echo e($ccId); ?>][description]" value="<?php echo e($ccCategory['description']); ?>" placeholder="<?php echo e($ccCategoryDefaults[$ccId]['description']); ?>" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[var(--primary-color)]">
                                    </div>
                                </div>

                                <?php if ($ccIsNecessary): ?>
                                    <p class="text-[10px] text-slate-400">
                                        Категория показывается в баннере всегда, её сниппеты выполняются сразу и не отключаются — это законное исключение.
                                    </p>
                                <?php else: ?>
                                    <label class="flex items-start gap-2 text-xs text-slate-600 cursor-pointer">
                                        <input type="hidden" name="cookie_consent_cat[<?php echo e($ccId); ?>][always_show]" value="0">
                                        <input type="checkbox" name="cookie_consent_cat[<?php echo e($ccId); ?>][always_show]" value="1" <?php echo $ccCategory['always_show'] ? 'checked' : ''; ?> class="w-4 h-4 mt-0.5 text-[var(--primary-color)] rounded border-slate-300 focus:ring-[var(--primary-color)]">
                                        <span>Показывать в баннере, даже если сниппетов нет<br><span class="text-[10px] text-slate-400">Без галочки категория появляется только при наличии сниппетов или когда её запросил контент страницы. Включите, если хотите, чтобы посетитель мог решить заранее: согласие одно на весь сайт.</span></span>
                                    </label>
                                    <p class="text-[10px] text-slate-400">
                                        В панели галочка снята, посетитель включает её сам: предварительно отмеченные галочки не считаются согласием.
                                    </p>
                                <?php endif; ?>

                                <div class="space-y-2" id="cc-snippets-<?php echo e($ccId); ?>" data-next="<?php echo count($ccCategory['snippets']); ?>">
                                    <?php foreach ($ccCategory['snippets'] as $ccIndex => $ccSnippet): ?>
                                        <div class="cc-snippet border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-2">
                                            <div class="flex items-center gap-2">
                                                <input type="text" name="cookie_consent_cat[<?php echo e($ccId); ?>][snippets][<?php echo (int)$ccIndex; ?>][name]" value="<?php echo e($ccSnippet['name']); ?>" placeholder="Название (например, Яндекс.Метрика)" class="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[var(--primary-color)]">
                                                <button type="button" class="js-cc-remove-snippet w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-400 hover:text-rose-500 hover:border-rose-200 hover:bg-rose-50 transition-colors" title="Удалить сниппет">
                                                    <span class="icon-x text-sm"></span>
                                                </button>
                                            </div>
                                            <textarea name="cookie_consent_cat[<?php echo e($ccId); ?>][snippets][<?php echo (int)$ccIndex; ?>][code]" rows="5" placeholder="Код: скрипт, пиксель, HTML" class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono focus:outline-none focus:border-[var(--primary-color)]"><?php echo e($ccSnippet['code']); ?></textarea>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <button type="button" class="js-cc-add-snippet w-full py-2 border border-dashed border-slate-300 rounded-lg text-slate-500 hover:border-[var(--primary-color)] hover:text-[var(--primary-color)] transition-colors text-xs flex items-center justify-center gap-2" data-category="<?php echo e($ccId); ?>">
                                    <span class="icon-plus text-sm"></span> Добавить сниппет
                                </button>
                            </div>
                        </details>
                    <?php endforeach; ?>
                </div>

                <p class="text-[10px] text-slate-400 mt-3">
                    Сниппеты выводятся в страницу инертными шаблонами и выполняются только после согласия посетителя.
                    Правка любого сниппета меняет версию согласия — посетители спросятся заново.
                </p>
            </div>
        </div>
    </div>
</div>

<template id="cc-snippet-template">
    <div class="cc-snippet border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-2">
        <div class="flex items-center gap-2">
            <input type="text" name="cookie_consent_cat[__CAT__][snippets][__IDX__][name]" placeholder="Название (например, Яндекс.Метрика)" class="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[var(--primary-color)]">
            <button type="button" class="js-cc-remove-snippet w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-400 hover:text-rose-500 hover:border-rose-200 hover:bg-rose-50 transition-colors" title="Удалить сниппет">
                <span class="icon-x text-sm"></span>
            </button>
        </div>
        <textarea name="cookie_consent_cat[__CAT__][snippets][__IDX__][code]" rows="5" placeholder="Код: скрипт, пиксель, HTML" class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono focus:outline-none focus:border-[var(--primary-color)]"></textarea>
    </div>
</template>

<?php if ($ccScriptVersion > 0): ?>
    <script src="js/cookie-consent.js?v=<?php echo $ccScriptVersion; ?>"></script>
<?php else: ?>
    <?php $ccInlineScript = @file_get_contents(__DIR__ . '/admin/script.js'); ?>
    <?php if ($ccInlineScript !== false): ?>
        <script><?php echo $ccInlineScript; ?></script>
    <?php endif; ?>
<?php endif; ?>
