<?php
/**
 * Плагин «Cookie-согласие».
 *
 * Категории cookie, баннер с выбором и активация сниппетов только после
 * явного согласия посетителя. Настройки — секцией в «Настройках сайта»,
 * рядом с простым Cookie-баннером.
 */

if (!defined('APP_ROOT')) {
    die('Доступ запрещен');
}

if (!defined('COOKIE_CONSENT_MAX_SNIPPETS')) {
    /** Максимальное число сниппетов в одной категории. */
    define('COOKIE_CONSENT_MAX_SNIPPETS', 30);

    /** Максимальный размер кода одного сниппета, байт. */
    define('COOKIE_CONSENT_MAX_SNIPPET_SIZE', 20000);

    /** Максимальный суммарный размер сниппетов, байт. */
    define('COOKIE_CONSENT_MAX_TOTAL_SIZE', 262144);
}

/**
 * Идентификаторы категорий в фиксированном порядке.
 *
 * @return array
 */
function cookie_consent_category_ids(): array {
    return ['necessary', 'functional', 'analytics', 'marketing'];
}

/**
 * Категории по умолчанию: подписи и описания.
 *
 * @return array
 */
function cookie_consent_category_defaults(): array {
    return [
        'necessary' => [
            'title'       => 'Необходимые',
            'description' => 'Без них сайт не работает: сессия, защита форм, выбранные настройки.',
            'always_show' => false,
        ],
        'functional' => [
            'title'       => 'Функциональные',
            'description' => 'Карты, видео и другие встроенные блоки сторонних сервисов.',
            'always_show' => false,
        ],
        'analytics' => [
            'title'       => 'Аналитика',
            'description' => 'Счётчики посещаемости и статистика поведения.',
            'always_show' => false,
        ],
        'marketing' => [
            'title'       => 'Маркетинг',
            'description' => 'Рекламные пиксели и ретаргетинг.',
            'always_show' => false,
        ],
    ];
}

/**
 * Значения настроек по умолчанию.
 *
 * @return array
 */
function cookie_consent_defaults(): array {
    return [
        'cookie_consent_title'           => 'Мы используем cookies',
        'cookie_consent_text'            => 'Часть cookies нужна для работы сайта, остальные включаются только с вашего согласия. Ознакомьтесь с {policy} и {cookie}.',
        'cookie_consent_accept_label'    => 'Принять все',
        'cookie_consent_necessary_label' => 'Только необходимые',
        'cookie_consent_configure_label' => 'Настроить',
        'cookie_consent_save_label'      => 'Сохранить выбор',
        'cookie_consent_back_label'      => 'Назад',
        'cookie_consent_position'        => 'bottom-center',
        'cookie_consent_policy_label'    => 'Политикой конфиденциальности',
        'cookie_consent_policy_url'      => '',
        'cookie_consent_cookie_label'    => 'Условиями cookie',
        'cookie_consent_cookie_url'      => '',
        'cookie_consent_days'            => 180,
        'cookie_consent_float_button'    => true,
        'cookie_consent_force_banner'    => false,
    ];
}

/**
 * Допустимые положения баннера.
 *
 * @return array Ключ — значение настройки, значение — подпись в админке
 */
function cookie_consent_positions(): array {
    return [
        'bottom-center' => 'Снизу по центру',
        'bottom-left'   => 'Снизу слева',
        'bottom-right'  => 'Снизу справа',
    ];
}

/**
 * Возвращает настройки плагина с подстановкой значений по умолчанию.
 *
 * @return array
 */
function cookie_consent_get_settings(): array {
    $defaults = cookie_consent_defaults();
    $settings = getSettingsData();
    $result = [];

    foreach ($defaults as $key => $default) {
        $value = $settings[$key] ?? $default;

        if (is_bool($default)) {
            $result[$key] = ($value === true || $value === 1 || $value === '1');
            continue;
        }

        if (is_int($default)) {
            $value = (int)$value;
            if ($value < 1 || $value > 3650) {
                $value = (int)$default;
            }
            $result[$key] = $value;
            continue;
        }

        $value = trim((string)$value);

        // Пустой URL — это не «нет ссылки», а встроенная модалка политики.
        if ($value === '' && $key !== 'cookie_consent_policy_url' && $key !== 'cookie_consent_cookie_url') {
            $value = $default;
        }

        $result[$key] = $value;
    }

    // Положение баннера: значение приходит из формы, но в settings.json
    // могло попасть что угодно — держим только белый список.
    $positions = cookie_consent_positions();
    if (!isset($positions[$result['cookie_consent_position']])) {
        $result['cookie_consent_position'] = 'bottom-center';
    }

    return $result;
}

/**
 * Возвращает категории с подписями и сниппетами.
 *
 * @return array
 */
function cookie_consent_get_categories(): array {
    $settings = getSettingsData();
    $stored = $settings['cookie_consent_categories'] ?? [];
    $defaults = cookie_consent_category_defaults();
    $result = [];

    foreach ($defaults as $id => $default) {
        $category = (is_array($stored) && isset($stored[$id]) && is_array($stored[$id]))
            ? $stored[$id]
            : [];

        $snippets = [];
        foreach ((array)($category['snippets'] ?? []) as $snippet) {
            if (!is_array($snippet)) {
                continue;
            }

            $code = trim((string)($snippet['code'] ?? ''));
            if ($code === '') {
                continue;
            }

            $snippets[] = [
                'name' => trim((string)($snippet['name'] ?? '')),
                'code' => $code,
            ];
        }

        $title = trim((string)($category['title'] ?? ''));
        $description = trim((string)($category['description'] ?? ''));

        $result[$id] = [
            'title'       => $title !== '' ? $title : $default['title'],
            'description' => $description !== '' ? $description : $default['description'],
            'always_show' => $id !== 'necessary' && !empty($category['always_show']),
            'snippets'    => $snippets,
        ];
    }

    return $result;
}

/**
 * Есть ли сниппеты в необязательных категориях.
 *
 * @param array $categories Категории из cookie_consent_get_categories()
 * @return bool
 */
function cookie_consent_has_snippets(array $categories): bool {
    foreach ($categories as $id => $category) {
        if ($id === 'necessary') {
            continue;
        }
        if (!empty($category['snippets'])) {
            return true;
        }
    }

    return false;
}

/**
 * Нужно ли выводить баннер на странице.
 *
 * Без сниппетов спрашивать не о чем: баннер появляется только при
 * включённой галочке «показывать всегда» (нужна для карт и видео в модулях).
 *
 * @param array $settings   Настройки плагина
 * @param array $categories Категории
 * @return bool
 */
function cookie_consent_banner_required(array $settings, array $categories): bool {
    if (!empty($settings['cookie_consent_force_banner'])) {
        return true;
    }

    return cookie_consent_has_snippets($categories);
}

/**
 * Версия согласия: меняется при правке состава категорий и сниппетов.
 *
 * Флаг «показывать всегда» тоже входит в версию: если панель начала
 * показывать категорию, о которой посетитель ещё не решал, согласие нужно
 * спросить заново.
 *
 * @param array $categories Категории
 * @return string 8 hex-символов
 */
function cookie_consent_version(array $categories): string {
    $payload = [];

    foreach ($categories as $id => $category) {
        $codes = [];
        foreach ((array)($category['snippets'] ?? []) as $snippet) {
            $codes[] = (string)($snippet['code'] ?? '');
        }

        $payload[$id] = [
            'always_show' => !empty($category['always_show']),
            'snippets'    => $codes,
        ];
    }

    return substr(sha1(json_encode($payload)), 0, 8);
}

/**
 * Заполнено ли поле «Произвольный JS» в настройках сайта.
 *
 * Такой код выводится в конце body без всякого согласия, поэтому плагин
 * предупреждает о нём в своей секции.
 *
 * @return bool
 */
function cookie_consent_custom_js_conflict(): bool {
    $settings = getSettingsData();
    $customJs = trim((string)($settings['custom_js'] ?? ''));

    return $customJs !== '';
}

/**
 * Разбирает и валидирует категории из POST.
 *
 * @param mixed $raw Значение $_POST['cookie_consent_cat']
 * @return array
 */
function cookie_consent_parse_categories($raw): array {
    $defaults = cookie_consent_category_defaults();
    $result = [];

    foreach ($defaults as $id => $default) {
        $category = (is_array($raw) && isset($raw[$id]) && is_array($raw[$id])) ? $raw[$id] : [];

        $title = trim(strip_tags((string)($category['title'] ?? '')));
        $description = trim(strip_tags((string)($category['description'] ?? '')));

        $result[$id] = [
            'title'       => $title !== '' ? mb_substr($title, 0, 60) : $default['title'],
            'description' => $description !== '' ? mb_substr($description, 0, 300) : $default['description'],
            'always_show' => $id !== 'necessary' && ((string)($category['always_show'] ?? '0') === '1'),
            'snippets'    => cookie_consent_parse_snippets($category['snippets'] ?? []),
        ];
    }

    return $result;
}

/**
 * Разбирает и валидирует сниппеты одной категории.
 *
 * @param mixed $raw Массив сниппетов из POST
 * @return array
 */
function cookie_consent_parse_snippets($raw): array {
    if (!is_array($raw)) {
        return [];
    }

    $result = [];
    $totalSize = 0;

    foreach ($raw as $item) {
        if (!is_array($item)) {
            continue;
        }

        $code = str_replace(["\r\n", "\r"], "\n", (string)($item['code'] ?? ''));
        $code = trim($code);

        if ($code === '') {
            continue;
        }

        if (strlen($code) > COOKIE_CONSENT_MAX_SNIPPET_SIZE) {
            $code = substr($code, 0, COOKIE_CONSENT_MAX_SNIPPET_SIZE);
        }

        if ($totalSize + strlen($code) > COOKIE_CONSENT_MAX_TOTAL_SIZE) {
            break;
        }
        $totalSize += strlen($code);

        $name = trim(strip_tags((string)($item['name'] ?? '')));

        $result[] = [
            'name' => $name !== '' ? mb_substr($name, 0, 100) : 'Сниппет ' . (count($result) + 1),
            'code' => $code,
        ];

        if (count($result) >= COOKIE_CONSENT_MAX_SNIPPETS) {
            break;
        }
    }

    return $result;
}

/**
 * Сбрасывает HTML-кеш страниц.
 *
 * Разметка баннера и версия согласия попадают в кешированный HTML,
 * поэтому при изменении настроек кеш нужно очистить.
 *
 * @return void
 */
function cookie_consent_clear_cache(): void {
    if (function_exists('clearPageCache')) {
        clearPageCache();
    }
}

/**
 * Категории для вывода с учётом фильтра consent_snippets.
 *
 * Через фильтр сторонние плагины (например, аналитика) добавляют свои
 * сниппеты в категории. Версия согласия считается уже с их учётом.
 *
 * @return array
 */
function cookie_consent_render_categories(): array {
    $categories = cookie_consent_get_categories();
    $filtered = apply_filters('consent_snippets', $categories);

    if (!is_array($filtered)) {
        return $categories;
    }

    $known = cookie_consent_category_defaults();
    $result = [];

    foreach ($known as $id => $default) {
        $stored = $categories[$id] ?? [];
        $category = (isset($filtered[$id]) && is_array($filtered[$id])) ? $filtered[$id] : $stored;

        $snippets = [];
        foreach ((array)($category['snippets'] ?? []) as $snippet) {
            if (!is_array($snippet)) {
                continue;
            }

            $code = trim((string)($snippet['code'] ?? ''));
            if ($code === '') {
                continue;
            }

            $name = trim((string)($snippet['name'] ?? ''));

            $snippets[] = [
                'name' => $name !== '' ? $name : 'Сниппет ' . (count($snippets) + 1),
                'code' => $code,
            ];
        }

        $title = trim((string)($category['title'] ?? ''));
        $description = trim((string)($category['description'] ?? ''));

        $result[$id] = [
            'title'       => $title !== '' ? $title : $default['title'],
            'description' => $description !== '' ? $description : $default['description'],
            'always_show' => $id !== 'necessary' && !empty($category['always_show']),
            'snippets'    => $snippets,
        ];
    }

    return $result;
}

/**
 * Считает сниппеты во всех категориях, включая необходимые.
 *
 * @param array $categories Категории из cookie_consent_render_categories()
 * @return int
 */
function cookie_consent_count_snippets(array $categories): int {
    $total = 0;

    foreach ($categories as $category) {
        $total += count($category['snippets'] ?? []);
    }

    return $total;
}

/**
 * Регистрирует категорию, без которой не обойтись на текущей странице.
 *
 * Модули со сторонними вставками (карты, видео) вызывают функцию во время
 * вывода, чтобы категория попала в баннер даже без сниппетов. Без плагина
 * вызов пропускается через function_exists().
 *
 * @param string $category ID категории
 * @return void
 */
function alpin_consent_require(string $category): void {
    $known = cookie_consent_category_defaults();

    if (!isset($known[$category])) {
        return;
    }

    if (!isset($GLOBALS['ALPIN_CONSENT_REQUIRED']) || !is_array($GLOBALS['ALPIN_CONSENT_REQUIRED'])) {
        $GLOBALS['ALPIN_CONSENT_REQUIRED'] = [];
    }

    if (!in_array($category, $GLOBALS['ALPIN_CONSENT_REQUIRED'], true)) {
        $GLOBALS['ALPIN_CONSENT_REQUIRED'][] = $category;
    }
}

/**
 * Категории, запрошенные контентом страницы.
 *
 * @return array
 */
function cookie_consent_required_categories(): array {
    $required = $GLOBALS['ALPIN_CONSENT_REQUIRED'] ?? [];

    return is_array($required) ? $required : [];
}

/**
 * Категории, которые попадают в панель настроек баннера.
 *
 * «Необходимые» показываются всегда. Остальные — если у категории есть
 * сниппеты, включён флаг «показывать всегда» или категорию запросил контент
 * страницы (карты, видео).
 *
 * @param array $categories Категории из cookie_consent_render_categories()
 * @return array
 */
function cookie_consent_banner_categories(array $categories): array {
    $required = cookie_consent_required_categories();
    $result = [];

    foreach ($categories as $id => $category) {
        if ($id === 'necessary'
            || !empty($category['always_show'])
            || !empty($category['snippets'])
            || in_array($id, $required, true)) {
            $result[$id] = $category;
        }
    }

    return $result;
}

/**
 * Нужно ли выводить что-то на странице.
 *
 * @return bool
 */
function cookie_consent_should_render(): bool {
    $settings = cookie_consent_get_settings();

    if (!empty($settings['cookie_consent_force_banner'])) {
        return true;
    }

    return cookie_consent_count_snippets(cookie_consent_render_categories()) > 0;
}

/**
 * Формирует ссылку на политику или кнопку встроенной модалки ядра.
 *
 * @param string $url        URL страницы; пусто — встроенная модалка
 * @param string $label      Подпись ссылки
 * @param string $policyType Тип политики для openPolicy(): privacy или cookie
 * @return string HTML
 */
function cookie_consent_link(string $url, string $label, string $policyType): string {
    if ($url !== '') {
        return '<a class="alpin-consent__link" href="' . e(safeUrl($url)) . '">' . e($label) . '</a>';
    }

    return '<button type="button" class="alpin-consent__link" data-consent-policy="'
        . e($policyType) . '">' . e($label) . '</button>';
}

/**
 * Подключает стили баннера.
 *
 * @return void
 */
function cookie_consent_render_head(): void {
    if (!cookie_consent_should_render()) {
        return;
    }

    $stylePath = APP_ROOT . '/css/cookie-consent.css';

    if (is_file($stylePath)) {
        echo '<link rel="stylesheet" href="css/cookie-consent.css?v='
            . (int)filemtime($stylePath) . '">' . "\n";
        return;
    }

    // Плагин скопирован вручную без установки — берём исходник из папки плагина.
    $inline = @file_get_contents(__DIR__ . '/site/style.css');
    if ($inline !== false) {
        echo '<style>' . $inline . '</style>' . "\n";
    }
}

/**
 * Выводит баннер, сниппеты и клиентский скрипт.
 *
 * Разметка одинакова для всех посетителей: решение принимает только клиент,
 * поэтому страницу можно кешировать.
 *
 * @return void
 */
function cookie_consent_render_body(): void {
    if (!cookie_consent_should_render()) {
        return;
    }

    $settings = cookie_consent_get_settings();
    $categories = cookie_consent_render_categories();
    $version = cookie_consent_version($categories);
    $banner = cookie_consent_banner_required($settings, $categories);
    $snippetCount = cookie_consent_count_snippets($categories);
    $bannerCategories = cookie_consent_banner_categories($categories);

    // «Настроить» нужна только если есть что настраивать.
    $canConfigure = false;
    foreach ($bannerCategories as $id => $category) {
        if ($id !== 'necessary') {
            $canConfigure = true;
            break;
        }
    }

    $text = str_replace(["\r\n", "\r"], "\n", $settings['cookie_consent_text']);
    $text = nl2br(e($text), false);
    $text = str_replace(
        ['{policy}', '{cookie}'],
        [
            cookie_consent_link($settings['cookie_consent_policy_url'], $settings['cookie_consent_policy_label'], 'privacy'),
            cookie_consent_link($settings['cookie_consent_cookie_url'], $settings['cookie_consent_cookie_label'], 'cookie'),
        ],
        $text
    );

    $config = [
        'version'    => $version,
        'days'       => (int)$settings['cookie_consent_days'],
        'banner'     => $banner,
        'reopen'     => (bool)$settings['cookie_consent_float_button'],
        'categories' => [],
    ];

    foreach ($categories as $id => $category) {
        $config['categories'][] = [
            'id'          => $id,
            'title'       => $category['title'],
            'description' => $category['description'],
        ];
    }
    ?>
<script type="application/json" id="alpin-consent-config"><?php
    echo json_encode($config, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
?></script>
    <?php if ($snippetCount > 0): ?>
        <?php foreach ($categories as $id => $category): ?>
            <?php foreach ($category['snippets'] as $snippet): ?>
<template data-consent-cat="<?php echo e($id); ?>" data-consent-name="<?php echo e($snippet['name']); ?>" data-consent-code="<?php echo e(base64_encode($snippet['code'])); ?>"></template>
            <?php endforeach; ?>
        <?php endforeach; ?>
    <?php endif; ?>
    <?php if ($banner): ?>
<div id="alpin-consent" class="alpin-consent alpin-consent--<?php echo e($settings['cookie_consent_position']); ?>" hidden>
    <div class="alpin-consent__panel" role="dialog" aria-labelledby="alpin-consent-title">
        <div class="alpin-consent__head">
            <h2 class="alpin-consent__title" id="alpin-consent-title"><?php echo e($settings['cookie_consent_title']); ?></h2>
            <button type="button" class="alpin-consent__close" data-consent-action="close" aria-label="Закрыть" hidden>&times;</button>
        </div>
        <p class="alpin-consent__text"><?php echo $text; ?></p>
        <div class="alpin-consent__actions">
            <button type="button" class="alpin-consent__btn alpin-consent__btn--primary" data-consent-action="all"><?php echo e($settings['cookie_consent_accept_label']); ?></button>
            <button type="button" class="alpin-consent__btn" data-consent-action="necessary"><?php echo e($settings['cookie_consent_necessary_label']); ?></button>
            <?php if ($canConfigure): ?>
            <button type="button" class="alpin-consent__btn" data-consent-action="configure"><?php echo e($settings['cookie_consent_configure_label']); ?></button>
            <?php endif; ?>
        </div>
        <div class="alpin-consent__settings" hidden>
            <?php foreach ($bannerCategories as $id => $category): ?>
                <?php $ccInputId = 'alpin-consent-cat-' . $id; ?>
                <div class="alpin-consent__cat">
                    <input type="checkbox" id="<?php echo e($ccInputId); ?>" data-consent-cat="<?php echo e($id); ?>"<?php echo $id === 'necessary' ? ' checked disabled' : ''; ?>>
                    <label for="<?php echo e($ccInputId); ?>">
                        <span class="alpin-consent__cat-title"><?php echo e($category['title']); ?></span>
                        <span class="alpin-consent__cat-desc"><?php echo e($category['description']); ?></span>
                    </label>
                </div>
            <?php endforeach; ?>
            <div class="alpin-consent__settings-actions">
                <button type="button" class="alpin-consent__btn" data-consent-action="back"><?php echo e($settings['cookie_consent_back_label']); ?></button>
                <button type="button" class="alpin-consent__btn alpin-consent__btn--primary" data-consent-action="save"><?php echo e($settings['cookie_consent_save_label']); ?></button>
            </div>
        </div>
    </div>
</div>
        <?php if (!empty($settings['cookie_consent_float_button'])): ?>
<button type="button" id="alpin-consent-reopen" class="alpin-consent-reopen" hidden>Настройки cookie</button>
        <?php endif; ?>
    <?php endif; ?>
    <?php
    $scriptPath = APP_ROOT . '/js/cookie-consent.js';

    if (is_file($scriptPath)) {
        echo '<script src="js/cookie-consent.js?v=' . (int)filemtime($scriptPath) . '"></script>' . "\n";
    } else {
        // Плагин скопирован вручную без установки — берём исходник из папки плагина.
        $inlineScript = @file_get_contents(__DIR__ . '/site/script.js');
        if ($inlineScript !== false) {
            echo '<script>' . $inlineScript . '</script>' . "\n";
        }
    }
}

// Стили в head, разметка и скрипт в конце body.
add_action('render_head_end', 'cookie_consent_render_head');
add_action('render_body_end', 'cookie_consent_render_body');

// Журнал: новая правка сниппетов должна быть видна в списке действий.
if (function_exists('register_log_action')) {
    register_log_action('cookie_consent_snippets', 'Изменение сниппетов cookie', 'Плагины', 'puzzle');
}

// Сохранение настроек из секции «Cookie-согласие».
add_filter('save_settings_data', function ($newSettings) {
    if (!is_array($newSettings)) {
        return $newSettings;
    }

    $defaults = cookie_consent_defaults();
    $submitted = save_plugin_settings($newSettings, 'cookie_consent_section', $defaults, array_keys($defaults));

    if (!$submitted) {
        return $newSettings;
    }

    // Текст баннера: сохраняем переносы строк, HTML запрещён.
    $text = str_replace(["\r\n", "\r"], "\n", (string)($_POST['cookie_consent_text'] ?? ''));
    $text = trim(strip_tags($text));
    $newSettings['cookie_consent_text'] = $text !== '' ? $text : $defaults['cookie_consent_text'];

    // Подписи кнопок и ссылок: только текст.
    foreach ([
        'cookie_consent_title',
        'cookie_consent_accept_label',
        'cookie_consent_necessary_label',
        'cookie_consent_configure_label',
        'cookie_consent_save_label',
        'cookie_consent_back_label',
        'cookie_consent_policy_label',
        'cookie_consent_cookie_label',
    ] as $key) {
        $value = trim(strip_tags((string)($_POST[$key] ?? '')));
        $newSettings[$key] = $value !== '' ? mb_substr($value, 0, 200) : $defaults[$key];
    }

    // Положение баннера: только значения из белого списка.
    $positions = cookie_consent_positions();
    $position = (string)($_POST['cookie_consent_position'] ?? '');
    $newSettings['cookie_consent_position'] = isset($positions[$position])
        ? $position
        : $defaults['cookie_consent_position'];

    // Ссылки: пустая строка означает встроенную модалку политики.
    foreach (['cookie_consent_policy_url', 'cookie_consent_cookie_url'] as $key) {
        $url = trim((string)($_POST[$key] ?? ''));
        if ($url !== '') {
            $safe = safeUrl($url);
            $url = ($safe === '#') ? '' : $safe;
        }
        $newSettings[$key] = $url;
    }

    // Срок хранения согласия.
    $days = (int)($_POST['cookie_consent_days'] ?? 0);
    $newSettings['cookie_consent_days'] = ($days >= 1 && $days <= 3650)
        ? $days
        : (int)$defaults['cookie_consent_days'];

    // Категории и сниппеты.
    $newSettings['cookie_consent_categories'] = cookie_consent_parse_categories($_POST['cookie_consent_cat'] ?? []);

    return $newSettings;
});

/**
 * Описывает изменения сниппетов между двумя сохранениями настроек.
 *
 * Нужна для журнала: сниппет — это код с полными правами страницы, поэтому
 * каждая правка должна оставлять след. Имена обрезаются и чистятся от
 * переводов строк, чтобы сообщение осталось одной строкой.
 *
 * @param mixed $oldCategories Категории до сохранения
 * @param mixed $newCategories Категории после сохранения
 * @return string Пустая строка, если сниппеты не менялись
 */
function cookie_consent_snippet_changes($oldCategories, $newCategories): string {
    $oldCategories = is_array($oldCategories) ? $oldCategories : [];
    $newCategories = is_array($newCategories) ? $newCategories : [];
    $parts = [];

    foreach (array_keys(cookie_consent_category_defaults()) as $id) {
        $oldMap = cookie_consent_snippet_map($oldCategories[$id]['snippets'] ?? []);
        $newMap = cookie_consent_snippet_map($newCategories[$id]['snippets'] ?? []);

        if ($oldMap === $newMap) {
            continue;
        }

        $title = trim((string)($newCategories[$id]['title'] ?? $oldCategories[$id]['title'] ?? $id));
        $added = [];
        $removed = [];
        $renamed = [];

        foreach ($newMap as $code => $name) {
            if (!array_key_exists($code, $oldMap)) {
                $added[] = '«' . $name . '»';
            } elseif ($oldMap[$code] !== $name) {
                $renamed[] = '«' . $oldMap[$code] . '» → «' . $name . '»';
            }
        }

        foreach ($oldMap as $code => $name) {
            if (!array_key_exists($code, $newMap)) {
                $removed[] = '«' . $name . '»';
            }
        }

        $changes = [];

        if ($added) {
            $changes[] = (count($added) === 1 ? 'добавлен ' : 'добавлены ') . implode(', ', $added);
        }

        if ($removed) {
            $changes[] = (count($removed) === 1 ? 'удалён ' : 'удалены ') . implode(', ', $removed);
        }

        if ($renamed) {
            $changes[] = (count($renamed) === 1 ? 'переименован ' : 'переименованы ') . implode(', ', $renamed);
        }

        if ($changes) {
            $parts[] = '«' . $title . '»: ' . implode('; ', $changes);
        }
    }

    if (!$parts) {
        return '';
    }

    $message = implode('; ', $parts);

    return mb_strlen($message) > 500 ? mb_substr($message, 0, 497) . '…' : $message;
}

/**
 * Приводит список сниппетов к карте «код => имя» для сравнения.
 *
 * @param mixed $snippets Сниппеты категории
 * @return array
 */
function cookie_consent_snippet_map($snippets): array {
    $map = [];

    foreach ((array)$snippets as $snippet) {
        if (!is_array($snippet)) {
            continue;
        }

        $code = (string)($snippet['code'] ?? '');
        if ($code === '') {
            continue;
        }

        $name = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string)($snippet['name'] ?? ''));
        $name = trim((string)$name);
        $map[$code] = $name !== '' ? mb_substr($name, 0, 60) : 'без названия';
    }

    return $map;
}

// Изменение настроек: баннер и версия в кеше должны обновиться.
add_action('settings_saved', function ($oldSettings, $newSettings) {
    if (!is_array($oldSettings) || !is_array($newSettings)) {
        return;
    }

    foreach (array_keys(cookie_consent_defaults()) as $key) {
        if (($oldSettings[$key] ?? null) != ($newSettings[$key] ?? null)) {
            cookie_consent_clear_cache();
            return;
        }
    }

    $oldCategories = $oldSettings['cookie_consent_categories'] ?? [];
    $newCategories = $newSettings['cookie_consent_categories'] ?? [];
    if (json_encode($oldCategories) !== json_encode($newCategories)) {
        cookie_consent_clear_cache();
    }

    // Аудит: кто и какие сниппеты добавил, убрал или изменил.
    if (function_exists('logAction')) {
        $changes = cookie_consent_snippet_changes($oldCategories, $newCategories);

        if ($changes) {
            logAction('cookie_consent_snippets', $changes);
        }
    }
}, 10, 2);

// Включение/выключение, обновление и удаление плагина: чистим кеш.
add_action('plugin_after_toggle', function ($id) {
    if ($id === 'cookie-consent') {
        cookie_consent_clear_cache();
    }
}, 10, 1);

add_action('plugin_after_update', function ($id) {
    if ($id === 'cookie-consent') {
        cookie_consent_clear_cache();
    }
}, 10, 1);

add_action('plugin_before_delete', function ($id) {
    if ($id !== 'cookie-consent') {
        return;
    }

    cookie_consent_clear_cache();

    // Плагин при удалении чистит только свои настройки.
    if (!function_exists('saveData')) {
        return;
    }

    $settings = getSettingsData();
    $changed = false;

    foreach (array_keys($settings) as $key) {
        if (strpos((string)$key, 'cookie_consent_') === 0) {
            unset($settings[$key]);
            $changed = true;
        }
    }

    if ($changed) {
        saveData('settings', $settings);
    }
}, 10, 1);

// Секция в «Настройках сайта».
register_plugin_section('cookie-consent', 'Cookie-согласие', function () {
    include __DIR__ . '/admin-section.php';
});
