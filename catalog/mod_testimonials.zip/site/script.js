/**
 * Отзывы клиентов — скрипты для сайта
 */
(function() {
    'use strict';

    let pendingVideoId = '';

    /**
     * Разрешена ли категория «Функциональные».
     *
     * Без плагина согласия видео грузится как раньше.
     *
     * @returns {boolean}
     */
    function isConsentAllowed() {
        if (!window.AlpinConsent || typeof window.AlpinConsent.isAllowed !== 'function') {
            return true;
        }

        return window.AlpinConsent.isAllowed('functional');
    }

    /**
     * Отклонил ли посетитель категорию «Функциональные».
     *
     * Отличается от «ещё не спрашивали»: до первого согласия false.
     *
     * @returns {boolean}
     */
    function isConsentDenied() {
        return !!window.AlpinConsent
            && typeof window.AlpinConsent.isDenied === 'function'
            && window.AlpinConsent.isDenied('functional');
    }

    /**
     * Показывает причину заглушки: запрет в настройках cookie или вопрос.
     *
     * @param {Element} panel Панель согласия в лайтбоксе
     * @returns {void}
     */
    function syncConsentNotice(panel) {
        if (!panel) return;

        const denied = isConsentDenied();
        const defaultText = panel.querySelector('[data-consent-text-default]');
        const deniedText = panel.querySelector('[data-consent-text-denied]');
        const openBtn = panel.querySelector('[data-consent-open]');

        if (defaultText) {
            defaultText.hidden = denied;
        }
        if (deniedText) {
            deniedText.hidden = !denied;
        }
        if (openBtn) {
            openBtn.hidden = !denied;
        }
    }

    /**
     * Загружает iframe YouTube.
     *
     * @param {string} videoId
     * @returns {void}
     */
    function playVideo(videoId) {
        const iframe = document.getElementById('testimonial-video-iframe');
        if (!iframe || !videoId) return;

        iframe.src = 'https://www.youtube.com/embed/' + videoId + '?autoplay=1';
    }

    /**
     * Открывает лайтбокс: без согласия сначала спрашивает про YouTube.
     *
     * @param {string} videoId
     * @returns {void}
     */
    function openTestimonialVideo(videoId) {
        const lightbox = document.getElementById('testimonial-lightbox');
        const iframe = document.getElementById('testimonial-video-iframe');
        const consent = document.getElementById('testimonial-video-consent');

        if (!lightbox || !iframe) return;

        pendingVideoId = videoId;

        lightbox.classList.remove('hidden');
        lightbox.classList.add('flex');
        document.body.style.overflow = 'hidden';

        if (isConsentAllowed()) {
            if (consent) {
                consent.hidden = true;
            }
            playVideo(videoId);
            return;
        }

        // Без согласия iframe остаётся пустым: YouTube ничего не получает.
        iframe.src = '';
        if (consent) {
            syncConsentNotice(consent);
            consent.hidden = false;
        }
    }

    window.closeTestimonialLightbox = function(event) {
        const lightbox = document.getElementById('testimonial-lightbox');
        const iframe = document.getElementById('testimonial-video-iframe');
        const consent = document.getElementById('testimonial-video-consent');
        
        if (!lightbox || !iframe) return;
        
        if (event && event.target !== event.currentTarget) return;
        
        iframe.src = '';
        pendingVideoId = '';
        if (consent) {
            consent.hidden = true;
        }
        lightbox.classList.add('hidden');
        lightbox.classList.remove('flex');
        document.body.style.overflow = '';
    };

    // Кнопка «Загрузить видео»: разовое разрешение, cookie-решение не меняет.
    // Фаза перехвата: лайтбокс останавливает всплытие кликов внутри себя.
    document.addEventListener('click', function(event) {
        if (!event.target || !event.target.closest) return;

        const trigger = event.target.closest('[data-video-consent-load]');
        if (!trigger) return;

        event.preventDefault();

        const consent = document.getElementById('testimonial-video-consent');
        if (consent) {
            consent.hidden = true;
        }
        playVideo(pendingVideoId);
    }, true);

    // «Настройки cookie» в панели лайтбокса. Фаза перехвата: лайтбокс
    // останавливает всплытие кликов внутри себя.
    document.addEventListener('click', function(event) {
        if (!event.target || !event.target.closest) return;

        const trigger = event.target.closest('[data-consent-open]');
        if (!trigger) return;

        event.preventDefault();

        if (window.AlpinConsent && typeof window.AlpinConsent.open === 'function') {
            window.AlpinConsent.open();
        }
    }, true);

    // Решение изменили при открытом лайтбоксе.
    document.addEventListener('alpin:consent', function() {
        const consent = document.getElementById('testimonial-video-consent');
        if (!consent || consent.hidden) return;

        syncConsentNotice(consent);

        if (isConsentAllowed() && pendingVideoId) {
            consent.hidden = true;
            playVideo(pendingVideoId);
        }
    });

    function initTestimonials() {
        // Обработка кнопок play
        const playBtns = document.querySelectorAll('.testimonial-play-btn');
        playBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                const video = this.getAttribute('data-video');
                if (video) {
                    openTestimonialVideo(video);
                }
            });
        });

        // Закрытие по Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const lightbox = document.getElementById('testimonial-lightbox');
                if (lightbox && !lightbox.classList.contains('hidden')) {
                    closeTestimonialLightbox();
                }
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initTestimonials);
    } else {
        initTestimonials();
    }
})();
