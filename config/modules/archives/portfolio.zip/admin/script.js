/**
 * Портфолио — скрипты для админки (модуль).
 *
 * Категории модуля — список тегов (строки через \n в hidden).
 * Категории карточки — множественный выбор через чипы-чекбоксы (peer).
 * В hidden items[N][categories] уходит строка с \n.
 */
(function() {
    'use strict';

    const ITEMS_CONTAINER_ID = 'portfolio-items-container';
    const CATEGORIES_CONTAINER_ID = 'categories-container';
    const CATEGORIES_HIDDEN_ID = 'categories-hidden';
    const CATEGORY_CHIP_CB = 'js-portfolio-cat-cb';

    // ===================================================================
    // Категории модуля (список тегов в шапке)
    // ===================================================================

    /**
     * Возвращает массив категорий из DOM (теги в #categories-container).
     * Без "Все" — оно зарезервировано.
     */
    function getModuleCategories() {
        const container = document.getElementById(CATEGORIES_CONTAINER_ID);
        if (!container) return [];
        const result = [];
        container.querySelectorAll('.category-tag').forEach(function(tag) {
            const text = tag.textContent.replace('×', '').trim();
            if (text && text !== 'Все') {
                result.push(text);
            }
        });
        return result;
    }

    /**
     * Пересобирает hidden #categories-hidden: "Все\nДизайн\nUI"
     */
    function syncCategoriesHidden() {
        const hidden = document.getElementById(CATEGORIES_HIDDEN_ID);
        if (!hidden) return;
        const cats = getModuleCategories();
        const all = ['Все'].concat(cats);
        hidden.value = all.join('\n');
    }

    /**
     * Перерисовывает чипы во всех карточках, сохраняя ранее выбранные.
     */
    function rerenderAllChips() {
        const container = document.getElementById(ITEMS_CONTAINER_ID);
        if (!container) return;

        const categories = getModuleCategories();

        container.querySelectorAll('.portfolio-item-card').forEach(function(card) {
            const chipsWrap = card.querySelector('.js-portfolio-categories');
            if (!chipsWrap) return;

            // Запоминаем текущий выбор по чекбоксам
            const selected = [];
            chipsWrap.querySelectorAll('.' + CATEGORY_CHIP_CB).forEach(function(cb) {
                if (cb.checked) selected.push(cb.value);
            });

            // Перерисовываем
            renderChipsInCard(card, categories, selected);
        });
    }

    /**
     * Рисует чипы в одной карточке.
     * @param {HTMLElement} card
     * @param {string[]}    categories — список всех категорий модуля (без "Все")
     * @param {string[]}    selected   — какие выбраны
     */
    function renderChipsInCard(card, categories, selected) {
        const chipsWrap = card.querySelector('.js-portfolio-categories');
        if (!chipsWrap) return;
        selected = selected || [];

        let html = '';
        categories.forEach(function(cat) {
            const checked = selected.indexOf(cat) !== -1;
            html += '<label class="cursor-pointer">';
            html += '<input type="checkbox" class="!hidden peer ' + CATEGORY_CHIP_CB + '" value="' + escapeAttr(cat) + '"' + (checked ? ' checked' : '') + '>';
            html += '<span class="inline-flex items-center px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs text-slate-600 transition-all hover:border-[var(--primary-color)] peer-checked:bg-[var(--primary-color)] peer-checked:text-white peer-checked:border-[var(--primary-color)]">' + escapeHtml(cat) + '</span>';
            html += '</label>';
        });
        chipsWrap.innerHTML = html;

        // Сразу синхронизируем hidden этой карточки
        syncCardCategoriesHidden(card);
    }

    /**
     * Пересобирает hidden items[N][categories] в одной карточке — по текущим чипам.
     */
    function syncCardCategoriesHidden(card) {
        const hidden = card.querySelector('.js-portfolio-categories-hidden');
        if (!hidden) return;
        const chipsWrap = card.querySelector('.js-portfolio-categories');
        if (!chipsWrap) return;

        const selected = [];
        chipsWrap.querySelectorAll('.' + CATEGORY_CHIP_CB).forEach(function(cb) {
            if (cb.checked) selected.push(cb.value);
        });
        hidden.value = selected.join('\n');
    }

    /**
     * Синхронизация всех карточек сразу.
     */
    function syncAllCardsHidden() {
        const container = document.getElementById(ITEMS_CONTAINER_ID);
        if (!container) return;
        container.querySelectorAll('.portfolio-item-card').forEach(syncCardCategoriesHidden);
    }

    // ===================================================================
    // Вспомогательные
    // ===================================================================

    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function escapeAttr(text) {
        return escapeHtml(text);
    }

    // ===================================================================
    // Управление категориями модуля
    // ===================================================================

    function initCategories() {
        const addBtn = document.getElementById('add-category-btn');
        const input = document.getElementById('new-category-input');
        const container = document.getElementById(CATEGORIES_CONTAINER_ID);

        if (addBtn && input && container) {
            addBtn.addEventListener('click', function() {
                const name = input.value.trim();
                if (!name) return;
                if (name === 'Все') {
                    alert('Название "Все" зарезервировано');
                    return;
                }

                const exists = getModuleCategories().indexOf(name) !== -1;
                if (exists) {
                    alert('Такая категория уже существует');
                    return;
                }

                const tag = document.createElement('span');
                tag.className = 'category-tag inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-sm text-slate-700';
                tag.innerHTML = escapeHtml(name) + '<button type="button" class="js-remove-category text-slate-400 hover:text-rose-500 transition-colors" data-category="' + escapeAttr(name) + '"><span class="icon-x text-sm"></span></button>';
                container.appendChild(tag);
                input.value = '';

                syncCategoriesHidden();
                rerenderAllChips();
            });

            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    addBtn.click();
                }
            });
        }

        if (container) {
            container.addEventListener('click', function(e) {
                const btn = e.target.closest('.js-remove-category');
                if (!btn) return;
                const tag = btn.closest('.category-tag');
                if (!tag) return;

                const catName = btn.getAttribute('data-category');

                // Проверяем, используется ли категория хоть в одной карточке
                const inUse = isCategoryInUse(catName);
                if (inUse) {
                    if (!confirm('Категория "' + catName + '" используется в работах. Удалить всё равно?')) {
                        return;
                    }
                }

                tag.remove();
                syncCategoriesHidden();
                rerenderAllChips();
            });
        }
    }

    /**
     * Проверяет, есть ли у какой-нибудь карточки выбранной эта категория.
     */
    function isCategoryInUse(catName) {
        const container = document.getElementById(ITEMS_CONTAINER_ID);
        if (!container) return false;

        let inUse = false;
        container.querySelectorAll('.js-portfolio-categories-hidden').forEach(function(hidden) {
            const value = hidden.value || '';
            const cats = value.split('\n').map(function(s) { return s.trim(); }).filter(Boolean);
            if (cats.indexOf(catName) !== -1) {
                inUse = true;
            }
        });
        return inUse;
    }

    // ===================================================================
    // Инициализация
    // ===================================================================

    function init() {
        // 1) Основная list-механика карточек
        if (typeof window.initListModule === 'function') {
            window.initListModule({
                container:     ITEMS_CONTAINER_ID,
                prefix:        'items',
                template:      'tmpl-portfolio-item',
                cardSelector:  '.portfolio-item-card',
                labelSelector: '.js-portfolio-num',
                labelText:     'Работа #',
                addBtn:        'add-portfolio-item-btn',
                removeBtn:     '.js-remove-portfolio-item',
                minCount:      1,
                minMessage:    'Должна остаться хотя бы одна работа',
                onAfterAdd: function(card) {
                    // Обновляем превью картинки
                    card.querySelectorAll('.js-image-url-input').forEach(function(input) {
                        if (typeof updatePreviewOnManualInput === 'function') {
                            updatePreviewOnManualInput(input);
                        }
                    });

                    // Рисуем чипы категорий в новой карточке (актуальный список, ничего не выбрано)
                    renderChipsInCard(card, getModuleCategories(), []);
                }
            });
        }

        // 2) Логика управления категориями модуля
        initCategories();

        // 3) Делегирование change на чекбоксы чипов
        const itemsContainer = document.getElementById(ITEMS_CONTAINER_ID);
        if (itemsContainer) {
            itemsContainer.addEventListener('change', function(e) {
                const cb = e.target.closest('.' + CATEGORY_CHIP_CB);
                if (!cb) return;
                const card = cb.closest('.portfolio-item-card');
                if (!card) return;
                syncCardCategoriesHidden(card);
            });
        }

        // 4) Первичная синхронизация (на всякий случай — данные и DOM могут разойтись)
        syncCategoriesHidden();
        syncAllCardsHidden();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();