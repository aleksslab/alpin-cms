/**
 * Портфолио — скрипты для сайта
 */
(function() {
    'use strict';

    // ===== LIGHTBOX =====
    function openPortfolioLightbox(lightboxId, imageSrc, caption) {
        var lightbox = document.getElementById(lightboxId);
        var img = document.getElementById(lightboxId + '-image');
        var captionEl = document.getElementById(lightboxId + '-caption');
        
        if (!lightbox || !img) return;
        
        img.src = imageSrc;
        if (captionEl) {
            captionEl.textContent = caption || '';
        }
        lightbox.classList.remove('hidden');
        lightbox.classList.add('flex');
        document.body.style.overflow = 'hidden';
    }

    window.closePortfolioLightbox = function(event, lightboxId) {
        if (!lightboxId) return;
        var lightbox = document.getElementById(lightboxId);
        if (!lightbox) return;
        if (event && event.target !== event.currentTarget) return;
        lightbox.classList.add('hidden');
        lightbox.classList.remove('flex');
        document.body.style.overflow = '';
    };

    function initPortfolioGrid(grid) {
        var enableLightbox = grid.dataset.lightbox === 'true';
        var items = grid.querySelectorAll('.portfolio-item');
        var prefix = grid.id.replace(/-grid$/, '');
        var lightboxId = prefix + '-lightbox';
        var filtersRoot = document.getElementById(prefix + '-filters');
        var filters = filtersRoot ? filtersRoot.querySelectorAll('.portfolio-filter-btn') : [];
        var loadMoreWrap = document.getElementById(prefix + '-loadmore-wrap');
        var loadMoreBtn = loadMoreWrap ? loadMoreWrap.querySelector('.portfolio-load-more') : null;
        var showAll = grid.dataset.showAll === 'true';
        var perPage = parseInt(grid.dataset.perPage) || 6;

        if (!items.length) return;

        var currentFilter = 'all';
        var currentPage = 1;
        var allItems = [];
        var filteredItems = [];

        // Клик по карточке — открытие Lightbox
        items.forEach(function(item) {
            var img = item.querySelector('img');
            var titleEl = item.querySelector('.text-white.text-lg.font-bold');
            if (img && enableLightbox) {
                item.addEventListener('click', function(e) {
                    if (e.target.closest('.inline-block.mt-3')) return;
                    var caption = titleEl ? titleEl.textContent : '';
                    openPortfolioLightbox(lightboxId, img.src, caption);
                });
            }
            allItems.push(item);
        });

        // Escape
        if (enableLightbox) {
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    var lightbox = document.getElementById(lightboxId);
                    if (lightbox && !lightbox.classList.contains('hidden')) {
                        closePortfolioLightbox(null, lightboxId);
                    }
                }
            });
        }

        /**
         * Читает категории карточки из data-categories (JSON-массив).
         * Защита от битых данных — возвращает [].
         */
        function getItemCategories(item) {
            var raw = item.dataset.categories;
            if (!raw) return [];
            try {
                var parsed = JSON.parse(raw);
                return Array.isArray(parsed) ? parsed : [];
            } catch (e) {
                return [];
            }
        }

        /**
         * Фильтрует карточки: возвращает те, у которых в categories есть category.
         * 'all' — все карточки.
         */
        function getItemsByCategory(category) {
            var result = [];
            allItems.forEach(function(item) {
                if (category === 'all') {
                    result.push(item);
                    return;
                }
                var itemCats = getItemCategories(item);
                if (itemCats.indexOf(category) !== -1) {
                    result.push(item);
                }
            });
            return result;
        }

        function updateVisibleItems() {
            filteredItems = getItemsByCategory(currentFilter);
            
            allItems.forEach(function(item) {
                item.style.display = 'none';
            });

            var itemsToShow = filteredItems;
            
            if (!showAll) {
                var limit = perPage * currentPage;
                itemsToShow = filteredItems.slice(0, limit);
            }

            itemsToShow.forEach(function(item) {
                item.style.display = '';
            });

            updateLoadMoreButton();
        }

        function updateLoadMoreButton() {
            if (!loadMoreWrap) return;

            if (showAll) {
                loadMoreWrap.style.display = 'none';
                return;
            }

            var totalInCategory = filteredItems.length;
            var visibleCount = 0;
            allItems.forEach(function(item) {
                if (item.style.display !== 'none') {
                    visibleCount++;
                }
            });

            if (visibleCount < totalInCategory && visibleCount < allItems.length) {
                loadMoreWrap.style.display = 'block';
            } else {
                loadMoreWrap.style.display = 'none';
            }
        }

        function filterItems(category) {
            currentFilter = category;
            currentPage = 1;

            filters.forEach(function(btn) {
                btn.classList.remove('bg-[var(--primary-color)]', 'text-white', 'shadow-lg', 'shadow-[var(--primary-color)]/20');
                btn.classList.add('bg-slate-100', 'text-slate-600');
                if (btn.dataset.filter === category) {
                    btn.classList.remove('bg-slate-100', 'text-slate-600');
                    btn.classList.add('bg-[var(--primary-color)]', 'text-white', 'shadow-lg', 'shadow-[var(--primary-color)]/20');
                }
            });

            updateVisibleItems();
        }

        function loadMore() {
            if (showAll) return;
            currentPage++;
            updateVisibleItems();
        }

        filters.forEach(function(btn) {
            btn.addEventListener('click', function() {
                var filter = this.dataset.filter;
                filterItems(filter);
            });
        });

        if (loadMoreBtn) {
            loadMoreBtn.addEventListener('click', function() {
                loadMore();
            });
        }

        // Инициализация
        var hasAllFilter = false;
        filters.forEach(function(btn) {
            if (btn.dataset.filter === 'all') {
                hasAllFilter = true;
            }
        });
        
        if (hasAllFilter) {
            filterItems('all');
        } else if (filters.length > 0) {
            filterItems(filters[0].dataset.filter);
        } else {
            filterItems('all');
        }
    }

    function initPortfolio() {
        document.querySelectorAll('.portfolio-grid').forEach(initPortfolioGrid);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPortfolio);
    } else {
        initPortfolio();
    }
})();