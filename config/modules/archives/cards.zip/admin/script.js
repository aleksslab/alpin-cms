/**
 * Карточки — скрипты для админки (модуль).
 */
(function() {
    'use strict';

    function init() {
        if (typeof window.initListModule !== 'function') return;

        window.initListModule({
            container:     'cards-rows-container',
            prefix:        'items',
            template:      'tmpl-card-item',
            cardSelector:  '.card-item-card',
            labelSelector: '.js-card-num',
            labelText:     'Карточка #',
            addBtn:        'add-card-btn',
            removeBtn:     '.js-remove-card',
            minCount:      1,
            minMessage:    'Должна остаться хотя бы одна карточка',
            onAfterAdd: function(card) {
                card.querySelectorAll('.js-image-url-input').forEach(function(input) {
                    if (typeof updatePreviewOnManualInput === 'function') {
                        updatePreviewOnManualInput(input);
                    }
                });
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();