/**
 * Квиз — скрипты для админки (модуль).
 *
 * Два независимых списка в одном модуле:
 *   - questions (вопросы)
 *   - fields    (поля для сбора данных)
 * Плюс — видимость блока «Варианты» по типу вопроса (text/single/multiple).
 */
(function() {
    'use strict';

    // === Видимость опций вопроса по типу ===
    function initQuestionTypeVisibility() {
        const questionsContainer = document.getElementById('questions-container');
        if (!questionsContainer) return;

        // Делегирование change
        questionsContainer.addEventListener('change', function(e) {
            const select = e.target.closest('.question-type-select');
            if (!select) return;
            const card = select.closest('.question-item-card');
            if (!card) return;
            const optionsContainer = card.querySelector('.question-options-container');
            if (!optionsContainer) return;

            optionsContainer.style.display = (select.value === 'text') ? 'none' : 'block';
        });

        // Первичная настройка существующих карточек
        questionsContainer.querySelectorAll('.question-item-card').forEach(function(card) {
            const select = card.querySelector('.question-type-select');
            const optionsContainer = card.querySelector('.question-options-container');
            if (select && optionsContainer) {
                if (select.value === 'text') {
                    optionsContainer.style.display = 'none';
                }
            }
        });
    }

    // === Инициализация списков ===
    function init() {
        if (typeof window.initListModule !== 'function') return;

        // 1) Вопросы
        window.initListModule({
            container:     'questions-container',
            prefix:        'questions',
            template:      'tmpl-question',
            cardSelector:  '.question-item-card',
            labelSelector: '.js-question-num',
            labelText:     'Вопрос #',
            addBtn:        'add-question-btn',
            removeBtn:     '.js-remove-question',
            minCount:      1,
            minMessage:    'Должен остаться хотя бы один вопрос',
            onAfterAdd: function(card) {
                // В новой карточке сразу применим видимость блока «Варианты» по типу
                const select = card.querySelector('.question-type-select');
                const optionsContainer = card.querySelector('.question-options-container');
                if (select && optionsContainer) {
                    optionsContainer.style.display = (select.value === 'text') ? 'none' : 'block';
                }
            }
        });

        // 2) Поля
        window.initListModule({
            container:     'fields-container',
            prefix:        'fields',
            template:      'tmpl-field',
            cardSelector:  '.field-item-card',
            labelSelector: '.js-field-num',
            labelText:     'Поле #',
            addBtn:        'add-field-btn',
            removeBtn:     '.js-remove-field',
            minCount:      1,
            minMessage:    'Должно остаться хотя бы одно поле'
        });

        // 3) Видимость опций по типу вопроса
        initQuestionTypeVisibility();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();