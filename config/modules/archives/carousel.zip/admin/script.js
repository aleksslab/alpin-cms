/**
 * Карусель — скрипты для админки (модуль).
 */
(function() {
    'use strict';

    function init() {
        if (typeof window.initListModule !== 'function') return;

        window.initListModule({
            container:     'carousel-rows-container',
            prefix:        'slides',
            template:      'tmpl-carousel-slide',
            cardSelector:  '.slide-item-card',
            labelSelector: '.js-slide-num',
            labelText:     'Слайд #',
            addBtn:        'add-slide-row-btn',
            removeBtn:     '.js-remove-slide',
            minCount:      1,
            minMessage:    'Должен остаться хотя бы один слайд',
            onAfterAdd: function(card) {
                // Обновляем превью у полей image в новой карточке
                card.querySelectorAll('.js-image-url-input').forEach(function(input) {
                    if (typeof updatePreviewOnManualInput === 'function') {
                        updatePreviewOnManualInput(input);
                    }
                });
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();