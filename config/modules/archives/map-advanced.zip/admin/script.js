/**
 * Яндекс.Карты (расширенный) — скрипты для админки (модуль).
 *
 * Активная метка: флаг `active` на самой метке.
 * UI — чекбокс `js-map-active-checkbox` + hidden `items[N][active]`,
 * который гарантирует, что в FormData всегда уйдёт 0 или 1.
 * При выборе чекбокса — у остальных снимаем галочки (single-choice поведение).
 */
(function() {
    'use strict';

    function init() {
        const container = document.getElementById('map-items-container');
        if (!container) return;

        // UI: single-choice поведение — при выборе снимаем остальные
        container.addEventListener('change', function(e) {
            const cb = e.target.closest('.js-map-active-checkbox');
            if (!cb) return;
            if (!cb.checked) return; // снятие галочки — ничего не делаем

            container.querySelectorAll('.js-map-active-checkbox').forEach(function(other) {
                if (other !== cb) other.checked = false;
            });
        });

        // Основная list-механика
        if (typeof window.initListModule === 'function') {
            window.initListModule({
                container:     'map-items-container',
                prefix:        'items',
                template:      'tmpl-map-item',
                cardSelector:  '.map-item-card',
                labelSelector: '.js-map-num',
                labelText:     'Метка #',
                addBtn:        'add-map-item-btn',
                removeBtn:     '.js-remove-map-item',
                minCount:      1,
                minMessage:    'Должна остаться хотя бы одна метка'
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();