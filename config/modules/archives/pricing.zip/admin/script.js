/**
 * Тарифная сетка — скрипты для админки (модуль).
 */
(function() {
    'use strict';

    // === Дополнительная логика: кнопки быстрой вставки валюты ===
    function initCurrencyPresets() {
        const currencyPresets = document.querySelectorAll('.currency-preset');
        const currencyInput = document.getElementById('currency-input');
        if (!currencyInput) return;

        currencyPresets.forEach(function(btn) {
            btn.addEventListener('click', function() {
                const currency = this.getAttribute('data-currency');
                if (currency) {
                    currencyInput.value = currency;
                    currencyInput.dispatchEvent(new Event('input'));
                }
            });
        });
    }

    function init() {
        // 1) Механика списка тарифов
        if (typeof window.initListModule === 'function') {
            window.initListModule({
                container:     'pricing-container',
                prefix:        'items',
                template:      'tmpl-pricing-item',
                cardSelector:  '.pricing-item-card',
                labelSelector: '.js-pricing-num',
                labelText:     'Тариф #',
                addBtn:        'add-pricing-btn',
                removeBtn:     '.js-remove-pricing',
                minCount:      1,
                minMessage:    'Должен остаться хотя бы один тариф'
            });
        }

        // 2) Дополнительная логика модуля
        initCurrencyPresets();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();