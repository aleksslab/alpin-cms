/**
 * Бегущая лента — скрипты для админки (модуль).
 */
(function() {
    'use strict';

    function init() {
        if (typeof window.initListModule !== 'function') return;

        window.initListModule({
            container:     'brands-container',
            prefix:        'items',
            template:      'tmpl-brand-item',
            cardSelector:  '.brand-item-card',
            labelSelector: '.js-brand-num',
            labelText:     'Логотип #',
            addBtn:        'add-brand-btn',
            removeBtn:     '.js-remove-brand',
            minCount:      1,
            minMessage:    'Должен остаться хотя бы один логотип',
            onAfterAdd: function(card) {
                card.querySelectorAll('.js-image-url-input').forEach(function(input) {
                    if (typeof updatePreviewOnManualInput === 'function') {
                        updatePreviewOnManualInput(input);
                    }
                });
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();