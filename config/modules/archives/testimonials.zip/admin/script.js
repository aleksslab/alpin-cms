/**
 * Отзывы клиентов — скрипты для админки (модуль).
 */
(function() {
    'use strict';

    function init() {
        if (typeof window.initListModule !== 'function') return;

        window.initListModule({
            container:     'testimonials-container',
            prefix:        'items',
            template:      'tmpl-testimonial-item',
            cardSelector:  '.testimonial-item-card',
            labelSelector: '.js-testimonial-num',
            labelText:     'Отзыв #',
            addBtn:        'add-testimonial-btn',
            removeBtn:     '.js-remove-testimonial',
            minCount:      1,
            minMessage:    'Должен остаться хотя бы один отзыв',
            onAfterAdd: function(card) {
                card.querySelectorAll('.js-image-url-input').forEach(function(input) {
                    if (typeof updatePreviewOnManualInput === 'function') {
                        updatePreviewOnManualInput(input);
                    }
                });
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();